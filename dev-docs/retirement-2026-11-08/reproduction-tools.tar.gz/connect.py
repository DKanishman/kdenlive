#!/usr/bin/python3
"""Start the verified local editor on demand, then hand stdio to its local bridge."""
import fcntl
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

PROJECT = Path('/home/USER/code/kdenlive')
ROOT = PROJECT / 'build-mcp-linux'
BASE = Path('/home/USER/.codex/work/kdenlive-mcp-launch')
SOCKET = ROOT / 'run/kdenlive-mcp-local'
PYTHON = '/usr/bin/python3'

def private_directory(path):
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise RuntimeError('Expected a private same-user directory: ' + str(path))

def private_file(path):
    fd = os.open(path, os.O_CREAT | os.O_APPEND | os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077 or info.st_nlink != 1:
        os.close(fd)
        raise RuntimeError('Expected a private same-user ordinary file: ' + str(path))
    return fd

def main():
    if sys.argv[1:] not in ([], ['--launch-only']):
        raise RuntimeError('Use no arguments for stdio, or --launch-only to open the editor.')
    private_directory(BASE)
    private_directory(SOCKET.parent)
    lock = private_file(SOCKET.parent / '.launch.lock')
    try:
        deadline = time.monotonic() + 15
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise RuntimeError('Another launch is still in progress.')
                time.sleep(.1)
        if not os.path.lexists(SOCKET):
            env = os.environ.copy()
            for variable, name in (('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data')):
                directory = BASE / 'editor-state' / name
                private_directory(directory)
                env[variable] = str(directory)
            config = Path(env['XDG_CONFIG_HOME']) / 'kdenliverc'
            try:
                fd = os.open(config, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            except FileExistsError:
                info = config.lstat()
                if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid():
                    raise RuntimeError('Unexpected editor configuration file.')
            else:
                with os.fdopen(fd,'w') as file:
                    file.write('[env]\nmeltpath='+str(ROOT/'install/bin/melt')+'\nkdenliverendererpath='+str(ROOT/'install/bin/kdenlive_render')+'\nffmpegpath='+str(ROOT/'install/bin/ffmpeg')+'\nffprobepath='+str(ROOT/'install/bin/ffprobe')+'\n\n[unmanaged]\ndefault_profile=dv_pal\n\n[sdl]\nsdlAudioBackend=sdl2_audio\n\n[version]\nversion=26.11.70\n\n[startup]\nshowWelcome=false\n')
            log = private_file(BASE / 'editor.log')
            try:
                process = subprocess.Popen([PYTHON,'-B',str(PROJECT/'dev-tools/mcp-linux.py'),'launch'],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,close_fds=True)
            finally:
                os.close(log)
            deadline = time.monotonic() + 45
            while not os.path.lexists(SOCKET):
                if process.poll() is not None:
                    raise RuntimeError('Verified editor launch failed; inspect '+str(BASE/'editor.log'))
                if time.monotonic() >= deadline:
                    raise RuntimeError('Editor is still starting or needs a native setup decision; inspect '+str(BASE/'editor.log'))
                time.sleep(.1)
        info = SOCKET.lstat()
        if not stat.S_ISSOCK(info.st_mode) or info.st_uid != os.getuid():
            raise RuntimeError('Expected a local same-user Unix socket; existing paths are never removed.')
    finally:
        os.close(lock)
    if sys.argv[1:] == ['--launch-only']:
        print('Local Kdenlive MCP editor is running.')
        return
    # No client request has been consumed, sent or replayed before this handoff.
    os.execv(PYTHON,[PYTHON,'-B',str(PROJECT/'src/mcp/kdenlive-mcp.py'),'--socket',str(SOCKET)])

if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError) as error:
        print('Local Kdenlive MCP: '+str(error),file=sys.stderr)
        sys.exit(1)
