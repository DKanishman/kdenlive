from pathlib import Path
import importlib.util,subprocess,tempfile,shutil,json,time,sys
p=Path('/home/USER/code/kdenlive');base=Path('/home/USER/.codex/work/kdenlive-mcp-native-completion');w=Path(tempfile.mkdtemp(prefix='gui-diagnostic-',dir=base));s=importlib.util.spec_from_file_location('m',p/'dev-tools/mcp-linux.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);e=m.runtime_env(p/'build-mcp-linux')
for variable,name in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data')]:
 d=w/name;d.mkdir(mode=0o700);e[variable]=str(d)
shutil.copyfile('/home/USER/.codex/work/kdenlive-mcp-launch/editor-state/config/kdenliverc',w/'config/kdenliverc')
run=w/'run';run.mkdir(mode=0o700);e.update(TMPDIR=str(run),QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',SDL_AUDIODRIVER='dummy')
source=base/'multicam-live-uho7rbs0/reproducer.kdenlive';fixture=source.with_name('reproducer-'+w.name+'.kdenlive');shutil.copyfile(source,fixture)
log=(w/'editor.log').open('ab',buffering=0);child=subprocess.Popen([str(p/'build-mcp-linux/editor-build/bin/kdenlive'),'--no-welcome','--mcp-socket','kdmcp-debug',str(fixture)],env=e,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True);log.close();endpoint=run/'kdmcp-debug';meta={'pid':child.pid,'workspace':str(w),'endpoint':str(endpoint),'project':str(fixture)};(w/'job.json').write_text(json.dumps(meta,indent=2)+'\n');(base/'multicam/latest-diagnostic.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta),flush=True)
deadline=time.monotonic()+45
while not endpoint.exists():
 assert child.poll() is None,(w/'editor.log').read_text()[-5000:]
 assert time.monotonic()<deadline,'Diagnostic editor is still starting; inspect recorded PID and log.'
 time.sleep(.1)
sys.path.insert(0,str(base));from local_mcp_client import LocalMcp
with LocalMcp(w/'session',socket=endpoint) as c:
 deadline=time.monotonic()+30
 while True:
  state=c.state()
  if state.get('ready') and state.get('counts',{}).get('clips')==5:break
  assert time.monotonic()<deadline,{'state':state,'ui':c.call('get_ui')};time.sleep(.1)
 video=[t['id'] for t in state['tracks'] if not t['audio']];assert len(video)==3
 args={'angleTrackIds':video,'selections':[{'trackId':track,'startFrame':i*30,'endFrame':(i+1)*30} for i,track in enumerate(video)],'acknowledgeGroupChanges':True}
 result=c.mutate('multicam_cut',args,allow_error=True);(w/'operation.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'ok':result.get('ok'),'error':result.get('error'),'checks':result.get('rollbackChecks'),'postEditChecks':result.get('postEditChecks')}),flush=True)
 assert result.get('ok'),result.get('error')
 current=c.state();assert current['undoIndex']==state['undoIndex']+1
 c.mutate('undo');restored=c.state();assert [(t['id'],t['clips']) for t in restored['tracks']]==[(t['id'],t['clips']) for t in state['tracks']]
 c.mutate('redo');after=c.state();assert sorted((clip['startFrame'],clip['durationFrames']) for t in after['tracks'] if not t['audio'] for clip in t['clips'])==[(0,30),(30,30),(60,30)]
 meta['passed']=True;(w/'verified.json').write_text(json.dumps(meta,indent=2)+'\n');(base/'multicam/latest-diagnostic-passed.json').write_text(json.dumps(meta,indent=2)+'\n')
