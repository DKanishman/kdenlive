import pathlib,subprocess,os,json,datetime,traceback
base=pathlib.Path(__file__).parent
prefix=pathlib.Path('/home/USER/code/kdenlive/build-mcp-linux/install')
state={'status':'running','pid':os.getpid()}
def save(): (base/'result.json').write_text(json.dumps(state,indent=2)+'\n')
def run(args,cwd=None):
 print('+ '+repr(args),flush=True)
 subprocess.run(args,cwd=cwd,env=env,check=True,timeout=5400)
env=os.environ.copy();env['PKG_CONFIG_PATH']=str(prefix/'lib/pkgconfig')+':'+env.get('PKG_CONFIG_PATH','');env['LD_LIBRARY_PATH']=str(prefix/'lib')+':'+env.get('LD_LIBRARY_PATH','')
save()
try:
 for name,url,rev in [('x264','https://github.com/mirror/x264.git','31e19f92f00c7003fa115047ce50978bc98c3a0d'),('ffmpeg','https://github.com/FFmpeg/FFmpeg.git','946fcce07b6dcd0331c8cc609192aeff5e1924f8')]:
  state['phase']='fetching '+name;save();source=base/name
  if not source.exists():
   run(['git','init',str(source)])
   run(['git','-C',str(source),'remote','add','origin',url])
   run(['git','-C',str(source),'fetch','--depth','1','origin',rev])
   run(['git','-C',str(source),'checkout','--detach',rev])
  actual=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
  if actual!=rev:raise RuntimeError('Wrong source revision')
  if list(source.rglob('AGENTS.md')):raise RuntimeError('Dependency has instructions to inspect before compiling')
  state[name+'Revision']=rev;save()
 state['phase']='building x264';save()
 run(['./configure','--prefix='+str(prefix),'--enable-shared','--disable-cli','--disable-asm'],base/'x264')
 run(['make','-j2'],base/'x264');run(['make','install'],base/'x264')
 state['phase']='building FFmpeg';save()
 run(['./configure','--prefix='+str(prefix),'--enable-gpl','--enable-libx264','--enable-shared','--disable-static','--disable-doc','--disable-debug','--disable-x86asm','--extra-cflags=-I'+str(prefix/'include'),'--extra-ldflags=-L'+str(prefix/'lib')],base/'ffmpeg')
 run(['make','-j2'],base/'ffmpeg');run(['make','install'],base/'ffmpeg')
 state.update(status='passed',phase='installed',completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except Exception as error:
 state.update(status='failed',error=str(error));save();traceback.print_exc();raise
