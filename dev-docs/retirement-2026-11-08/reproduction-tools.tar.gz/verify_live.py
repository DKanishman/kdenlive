import datetime,hashlib,importlib.util,json,math,os,pathlib,struct,subprocess,sys,tempfile,time,wave,traceback
PROJECT=pathlib.Path('/home/USER/code/kdenlive');BASE=pathlib.Path('/home/USER/.codex/work/kdenlive-mcp-native-completion');sys.path.insert(0,str(BASE));from local_mcp_client import LocalMcp
WORK=pathlib.Path(tempfile.mkdtemp(prefix='multicam-live-',dir=BASE));result={'status':'running','workspace':str(WORK),'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(): (WORK/'result.json').write_text(json.dumps(result,indent=2)+'\n')
save()
try:
 spec=importlib.util.spec_from_file_location('m',PROJECT/'dev-tools/mcp-linux.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 manifest=json.loads((PROJECT/'build-mcp-linux/build-manifest.json').read_text());assert manifest['nativeTestsPassed'] and m.same_source(manifest['source'],m.fingerprint())
 env=m.runtime_env(PROJECT/'build-mcp-linux');endpoint=PROJECT/'build-mcp-linux/run/kdenlive-mcp-local'
 if endpoint.exists():
  with LocalMcp(WORK/'upgrade') as client:
   info=client.call('get_info');pid=int(info['processId']);actual=hashlib.sha256((pathlib.Path('/proc')/str(pid)/'exe').read_bytes()).hexdigest()
   if actual!=manifest['executableSha256']:
    previous=json.loads((BASE/'multicam/pre-upgrade.json').read_text());state=client.state()
    assert info['sessionId']==previous['editor']['sessionId'] and state['expectedState']==previous['state']['expectedState'],'Older editor changed; preserve its work.'
    assert state['freshProjectEligible'] and state['counts']['clips']==0 and state['counts']['subtitles']==0
    job=client.mutate('save_document',{'path':str(WORK/'previous-blank.kdenlive'),'overwrite':False})['job'];client.wait('project_job_status',job['jobId'])
    assert not client.state()['modified']
    actions=client.call('list_actions',{'query':'quit'})['actions'];assert any(a['id']=='file_quit' and a['enabled'] for a in actions)
    ui=client.call('get_ui')['ui'];client.call('trigger_action',{'actionId':'file_quit','expectedUi':ui['uiToken']})
    result['replacedOwnedEditorPid']=pid;save()
  if result.get('replacedOwnedEditorPid'):
   deadline=time.monotonic()+20
   while pathlib.Path('/proc',str(pid),'exe').exists() and time.monotonic()<deadline:time.sleep(.1)
   assert not pathlib.Path('/proc',str(pid),'exe').exists(),'Previous managed editor has not exited.'
   assert not os.path.lexists(endpoint),'Previous endpoint remains; do not remove it automatically.'
 for name,frequency in [('master',1000),('scratch',400)]:
  pcm=bytearray()
  for sample in range(90*1920):pcm.extend(struct.pack('<h',int(1600*math.sin(2*math.pi*frequency*sample/48000))))
  with wave.open(str(WORK/(name+'.wav')),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(48000);f.writeframes(pcm)
 with LocalMcp(WORK/'session') as client:
  info=client.call('get_info');binary=hashlib.sha256(pathlib.Path('/proc',info['processId'],'exe').read_bytes()).hexdigest();assert binary==manifest['executableSha256']
  catalog=client.rpc('tools/list')['tools'];assert 'multicam_cut' in {t['name'] for t in catalog}
  state=client.state()
  if state['projectPath']==str(WORK/'previous-blank.kdenlive') and state['counts']['clips']==0 and not state['modified']:
   job=client.mutate('new_project',{'profile':'dv_pal','videoTracks':2,'audioTracks':2})['job'];client.wait('project_job_status',job['jobId']);state=client.state()
  assert state['freshProjectEligible'] and state['counts']['clips']==0 and state['fps']==25,'Refuse to change a nonempty editor.'
  result.update(editor=info,executableSha256=binary,toolCount=len(catalog));save()
  audio=[t['id'] for t in state['tracks'] if t['audio']];video=[t['id'] for t in state['tracks'] if not t['audio']]
  video.append(client.mutate('add_track',{'position':len(state['tracks']),'audio':False})['trackId'])
  audio_ids=[]
  for index,name in enumerate(('scratch','master')):
   bid=client.mutate('import_media',{'path':str(WORK/(name+'.wav'))})['binId'];deadline=time.monotonic()+30
   while True:
    entry=next((b for b in client.state()['bin'] if b['id']==bid),None)
    if entry and entry['ready']:break
    assert time.monotonic()<deadline,'Media is not ready';time.sleep(.1)
   audio_ids.append(client.mutate('insert_media_clip',{'binId':bid,'trackId':audio[index],'startFrame':0,'sourceInFrame':0,'durationFrames':90,'stream':'audio'})['clipId'])
  clips=[]
  for track,color in zip(video,('#ff0000ff','#00ff00ff','#0000ffff')):clips.append(client.mutate('add_color_clip',{'trackId':track,'startFrame':0,'durationFrames':90,'color':color,'name':'Multicamera test angle'})['clipId'])
  client.mutate('group_items',{'itemIds':[clips[0],audio_ids[0]]})
  ranges=[{'trackId':video[i],'startFrame':i*30,'endFrame':(i+1)*30} for i in range(3)];args={'angleTrackIds':video,'selections':ranges}
  before=client.state();refusal=client.mutate('multicam_cut',args,allow_error=True);assert refusal['error']['code']=='GROUP_ACKNOWLEDGEMENT_REQUIRED' and len(refusal['affectedGroups'])==1
  assert client.state()['expectedState']==before['expectedState']
  args['acknowledgeGroupChanges']=True;applied=client.mutate('multicam_cut',args);assert applied['changed'] and client.state()['undoIndex']==before['undoIndex']+1
  def verify(edited):
   state=client.state();items={c['id']:c for t in state['tracks'] for c in t['clips']}
   for clip in audio_ids:assert items[clip]['startFrame']==0 and items[clip]['durationFrames']==90
   for index,track in enumerate(video):
    entries=next(t for t in state['tracks'] if t['id']==track)['clips'];assert len(entries)==1
    assert entries[0]['startFrame']==(index*30 if edited else 0) and entries[0]['durationFrames']==(30 if edited else 90)
   return state
  verify(True);client.mutate('undo');verify(False);client.mutate('redo');verify(True)
  project=WORK/'multicam.kdenlive';job=client.mutate('save_document',{'path':str(project),'overwrite':False})['job'];client.wait('project_job_status',job['jobId'])
  job=client.mutate('new_project',{'profile':'dv_pal','videoTracks':2,'audioTracks':2})['job'];client.wait('project_job_status',job['jobId'])
  job=client.mutate('save_document',{'path':str(WORK/'blank-before-reopen.kdenlive'),'overwrite':False})['job'];client.wait('project_job_status',job['jobId'])
  job=client.mutate('open_project',{'path':str(project)})['job'];client.wait('project_job_status',job['jobId'])
  reopened=client.state();camera_entries=[c for t in reopened['tracks'] if not t['audio'] for c in t['clips']];assert sorted((c['startFrame'],c['durationFrames']) for c in camera_entries)==[(0,30),(30,30),(60,30)]
  for repeat in range(4):
   assert client.state()['projectPath']==str(project) and not client.state()['modified']
   job=client.mutate('new_project',{'profile':'dv_pal','videoTracks':2,'audioTracks':2})['job'];client.wait('project_job_status',job['jobId'])
   job=client.mutate('save_document',{'path':str(WORK/f'blank-reopen-cycle-{repeat}.kdenlive'),'overwrite':False})['job'];client.wait('project_job_status',job['jobId'])
   job=client.mutate('open_project',{'path':str(project)})['job'];client.wait('project_job_status',job['jobId'])
   repeated=client.state();assert repeated['counts']['clips']==5 and not repeated['modified']
  render=client.mutate('start_render',{'path':str(WORK/'multicam.mp4'),'presetName':'MP4-H264/AAC','inFrame':0,'outFrame':89})['job'];render=client.wait('render_status',render['jobId'],180)
  pixels=[]
  ffmpeg=str(PROJECT/'build-mcp-linux/install/bin/ffmpeg')
  for frame in (15,45,75):
   data=subprocess.check_output([ffmpeg,'-nostdin','-hide_banner','-v','error','-i',str(WORK/'multicam.mp4'),'-vf',f'select=eq(n\\,{frame}),scale=1:1','-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','pipe:1'],env=env,timeout=30);assert len(data)==3;pixels.append(list(data))
  for channel,pixel in enumerate(pixels):assert pixel[channel]>220 and all(value<35 for index,value in enumerate(pixel) if index!=channel),pixels
  pcm=subprocess.check_output([ffmpeg,'-nostdin','-hide_banner','-v','error','-i',str(WORK/'multicam.mp4'),'-vn','-ac','1','-ar','48000','-f','s16le','pipe:1'],env=env,timeout=30);samples=struct.unpack('<'+'h'*(len(pcm)//2),pcm);assert len(samples)>=90*1900 and sum(abs(s) for s in samples)/len(samples)>500
  job=client.mutate('new_project',{'profile':'dv_pal','videoTracks':2,'audioTracks':2})['job'];client.wait('project_job_status',job['jobId']);blank=client.state();assert blank['counts']['clips']==0
  result.update(status='passed',checks=['on-demand source-matched installed editor','local MCP discovery/state/UI','explicit group acknowledgement before edits','three-camera cuts in one native history entry','unchanged audio ranges','undo/redo','native Save As and five reopen cycles','H264 red/green/blue output and decoded audio','returned to blank project'],pixels=pixels,render=render,project=str(project),blankState=blank,fullEditorCoverageVerified=False,completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();(BASE/'latest-multicam-live.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('status','workspace','checks','pixels','toolCount','executableSha256')},indent=2))
except Exception as e:
 result.update(status='failed',error=str(e),completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();traceback.print_exc();raise
