"""Private sequential test client. Never retries or replays an uncertain request."""
import json, os, pathlib, selectors, subprocess, time
class LocalMcp:
    def __init__(self, work, socket=None):
        self.work=pathlib.Path(work);self.work.mkdir(mode=0o700,parents=True,exist_ok=True)
        self.log=(self.work/'bridge-stderr.log').open('ab',buffering=0)
        command=['/usr/bin/python3','-B','/home/USER/.codex/work/kdenlive-mcp-launch/connect.py'] if socket is None else ['/usr/bin/python3','-B','/home/USER/code/kdenlive/src/mcp/kdenlive-mcp.py','--socket',str(socket)]
        self.process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,bufsize=0)
        self.selector=selectors.DefaultSelector();self.selector.register(self.process.stdout,selectors.EVENT_READ);self.buffer=bytearray();self.serial=0
        self.rpc('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'local-native-verification','version':'1'}})
        self.rpc('notifications/initialized',notification=True)
    def rpc(self,method,params=None,notification=False):
        req={'jsonrpc':'2.0','method':method}
        if params is not None:req['params']=params
        if not notification:self.serial+=1;req['id']=self.serial
        self.process.stdin.write(json.dumps(req,separators=(',',':')).encode()+b'\n');self.process.stdin.flush()
        if notification:return
        deadline=time.monotonic()+65
        while True:
            while b'\n' not in self.buffer:
                remaining=deadline-time.monotonic()
                if remaining<=0 or not self.selector.select(remaining):raise TimeoutError('MCP outcome uncertain; request is not replayed.')
                data=os.read(self.process.stdout.fileno(),65536)
                if not data:raise RuntimeError('MCP connection closed; request is not replayed. See '+str(self.work/'bridge-stderr.log'))
                self.buffer.extend(data)
                if len(self.buffer)>2*1024*1024:raise RuntimeError('MCP response exceeded the test client bound.')
            line,_,rest=self.buffer.partition(b'\n');self.buffer[:]=rest;reply=json.loads(line)
            if reply.get('id')==self.serial:break
        (self.work/f'{self.serial:03d}-reply.json').write_text(json.dumps(reply,indent=2)+'\n')
        if 'error' in reply:raise RuntimeError(str(reply['error']))
        return reply['result']
    def call(self,name,args=None,allow_error=False):
        result=self.rpc('tools/call',{'name':name,'arguments':args or {}})
        content=result.get('structuredContent',{})
        if not allow_error and (result.get('isError') or not content.get('ok')):raise RuntimeError(name+': '+str(content.get('error',content)))
        return content
    def state(self):return self.call('get_state')['state']
    def mutate(self,name,args=None,allow_error=False):
        args=dict(args or {});args['expectedState']=self.state()['expectedState'];return self.call(name,args,allow_error)
    def wait(self,tool,job_id,timeout=120):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            job=self.call(tool,{'jobId':job_id})['job']
            if job['status'] in ('completed','ready'):return job
            if job['status'] in ('failed','canceled','cancelled','obsolete','needsUserAction'):raise RuntimeError(str(job))
            time.sleep(.1)
        raise TimeoutError('Job still has an uncertain outcome: '+job_id)
    def close(self):
        if self.process.stdin:self.process.stdin.close()
        try:self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:self.process.terminate();self.process.wait(timeout=5)
        self.selector.close();self.log.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
