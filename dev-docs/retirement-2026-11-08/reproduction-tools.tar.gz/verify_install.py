import pathlib, subprocess, sys, os, json, importlib.util, datetime, hashlib, traceback
project=pathlib.Path('/home/USER/code/kdenlive')
root=project/'build-mcp-linux'
job=pathlib.Path(__file__).parent
result=job/'result.json'
def save(data):
    temporary=result.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,indent=2)+'\n')
    temporary.replace(result)
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def run(args,env):
    print('+ '+str(args),flush=True)
    subprocess.run([str(a) for a in args],cwd=project,env=env,check=True,timeout=5400)
state={'status':'running','pid':os.getpid(),'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
save(state)
try:
    spec=importlib.util.spec_from_file_location('native_linux',project/'dev-tools/mcp-linux.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    before=m.fingerprint();state['source']=before;save(state)
    (root/'build-manifest.json').unlink(missing_ok=True)
    env=m.runtime_env(root,isolated=True)
    env.update(QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',SDL_AUDIODRIVER='dummy')
    native=['compositiontest','mixtest','mcpmulticamtest','mcpalignmenttest','mcptest','mcpprojectextrastest','bintest','groupstest','sequencetest','markertest','subtitlestest','otiotest','ffttoolstest']
    run(['cmake','--build',root/'editor-build','--target','kdenlive','kdenlive_render','mltpreview',*native,'--parallel','1'],env)
    run(['cmake','--install',root/'editor-build/data'],env)
    query=subprocess.check_output(['ctest','--test-dir',str(root/'editor-build'),'-R',m.SUITES,'--show-only=json-v1'],env=env,text=True)
    selected=[t['name'] for t in json.loads(query)['tests']]
    if set(selected)!=set(native+['mcp_proxy','mcp_linux']):raise RuntimeError('Unexpected native/Python suite selection: '+str(selected))
    state['selectedSuites']=selected;state['phase']='testing';save(state)
    run(['ctest','--test-dir',root/'editor-build','-R',m.SUITES,'--output-on-failure','--no-tests=error','--timeout','1800','--parallel','1','--output-junit',job/'editor-tests.xml'],env)
    if not m.same_source(before,m.fingerprint()):raise RuntimeError('Application/build sources changed during verification; no install receipt issued.')
    state['phase']='installing';save(state)
    run(['cmake','--install',root/'editor-build'],env)
    exe=root/'install/bin/kdenlive'
    dependency=subprocess.check_output(['git','-C',str(root/'mlt-source'),'diff','HEAD','--binary'])
    manifest={'source':before,'mltRevision':m.MLT_REVISION,'mltWorktreeSha256':hashlib.sha256(dependency).hexdigest(),'patches':{name:digest(project/'packaging/patches'/name) for name in m.PATCHES},'nativeTestsPassed':True,'fullEditorCoverageVerified':False,'executable':str(exe),'executableSha256':digest(exe),'verifiedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verifiedSuites':selected}
    (root/'build-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    state.update(status='passed',phase='installed',completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest=str(root/'build-manifest.json'),executable=str(exe),executableSha256=manifest['executableSha256'])
    save(state)
    print('Native suites passed; matched editor installed with build receipt.',flush=True)
except Exception as error:
    state.update(status='failed',error=str(error),completedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(state);traceback.print_exc();sys.exit(1)
