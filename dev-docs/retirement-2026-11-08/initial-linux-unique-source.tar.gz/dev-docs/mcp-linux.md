# Native MCP on Linux

The native MCP fork must be compiled. Installing the stock Kdenlive Flatpak or
running the Python bridge alone does not add an MCP server to that editor.
The helper uses a separate prefix under `build-mcp-linux/install`, preserves
the stock installation and never installs system packages itself.

## Fedora prerequisites

Run in your ordinary terminal with network access and permission to install packages:

```bash
sudo dnf install git cmake ninja-build gcc-c++ extra-cmake-modules pkgconf-pkg-config
sudo dnf builddep mlt kdenlive
```

`dnf builddep` requires the distribution's builddep support and source package
metadata. It installs the distribution package's dependencies; CMake remains
the authority for this newer fork's requirements: Qt 6.10+, KF 6.21+,
KDDockWidgets 2.4+, OpenTimelineIO and the multimedia development libraries.
See [upstream build instructions](build.md) and
[KDE's Fedora dependency guidance](https://develop.kde.org/docs/getting-started/building/help-dependencies/).

## Build and test

From the repository root:

```bash
python3 -B dev-tools/mcp-linux.py doctor
python3 -B dev-tools/mcp-linux.py build --jobs 2
```

The build command clones MLT at the exact revision in
[the dependency patch instructions](../packaging/patches/README.md), checks and
applies all four patches, builds/installs it locally, checks essential runtime
modules and runs its native CTest suite. It then configures/builds this editor,
runs MCP, subtitle, group, sequence, marker, OTIO, FFT and Python suites, and
installs the editor only after those checks pass. Tests use isolated settings,
software Qt rendering and dummy SDL audio. Successful execution records Git
revision, pending source content, dependency changes and patch hashes in
`build-manifest.json`. A failed command is a build failure, not a successful
installation. Network, a compiler and Unix socket permissions are required.

The helper defaults to two compiler jobs to limit memory use. A custom location
must precede the subcommand, for example `--root /short/path build --jobs 2`.
Keep that same `--root` for launch/config/probe. Existing dependency checkouts
are never reset, and patches that cannot apply or reverse-check are errors.

## Launch and connect

```bash
python3 -B dev-tools/mcp-linux.py launch
```

For disposable settings/data/cache, add `--isolated`; to open an existing local
project, add `--project /absolute/path/project.kdenlive`. Launch refuses an absent
or stale build receipt. Its editor and MLT runtime come from the same prefix.
It creates a same-user directory with mode 0700 and sets the editor's `TMPDIR`
so Qt and the connector agree on the exact socket path. Existing endpoints are
never deleted automatically. Use `--socket-name another-unique-name` before the
subcommand for another editor instance. Socket paths must fit Linux AF_UNIX limits.

In a second terminal, while the editor is running:

```bash
python3 -B dev-tools/mcp-linux.py probe
python3 -B dev-tools/mcp-linux.py config
```

`probe` performs initialize, initialized notification, tools/list, get_info,
get_capabilities and get_state. It checks native replies without editing a
project. Close the probe before connecting another client; the native endpoint
accepts one client. `config` prints a standard `mcpServers` stanza for a stdio
client, with an explicit interpreter, bridge and socket path. Import that stanza
into your MCP client's settings; no client configuration is edited automatically.
The bridge checks Linux SO_PEERCRED before sending a request. Native startup
logs and `get_info.endpoint` expose Qt's actual endpoint; `get_info.buildVersion`
also includes the configured build revision.

## Current verification and remaining work

On 2026-11-07 this workspace has stock Kdenlive 26.08.2 as a Fedora Flatpak.
After the user installed the Fedora dependencies, GCC 16.2.1, CMake 4.3.0,
Ninja and the development libraries became available. A real CMake configuration
found compatible Qt 6.11.2 and KF 6.31.0, then refused system MLT 7.40.0 because
the fork requires at least 7.42.0. The build helper targets patched MLT 7.43.0,
but its source clone still fails because Git cannot resolve github.com in this
execution session. AF_UNIX binding and connection are still refused with EPERM.
The GitHub connector confirmed the fork and its two MCP branches, but that does
not provide network access to the build process. Neither a native Linux
installation nor a live editor MCP test has completed.

Python 3.15 accepts deeply nested JSON without the previous recursion error.
The bridge now enforces an explicit 1,024-container nesting bound for client and
native frames, with escaped JSON strings handled correctly. The original failing
case and new depth/peer-identity regressions pass. The selected suite executes 36
tests: 35 pass and the Windows real-pipe test is skipped on Linux. The separate
real Unix socket test fails because of the session's socket permission, and is
still required by the normal full suite and build command. No test silently
skips that Linux restriction.

This Linux setup work does not integrate the unverified
`codex/mcp-full-coverage-wip` branch. Full editor coverage remains incomplete.
The open native alignment/multicam/time-map contracts, project extras,
archive/library/OTIO workflows, specialized analysis/masks and persistent render
queue still require implementation and audiovisual/persistence verification.
See [the original checkpoint](mcp-progress.md), the WIP branch's plans and
[the Linux verification record](mcp-linux-verification.json).
