from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpquick_cases.inc')
s=p.read_text(encoding='utf-8')
old='''    root->setObjectName(QStringLiteral("mcp-quick-context-root-last"));
    submenu->setObjectName(QStringLiteral("mcp-quick-context-submenu-first"));
    root->addMenu(submenu);'''
new='''    root->setObjectName(QStringLiteral("mcp-quick-context-root-last"));
    submenu->setObjectName(QStringLiteral("mcp-quick-context-submenu-first"));
    root->setTitle(QStringLiteral("Context root"));
    submenu->setTitle(QStringLiteral("Nested context"));
    root->addMenu(submenu);'''
assert old in s
s=s.replace(old,new)
p.write_text(s,encoding='utf-8')
