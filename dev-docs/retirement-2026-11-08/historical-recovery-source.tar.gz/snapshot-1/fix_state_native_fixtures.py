from pathlib import Path
path=Path(r"C:\Users\USER\Documents\kdenlive\tests\mcpstate_cases.inc")
text=path.read_text(encoding="utf-8")
old='''    REQUIRE_FALSE(added.value(QStringLiteral("item")).toObject().value(QStringLiteral("id")).toString().isEmpty());
    project.success(QStringLiteral("undo"), project.expected());
    CHECK(project.state().value(QStringLiteral("ready")).toBool());
'''
new='''    const auto created = added.value(QStringLiteral("item")).toObject();
    const auto createdId = created.value(QStringLiteral("binId")).toString();
    REQUIRE_FALSE(createdId.isEmpty());
    CHECK(created.value(QStringLiteral("parentId")).toString() == deepest);
    const auto folder = bin->getFolderByBinId(createdId);
    REQUIRE(folder);
    CHECK(folder->parent()->clipId() == deepest);
    CHECK(folder->name() == QStringLiteral("Created beyond4096"));
    project.success(QStringLiteral("undo"), project.expected());
    CHECK_FALSE(bin->getFolderByBinId(createdId));
    CHECK(project.state().value(QStringLiteral("ready")).toBool());
'''
if text.count(old)!=1:raise RuntimeError("Folder assertion anchor changed")
text=text.replace(old,new,1)
old='''    auto evaluate = [&](int position) {
        graph.seek(position);
        graph.set_speed(1);
        std::unique_ptr<Mlt::Frame> frame(graph.get_frame());
        REQUIRE(frame);
        REQUIRE(frame->is_valid());
        mlt_audio_format format = mlt_audio_f32le;
        int frequency = 48000, channels = 2, samples = 1920;
        REQUIRE(frame->get_audio(format, frequency, channels, samples));
    };
'''
new='''    auto evaluate = [&](int position) {
        // Evaluate this exact native transition with real producer frames.
        // The saved sequence's pre-existing field graph can route its output
        // through other tracks, so its final frame need not pull this mix.
        toneA.seek(position);
        toneB.seek(position);
        toneA.set_speed(1);
        toneB.set_speed(1);
        std::unique_ptr<Mlt::Frame> frameA(toneA.get_frame()), frameB(toneB.get_frame());
        REQUIRE(frameA);
        REQUIRE(frameB);
        REQUIRE(frameA->is_valid());
        REQUIRE(frameB->is_valid());
        REQUIRE(mlt_transition_process(mix.get_transition(), frameA->get_frame(), frameB->get_frame()) == frameA->get_frame());
        mlt_audio_format format = mlt_audio_f32le;
        int frequency = 48000, channels = 2, samples = 1920;
        const auto audio = static_cast<float *>(frameA->get_audio(format, frequency, channels, samples));
        REQUIRE(audio);
        REQUIRE(format == mlt_audio_f32le);
        REQUIRE(samples > 0);
        REQUIRE(channels > 0);
        REQUIRE(std::any_of(audio, audio + samples * channels, [](float value) { return std::abs(value) > 0.000001f; }));
    };
'''
if text.count(old)!=1:raise RuntimeError("Native telemetry evaluation anchor changed")
text=text.replace(old,new,1)
path.write_text(text,encoding="utf-8")
print("Corrected native folder contract and direct real-audio mix evaluation; source released")