from pathlib import Path
root = Path(r'C:\Users\USER\Documents\kdenlive')
p = root / 'data/scripts/whisper/whispertotext.py'
s = p.read_text(encoding='utf-8')
s = s.replace('import argparse\n', 'import argparse\nimport json\nimport wave\n', 1)
s = s.replace('def run_whisper(source, model, device="cpu", task="transcribe", extraparams=""):', 'def run_whisper(source, model, device="cpu", task="transcribe", extraparams="",\n                model_root=None, pcm_source=False, language=None, ffmpeg_path=None):', 1)
start = s.index('    with (\n        open(checkpoint_file, "rb")')
end = s.index('\n    transcribe_kwargs = {', start)
s = s[:start] + '''    if model_root is not None:
        # MCP supplies an existing local checkpoint; never pass a model alias to
        # load_model, which may download or replace an invalid cached model.
        checkpoint_file = os.path.join(os.path.abspath(model_root), os.path.basename(url))
        if not os.path.isabs(model_root) or not os.path.isfile(checkpoint_file):
            raise FileNotFoundError("The selected local Whisper checkpoint is unavailable")
        loadedModel = whisper.load_model(checkpoint_file, device=device)
        if alignment_heads is not None:
            loadedModel.set_alignment_heads(alignment_heads)
    else:
        # Preserve the existing GUI loader and its default cache location.
        with open(checkpoint_file, "rb") as fp:
            kwargs = {"weights_only": True} if torch.__version__ >= "1.13" else {}
            checkpoint = torch.load(fp, map_location=device, **kwargs)
        dims = whisper.ModelDimensions(**checkpoint["dims"])
        loadedModel = whisper.Whisper(dims)
        loadedModel.load_state_dict(checkpoint["model_state_dict"])
        if alignment_heads is not None:
            loadedModel.set_alignment_heads(alignment_heads)
        loadedModel = loadedModel.to(device)

    if pcm_source:
        # Pre-extracted PCM avoids Whisper's ffmpeg subprocess, so cancellation
        # owns exactly one process. Validate before allocating the sample array.
        import numpy as np
        with wave.open(source, "rb") as pcm:
            if (pcm.getnchannels(), pcm.getsampwidth(), pcm.getframerate(), pcm.getcomptype()) != (1, 2, 16000, "NONE"):
                raise ValueError("PCM input must be uncompressed mono 16-bit 16000 Hz WAV")
            if pcm.getnframes() > 16000 * 1800:
                raise ValueError("PCM input exceeds the 30-minute job limit")
            source = np.frombuffer(pcm.readframes(pcm.getnframes()), dtype="<i2").astype(np.float32) / 32768.0
''' + s[end:]
s = s.replace("    if 'fp16' in transcribe_kwargs", '''    # Typed CLI values must retain spaces and '=' characters in paths/names.
    if language:
        transcribe_kwargs["language"] = language
    if ffmpeg_path:
        os.environ["PATH"] += os.pathsep + os.path.dirname(os.path.abspath(ffmpeg_path))

    if 'fp16' in transcribe_kwargs''', 1)
s = s.replace('    args = parser.parse_args()\n', '''    parser.add_argument("--model_root", help="existing local model directory; no downloads")
    parser.add_argument("--pcm_source", action="store_true", help="read pre-extracted mono 16k PCM WAV without ffmpeg")
    parser.add_argument("--result_file", help="write exact native segment/word timestamps as UTF-8 JSON")
    args = parser.parse_args()
''', 1)
s = s.replace('        sys.exit()\n\n    if float(args.in_point)', '        return 1\n\n    if args.pcm_source and (float(args.in_point) != 0 or float(args.out_point) != 0):\n        raise ValueError("PCM source ranges must be extracted before recognition")\n\n    if float(args.in_point)', 1)
start = s.index("    jobArgs = ''\n")
end = s.index('\n    for i in result["segments"]:', start)
s = s[:start] + '''    result = run_whisper(source, model, device, task, model_root=args.model_root,
                         pcm_source=args.pcm_source, language=language, ffmpeg_path=ffmpeg_path)
    if args.result_file:
        with open(args.result_file, "w", encoding="utf-8") as output:
            json.dump({"language": result.get("language", ""), "segments": result["segments"]},
                      output, ensure_ascii=False, allow_nan=False)
        return 0
''' + s[end:]
p.write_text(s, encoding='utf-8')
p = root / 'data/scripts/vosk/speechtotext.py'
s = p.read_text(encoding='utf-8')
s = s.replace('import argparse\n', 'import argparse\nimport json\nimport wave\n', 1)
s = s.replace('    args = parser.parse_args()\n', '''    parser.add_argument("--pcm_source", action="store_true", help="read pre-extracted mono 16k PCM WAV without ffmpeg")
    parser.add_argument("--result_file", help="write exact native recognizer results as UTF-8 JSON")
    args = parser.parse_args()
''', 1)
s = s.replace('        sys.exit()\n\n    model = args.model', '        return 1\n\n    model = args.model', 1)
start = s.index('    # zone rendering\n')
end = s.index('\n\nif __name__', start)
s = s[:start] + '''    # The GUI retains its FFmpeg input. MCP pre-extracts the exact source range
    # and reads PCM directly, avoiding a child process that could outlive abort.
    process = None
    pcm = None
    if args.pcm_source:
        if float(args.in_point) != 0 or float(args.out_point) != 0:
            raise ValueError("PCM source ranges must be extracted before recognition")
        pcm = wave.open(source, "rb")
        if (pcm.getnchannels(), pcm.getsampwidth(), pcm.getframerate(), pcm.getcomptype()) != (1, 2, sample_rate, "NONE"):
            pcm.close()
            raise ValueError("PCM input must be uncompressed mono 16-bit 16000 Hz WAV")
        if pcm.getnframes() > sample_rate * 1800:
            pcm.close()
            raise ValueError("PCM input exceeds the 30-minute job limit")
        read_audio = lambda: pcm.readframes(2000)
    else:
        command = [ffmpeg_path, '-loglevel', 'quiet', '-i', source]
        if float(args.in_point) > 0 or float(args.out_point) > 0:
            command += ['-ss', args.in_point, '-t', args.out_point]
        command += ['-ar', str(sample_rate), '-ac', '1', '-f', 's16le', '-']
        process = subprocess.Popen(command, stdout=subprocess.PIPE)
        read_audio = lambda: process.stdout.read(4000)

    results = []
    try:
        while True:
            data = read_audio()
            if not data:
                result = rec.FinalResult()
            elif rec.AcceptWaveform(data):
                result = rec.Result()
            else:
                continue
            if args.result_file:
                results.append(json.loads(result))
            else:
                sys.stdout.buffer.write(result.encode('utf-8'))
                sys.stdout.flush()
            if not data:
                break
    finally:
        if pcm is not None:
            pcm.close()
        if process is not None:
            process.stdout.close()
            if process.wait() != 0:
                raise RuntimeError("FFmpeg audio extraction failed")

    if args.result_file:
        with open(args.result_file, "w", encoding="utf-8") as output:
            json.dump({"results": results}, output, ensure_ascii=False, allow_nan=False)
    return 0
''' + s[end:]
p.write_text(s, encoding='utf-8')
print('Updated the two native speech text scripts; no dependencies or models installed.')
