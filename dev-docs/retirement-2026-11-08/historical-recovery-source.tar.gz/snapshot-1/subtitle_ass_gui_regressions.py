"""Actual-editor MCP ASS import metadata, history, save and reopen proof."""
from pathlib import Path
import hashlib


ASS = ("[Script Info]\nTitle: MCP ASS metadata regression\nScriptType: v4.00+\n\n"
       "[V4+ Styles]\nStyle: Accent,Arial,37.25,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,2,2,10,11,12,1\n\n"
       "[Kdenlive Extradata]\nMaxLayer: 3\nDefaultStyles: Accent,Default,Accent,Accent\n\n"
       "[Fonts]\nfontname: mcp-ass-probe.ttf\n!!!!\n\n"
       "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
       "Dialogue: 0,0:00:00.40,0:00:01.40,Accent,Actor,12,13,14,fx,Imported Unicode שלום\n"
       "Comment: 3,0:00:02.04,0:00:03.24,Default,,0,0,0,,Second layer\n")


def verify_subtitle_ass(driver, work):
    work = Path(work).resolve()

    def require(value, message):
        if not value:
            raise AssertionError(message)

    def subtitles():
        return driver.call("get_subtitles")

    def ids(value):
        return {item["id"] for item in value["subtitles"]}

    def metadata_bytes(value):
        require(b"Title: MCP ASS metadata regression" in value, "ASS script metadata missing")
        require(b"Style: Accent,Arial,37.25," in value, "ASS exact style metadata missing")
        require(b"MaxLayer: 3" in value and b"DefaultStyles: Accent,Default,Accent,Accent" in value,
                "ASS layer/default-style metadata missing")
        require(b"[Fonts]\nfontname: mcp-ass-probe.ttf\n!!!!\n" in value, "ASS embedded-font metadata missing")

    def check_imported():
        value = subtitles()
        require(value["maxLayer"] == 3 and len(value["subtitles"]) == 3, "ASS layer/event readback differs")
        first = next(item for item in value["subtitles"] if item["text"].startswith("Imported Unicode"))
        require(first["startFrame"] == 10 and first["endFrame"] == 35 and first["layer"] == 0,
                f"ASS exact event timing differs: {first}")
        require(first["style"] == "Accent" and first["name"] == "Actor" and first["marginL"] == 12
                and first["marginR"] == 13 and first["marginV"] == 14 and first["effects"] == "fx",
                f"ASS event metadata differs: {first}")
        second = next(item for item in value["subtitles"] if item["text"] == "Second layer")
        require(second["layer"] == 3 and second["startFrame"] == 51 and second["endFrame"] == 81
                and not second["dialogue"], f"ASS comment/layer metadata differs: {second}")
        return value

    def published(value):
        result = {}
        for item in value["languageTracks"]:
            path = Path(item["savedPath"]).resolve()
            require(path.is_relative_to(work), f"Published fixture path escaped owned directory: {path}")
            result[path] = path.read_bytes()
        return result

    def verify_published(values):
        for path, expected in values.items():
            require(path.read_bytes() == expected, f"History changed a published ASS asset: {path}")

    state = driver.state()
    require(not state["projectPath"] and state["undoCount"] == 0 and not subtitles()["subtitles"],
            "ASS integration phase requires a fresh owned project")
    video = next(track for track in state["tracks"] if not track["audio"])
    driver.mutate("add_color_clip", trackId=video["id"], startFrame=0, durationFrames=100,
                  color="#204060ff", name="ASS metadata persistence")
    original = driver.mutate("edit_subtitle", operation="add", startFrame=2, endFrame=8,
                             text="Original event retained")["id"]
    before = subtitles()
    before_index = driver.state()["undoIndex"]
    path = work / "metadata-input.ASS"
    path.write_text(ASS, encoding="utf-8")
    source_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    imported = driver.mutate("subtitle_file", operation="import", path=str(path))
    require(imported["importedCount"] == 2, "MCP ASS import count differs")
    require(driver.state()["undoIndex"] == before_index + 1, "ASS import did not create exactly one history command")
    after = check_imported()
    after_ids = ids(after)
    require(original in after_ids, "ASS import changed original event identity")
    driver.mutate("undo")
    undone = subtitles()
    require(undone["subtitles"] == before["subtitles"] and undone["styles"] == before["styles"]
            and undone["maxLayer"] == before["maxLayer"], "ASS undo did not restore all public metadata/events")
    driver.mutate("redo")
    require(ids(check_imported()) == after_ids, "ASS redo changed native event IDs")
    exported = work / "metadata-export.ass"
    driver.mutate("subtitle_file", operation="export", path=str(exported))
    metadata_bytes(exported.read_bytes())
    project_a, project_b = work / "ass-save-A.kdenlive", work / "ass-save-B.kdenlive"
    driver.project_job("save_document", path=str(project_a), overwrite=False)
    driver.project_job("save_document", path=str(project_a), overwrite=True)
    snapshots = published(subtitles())
    for value in snapshots.values():
        metadata_bytes(value)
    driver.project_job("save_document", path=str(project_b), overwrite=False)
    snapshots.update(published(subtitles()))
    work_files = [Path(item["workPath"]).resolve() for item in subtitles()["languageTracks"]]
    driver.mutate("undo")
    require(ids(subtitles()) == {original}, "Saved ASS undo changed the retained event")
    verify_published(snapshots)
    driver.mutate("redo")
    require(ids(check_imported()) == after_ids, "Saved ASS redo changed IDs")
    require(not driver.state()["modified"], "ASS redo did not restore clean saved boundary")
    profile = driver.state()["profile"]
    if isinstance(profile, dict):
        profile = profile["path"]
    reopened = []
    for index, target in enumerate((project_a, project_b), 1):
        driver.project_job("new_project", profile=profile, videoTracks=2, audioTracks=1)
        driver.project_job("save_document", path=str(work / f"ass-reopen-bridge-{index}.kdenlive"), overwrite=False)
        for item in work_files:
            require(item.is_relative_to(work), f"Refusing fixture cleanup outside owned directory: {item}")
            item.unlink(missing_ok=True)
        driver.project_job("open_project", path=str(target))
        value = check_imported()
        for payload in published(value).values():
            metadata_bytes(payload)
        work_files = [Path(item["workPath"]).resolve() for item in value["languageTracks"]]
        reopened.append(str(target))
    verify_published(snapshots)
    require(hashlib.sha256(path.read_bytes()).hexdigest() == source_hash, "ASS importer changed input file")
    return {"passed": True, "importedCount": 2, "singleUndoCommand": True, "stableUndoRedoIds": True,
            "scriptStylesLayersFontsVerified": True, "nativeReopens": reopened,
            "publishedAssets": {str(path): hashlib.sha256(value).hexdigest() for path, value in snapshots.items()},
            "inputUnchanged": True}
