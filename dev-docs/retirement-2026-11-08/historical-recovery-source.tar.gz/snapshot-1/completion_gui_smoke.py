#!/usr/bin/env python3
"""Owned Windows integration checks for the native Kdenlive MCP expansion."""
from __future__ import annotations
import argparse
import array
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET

HELPER = Path(r"C:\Users\USER\.codex\work\kdenlive-mcp-prototype\live_smoke.py")
spec = importlib.util.spec_from_file_location("kdenlive_owned_smoke_helpers", HELPER)
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
OwnedJob, McpClient = common.OwnedJob, common.McpClient
seed_config, wait_for_pipe = common.seed_config, common.wait_for_pipe
hidden_options, stop_owned, run_logged = common.hidden_options, common.stop_owned, common.run_logged
require, SmokeFailure = common.require, common.SmokeFailure
PHASES = ("catalogs", "profile", "timeline", "effects", "lifecycle", "sequences", "dialogs")

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def loaded_module_provenance(process_id, names=("mlt-7.dll", "mlt++-7.dll", "mltcore.dll", "mltxml.dll", "mltsdl2.dll", "mltopenfx.dll")):
    """Read the owned Windows process's actual loaded module paths and file hashes."""
    import ctypes
    from ctypes import wintypes

    require(os.name == "nt" and isinstance(process_id, int) and process_id > 0,
            "Module provenance requires the owned Windows application PID")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel.CloseHandle.restype = wintypes.BOOL
    kernel.K32EnumProcessModulesEx.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.HMODULE),
                                               wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), wintypes.DWORD)
    kernel.K32EnumProcessModulesEx.restype = wintypes.BOOL
    for function_name in ("K32GetModuleBaseNameW", "K32GetModuleFileNameExW"):
        function = getattr(kernel, function_name)
        function.argtypes = (wintypes.HANDLE, wintypes.HMODULE, wintypes.LPWSTR, wintypes.DWORD)
        function.restype = wintypes.DWORD
    # Query/read access to this runner's own app only; no debug privileges.
    process = kernel.OpenProcess(0x0400 | 0x0010, False, process_id)
    if not process:
        raise ctypes.WinError(ctypes.get_last_error())
    wanted = {name.casefold() for name in names}
    try:
        for attempt in range(5):
            try:
                capacity = 256
                while True:
                    modules = (wintypes.HMODULE * capacity)()
                    needed = wintypes.DWORD()
                    if not kernel.K32EnumProcessModulesEx(process, modules, ctypes.sizeof(modules), ctypes.byref(needed), 3):
                        raise ctypes.WinError(ctypes.get_last_error())
                    count = (needed.value + ctypes.sizeof(wintypes.HMODULE) - 1) // ctypes.sizeof(wintypes.HMODULE)
                    require(count <= 8192, "Owned process module enumeration exceeded its diagnostic bound")
                    if needed.value <= ctypes.sizeof(modules):
                        break
                    capacity = count
                found = []
                for module in modules[:count]:
                    short_name = ctypes.create_unicode_buffer(512)
                    if not kernel.K32GetModuleBaseNameW(process, module, short_name, len(short_name)):
                        raise ctypes.WinError(ctypes.get_last_error())
                    if short_name.value.casefold() not in wanted:
                        continue
                    path_capacity = 512
                    while True:
                        full_name = ctypes.create_unicode_buffer(path_capacity)
                        written = kernel.K32GetModuleFileNameExW(process, module, full_name, path_capacity)
                        if not written:
                            raise ctypes.WinError(ctypes.get_last_error())
                        if written < path_capacity - 1:
                            break
                        require(path_capacity < 32768, "Loaded module path exceeded the Windows diagnostic bound")
                        path_capacity = min(path_capacity * 2, 32768)
                    module_path = Path(full_name.value)
                    require(module_path.is_absolute(), "Windows returned a relative loaded module path")
                    found.append({"name": short_name.value.casefold(), "path": str(module_path),
                                  "sha256": digest(module_path), "sizeBytes": module_path.stat().st_size})
                return {"processId": process_id, "method": "Windows K32 process module enumeration",
                        "hashMeaning": "SHA256 of the file at the OS-reported loaded module path",
                        "modules": sorted(found, key=lambda item: (item["name"], item["path"].casefold())),
                        "missing": sorted(wanted - {item["name"] for item in found})}
            except OSError as error:
                # Loading/unloading can briefly invalidate the loader snapshot.
                if getattr(error, "winerror", None) not in (24, 299) or attempt == 4:
                    raise
                time.sleep(.05)
    finally:
        kernel.CloseHandle(process)

def clip_map(state):
    return {int(c["id"]): (t, c) for t in state["tracks"] for c in t["clips"]}

def signature(state):
    sources = {b["id"]: b for b in state["bin"]}
    result = []
    for track in state["tracks"]:
        for clip in track["clips"]:
            source = sources[clip["binId"]]
            resource = source.get("resource", "")
            resource_key = str(Path(resource).resolve()).lower() if resource and Path(resource).is_file() else (source["mediaType"], source["name"])
            result.append((track["position"], track["audio"], str(resource_key), clip["startFrame"],
                           clip["durationFrames"], clip["inFrame"], clip["outFrame"], clip.get("speed", 1)))
    return sorted(result)

class Driver:
    def __init__(self, client, report):
        self.client, self.report = client, report
        self.last_state = self.last_ui = None

    def call(self, name, arguments=None):
        content = self.client.tool(name, arguments or {})
        if "state" in content:
            self.last_state = content["state"]
        if name == "get_ui":
            self.last_ui = content["ui"]
        return content

    def state(self):
        result = self.call("get_state")["state"]
        require(result.get("ready"), f"Native project is not ready: {result}")
        return result

    def stable_ui(self, timeout=10, interval=.3):
        deadline, stable_since, previous = time.monotonic() + timeout, time.monotonic(), None
        while time.monotonic() < deadline:
            ui = self.call("get_ui")["ui"]
            token = ui["uiToken"]
            if token != previous:
                previous, stable_since = token, time.monotonic()
            elif time.monotonic() - stable_since >= interval:
                return ui
            time.sleep(.05)
        raise SmokeFailure("Native UI did not reach stable focus/layout before the planned operation")

    def mutate(self, tool_name, **arguments):
        state = self.state()
        return self.call(tool_name, {"expectedState": state["expectedState"], **arguments})

    def project_job(self, name, **arguments):
        result = self.mutate(name, **arguments)
        return self.wait_job("project_job_status", result["job"]["jobId"], timeout=60)

    def wait_job(self, tool, job_id, timeout=60):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            result = self.call(tool, {"jobId": job_id})
            job = result["job"]
            if job["status"] in ("completed", "canceled"):
                return result
            if job["status"] in ("failed", "needsUserAction") or job.get("needsUserInput"):
                ui = self.call("get_ui")["ui"]
                raise SmokeFailure(f"Unexpected native job outcome; no dialog was resolved: {job}; modalId={ui.get('modalId')}; full UI saved in diagnostics")
            time.sleep(.03)
        raise SmokeFailure(f"Native job deadline reached: {tool} {job_id}; no command was replayed")

    def wait_media(self, bin_id):
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            state = self.state()
            item = next((x for x in state["bin"] if x["id"] == bin_id), None)
            if item and item["ready"]:
                require(item["status"] == "ready", f"Native source is unsupported: {item}")
                return item
            ui = self.call("get_ui")["ui"]
            require(not ui["needsUserInput"], f"Unexpected import dialog; no control was activated: {ui}")
            time.sleep(.03)
        raise SmokeFailure(f"Media loader deadline reached for {bin_id}")

    def check_clip(self, clip_id, **expected):
        state = self.state()
        require(int(clip_id) in clip_map(state), f"Missing native timeline clip {clip_id}")
        track, clip = clip_map(state)[int(clip_id)]
        actual = {"trackId": track["id"], **clip}
        for key, value in expected.items():
            require(actual[key] == value, f"Clip {clip_id} {key}: expected {value}, actual {actual}")
        return actual

    def phase(self, name, function):
        print(f"Starting {name}", flush=True)
        started = time.monotonic()
        value = function()
        self.report["checks"][name] = value
        self.report["completedPhases"].append(name)
        print(f"Passed {name} in {time.monotonic()-started:.2f}s", flush=True)
        return value

def catalogs(driver, tool_names):
    capabilities = driver.call("get_capabilities")
    actions = driver.call("list_actions")["actions"]
    ui = driver.call("get_ui")["ui"]
    require(actions and ui.get("uiToken"), "Native actions/UI discovery failed")
    require(not ui["needsUserInput"], f"Unexpected startup dialog: {ui}")
    profiles = driver.call("list_profiles")["profiles"]
    presets = driver.call("list_render_presets")["presets"]
    effects = driver.call("asset_catalog", {"kind": "effect", "limit": 5})
    transitions = driver.call("asset_catalog", {"kind": "transition", "limit": 5})
    require(profiles and presets and effects["total"] > 0 and transitions["total"] > 0, "Native asset catalogs are incomplete")
    return {"toolCount": len(tool_names), "actionCount": len(actions), "profileCount": len(profiles),
            "presetCount": len(presets), "effectCount": effects["total"], "transitionCount": transitions["total"],
            "capabilities": capabilities, "initialUi": ui}

def initial_profile(driver):
    path = Path(__file__).with_name("lifecycle_gui_regressions.py")
    spec = importlib.util.spec_from_file_location("initial_profile_regression", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify_empty_unsaved_profile(driver.call)

def build_fixture(args, work, env, owned):
    fixture = work / "fixture-av.mp4"
    command = [str(args.ffmpeg), "-n", "-v", "error",
               "-f", "lavfi", "-i", "color=c=red:s=320x180:r=25:d=1",
               "-f", "lavfi", "-i", "color=c=blue:s=320x180:r=25:d=1",
               "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=2",
               "-filter_complex", "[0:v][1:v]concat=n=2:v=1:a=0,format=yuv420p[v]",
               "-map", "[v]", "-map", "2:a:0", "-frames:v", "50", "-t", "2",
               "-c:v", "libx264", "-preset", "ultrafast", "-crf", "18", "-threads", "2",
               "-c:a", "aac", "-b:a", "128k", "-ar", "48000", "-ac", "2", str(fixture)]
    run_logged(command, work / "fixture-ffmpeg.log", env, owned, 60)
    require(fixture.is_file() and fixture.stat().st_size > 0, "Source fixture was not generated")
    return fixture

def setup_project(driver, fixture):
    driver.project_job("new_project", profile="dv_pal", videoTracks=2, audioTracks=2)
    state = driver.state()
    require(not state["projectPath"] and not clip_map(state), "new_project did not create a fresh document")
    require(state["fps"] == 25 and state["width"] == 720 and state["height"] == 576, f"New profile mismatch: {state}")
    videos = [t["id"] for t in state["tracks"] if not t["audio"] and not t["locked"]]
    audios = [t["id"] for t in state["tracks"] if t["audio"] and not t["locked"]]
    imported = driver.mutate("import_media", path=str(fixture))
    bin_id = imported["binId"]
    source = driver.wait_media(bin_id)
    require(source["hasVideo"] and source["hasAudio"] and source["durationFrames"] >= 50, f"AV fixture import differs: {source}")
    visual = driver.mutate("insert_media_clip", binId=bin_id, trackId=videos[0], startFrame=0,
                           sourceInFrame=0, durationFrames=50, stream="video")["clipId"]
    audio = driver.mutate("insert_media_clip", binId=bin_id, trackId=audios[0], startFrame=0,
                          sourceInFrame=0, durationFrames=50, stream="audio")["clipId"]
    driver.check_clip(visual, trackId=videos[0], startFrame=0, durationFrames=50, inFrame=0, outFrame=49)
    driver.check_clip(audio, trackId=audios[0], startFrame=0, durationFrames=50, inFrame=0, outFrame=49)
    require(len(clip_map(driver.state())) == 2, "Explicit stream insertion unexpectedly mirrored AV")
    return {"binId": bin_id, "video": visual, "audio": audio, "videoTracks": videos, "audioTracks": audios,
            "fixture": str(fixture), "fixtureSha256": digest(fixture)}

def timeline_checks(driver, context):
    visual, audio = context["video"], context["audio"]
    video_track, upper = context["videoTracks"]
    audio_track = context["audioTracks"][0]
    original = signature(driver.state())
    driver.mutate("move_clip", clipId=visual, trackId=video_track, startFrame=7)
    driver.check_clip(visual, startFrame=7, inFrame=0, outFrame=49)
    driver.mutate("move_clip", clipId=visual, trackId=video_track, startFrame=0)
    cut = driver.mutate("cut_clip", clipId=visual, frame=25)
    driver.check_clip(cut["leftClipId"], startFrame=0, durationFrames=25, inFrame=0, outFrame=24)
    driver.check_clip(cut["rightClipId"], startFrame=25, durationFrames=25, inFrame=25, outFrame=49)
    driver.mutate("undo")
    require(signature(driver.state()) == original, "Undo did not restore exact ordinary AV clip ranges")
    driver.mutate("redo")
    driver.check_clip(cut["rightClipId"], startFrame=25, inFrame=25)
    driver.mutate("undo")
    driver.mutate("trim_clip", clipId=visual, durationFrames=40, edge="right")
    driver.check_clip(visual, durationFrames=40, inFrame=0, outFrame=39)
    driver.mutate("undo")
    driver.check_clip(visual, durationFrames=50, outFrame=49)
    duplicate = driver.mutate("duplicate_clip", clipId=visual, trackId=upper, startFrame=60)["clipId"]
    driver.check_clip(duplicate, trackId=upper, startFrame=60, durationFrames=50, inFrame=0, outFrame=49)
    driver.mutate("delete_item", itemId=duplicate)
    require(duplicate not in clip_map(driver.state()), "Native duplicate deletion did not apply")
    driver.mutate("undo")
    driver.check_clip(duplicate, startFrame=60, durationFrames=50)
    driver.mutate("redo")
    require(duplicate not in clip_map(driver.state()), "Redo did not remove the duplicate")
    driver.mutate("move_clip", clipId=audio, trackId=audio_track, startFrame=3)
    driver.check_clip(audio, startFrame=3, inFrame=0, outFrame=49)
    driver.mutate("undo")
    require(signature(driver.state()) == original, "Ordinary timeline checks changed the final AV assembly")
    return {"passed": True, "ordinaryAV": True, "moveSplitTrimDuplicateDeleteUndoRedo": True,
            "exactFinalSignature": original}

def effects_checks(driver, context):
    visual, audio = context["video"], context["audio"]
    detail = driver.call("asset_catalog", {"kind": "effect", "assetId": "brightness"})
    require("CubicIn" in detail["interpolationTypes"], "Native easing was absent from discovery")
    added = driver.mutate("edit_effect", scope="clip", targetId=str(visual), operation="add", effectId="brightness")
    effect = next(e for e in added["stack"]["effects"] if e.get("assetId") == "brightness")
    instance = effect["instanceId"]
    driver.mutate("edit_effect", scope="clip", targetId=str(visual), operation="parameters",
                  instanceId=instance, parameters={"level": .85})
    driver.mutate("set_effect_keyframes", scope="clip", targetId=str(visual), instanceId=instance, keyframes=[
        {"frame": 0, "values": {"level": .85}, "interpolation": "CubicIn"},
        {"frame": 49, "values": {"level": 1.0}, "interpolation": "Linear"}])
    stack = driver.call("get_effect_stack", {"scope": "clip", "targetId": str(visual)})["stack"]
    actual = next(e for e in stack["effects"] if e.get("assetId") == "brightness")
    require(actual["enabled"] and actual["rawNativeParameters"]["level"], f"Native animated effect readback missing: {actual}")
    audio_effects = driver.mutate("set_clip_audio", clipId=audio, gainDb=-3, fadeInFrames=2, fadeOutFrames=3)
    title = driver.mutate("create_title", name="Native MCP smoke title", durationFrames=50, items=[
        {"type": "rectangle", "x": 24, "y": 24, "width": 672, "height": 84, "fill": "#14243a"},
        {"type": "text", "text": "Kdenlive native MCP", "x": 40, "y": 40,
         "width": 640, "height": 60, "fontSize": 38, "bold": True, "color": "#ffffff"}])
    driver.wait_media(title["binId"])
    title_clip = driver.mutate("insert_media_clip", binId=title["binId"], trackId=context["videoTracks"][1],
                               startFrame=0, sourceInFrame=0, durationFrames=50, stream="video")["clipId"]
    driver.check_clip(title_clip, startFrame=0, durationFrames=50)
    sub = driver.mutate("edit_subtitle", operation="add", text="Frame accurate subtitles", startFrame=5, endFrame=45)
    subtitle = next(s for s in driver.call("get_subtitles")["subtitles"] if s["id"] == sub["id"])
    require(subtitle["text"] == "Frame accurate subtitles" and subtitle["startFrame"] == 5 and subtitle["endFrame"] == 45,
            f"Editable native subtitle differs: {subtitle}")
    context.update(titleBinId=title["binId"], titleClipId=title_clip, subtitleId=sub["id"], brightnessInstanceId=instance)
    return {"passed": True, "easedBrightness": actual, "audioEffects": audio_effects.get("appliedEffects"),
            "titleBinId": title["binId"], "titleClipId": title_clip, "subtitle": subtitle}

def choose_h264_preset(driver):
    presets = driver.call("list_render_presets")["presets"]
    for preset in presets:
        if not preset.get("valid") or preset.get("extension", "").lower() != "mp4":
            continue
        detail = driver.call("list_render_presets", {"presetName": preset["id"]})["presets"][0]
        if detail.get("parameters", {}).get("vcodec") == "libx264":
            return detail
    raise SmokeFailure("No installed software H.264 MP4 preset is available")

def inspect_video(args, path, work, env, owned, state):
    raw = run_logged([str(args.ffprobe), "-v", "error", "-count_frames", "-show_streams", "-of", "json", str(path)],
                     work / "final-ffprobe.log", env, owned, 60, capture=True)
    probe = json.loads(raw)
    video = [s for s in probe["streams"] if s["codec_type"] == "video"]
    audio = [s for s in probe["streams"] if s["codec_type"] == "audio"]
    require(len(video) == 1 and len(audio) == 1, f"Expected one video and one audio stream: {probe}")
    v, a = video[0], audio[0]
    require(int(v["nb_read_frames"]) == 50, f"Export changed exact frame count: {v}")
    require((v["width"], v["height"]) == (state["width"], state["height"]), "Export changed project dimensions")
    require(abs(float(Fraction(v["avg_frame_rate"])) - state["fps"]) < 1e-6, "Export changed frame rate")
    require(int(a["sample_rate"]) == 48000 and int(a["channels"]) == 2, f"Export audio format differs: {a}")
    samples = {}
    for frame, color in ((10, "red"), (35, "blue")):
        data = run_logged([str(args.ffmpeg), "-v", "error", "-i", str(path), "-map", "0:v:0",
                           "-vf", f"select=eq(n\\,{frame}),crop=16:16:(iw-16)/2:(ih-16)/2,scale=1:1",
                           "-frames:v", "1", "-an", "-sn", "-pix_fmt", "rgb24", "-f", "rawvideo", "pipe:1"],
                          work / f"final-pixel-{frame}.log", env, owned, 60, capture=True)
        require(len(data) == 3, f"Cannot decode sample frame {frame}")
        r, g, b = data
        require((r > 100 and g < 60 and b < 60) if color == "red" else (b > 100 and r < 60 and g < 60),
                f"Output scene order/color mismatch at {frame}: {list(data)}")
        samples[str(frame)] = {"expected": color, "rgb": list(data)}
    pcm_bytes = run_logged([str(args.ffmpeg), "-v", "error", "-i", str(path), "-map", "0:a:0", "-t", "1",
                            "-vn", "-sn", "-c:a", "pcm_s16le", "-f", "s16le", "pipe:1"],
                           work / "final-audio-decode.log", env, owned, 60, capture=True)
    pcm = array.array("h")
    pcm.frombytes(pcm_bytes)
    require(pcm, "Export audio decoded empty")
    rms = math.sqrt(sum(int(s) ** 2 for s in pcm) / len(pcm)) / 32768
    require(rms > .01, f"Export audio is unexpectedly silent: RMS={rms}")
    return {"probe": probe, "sampledColors": samples, "audioRms": rms}

def lifecycle_checks(driver, context, args, work, env, owned):
    base, copy, video = work / "normal-save.kdenlive", work / "reopened-edited-copy.kdenlive", work / "native-render.mp4"
    expected = signature(driver.state())
    saved = driver.project_job("save_document", path=str(base), overwrite=False)
    require(Path(saved["state"]["projectPath"]).resolve() == base.resolve() and base.stat().st_size > 0,
            "Normal native save did not update live document URL")
    saved_hash = digest(base)
    driver.project_job("new_project", profile="dv_pal", videoTracks=2, audioTracks=2)
    require(not clip_map(driver.state()), "New project retained the old timeline")
    driver.project_job("save_document", path=str(work / "lifecycle-reopen-bridge.kdenlive"), overwrite=False)
    driver.project_job("open_project", path=str(base))
    state = driver.state()
    source = next((b for b in state["bin"] if b.get("name") == Path(context["fixture"]).name
                   or Path(b.get("resource", "")).name == Path(context["fixture"]).name), None)
    require(source is not None, "Reopened bin lost the original AV source")
    driver.wait_media(source["id"])
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        state = driver.state()
        if all(b["ready"] for b in state["bin"]):
            break
        time.sleep(.03)
    require(signature(state) == expected, f"Saved/reopened source ranges differ: {signature(state)} vs {expected}")
    visual_candidates = [(t, c) for t in state["tracks"] if not t["audio"] for c in t["clips"] if c["binId"] == source["id"]]
    require(len(visual_candidates) == 1, "Cannot identify the reopened ordinary video clip")
    visual = visual_candidates[0][1]["id"]
    driver.mutate("trim_clip", clipId=visual, durationFrames=49, edge="right")
    driver.check_clip(visual, durationFrames=49, inFrame=0, outFrame=48)
    driver.mutate("undo")
    require(signature(driver.state()) == expected, "MCP could not edit/undo an existing saved project's ordinary media")
    copied = driver.mutate("save_project", path=str(copy))
    require(copied.get("persisted") and copy.stat().st_size > 0, "Existing-project save copy did not persist")
    require(Path(copied["state"]["projectPath"]).resolve() == base.resolve(), "Saving a copy renamed the live document")
    require(digest(base) == saved_hash, "Save copy changed the original saved project")
    root = ET.parse(copy).getroot()
    profile = root.find("profile")
    require(profile is not None and int(profile.attrib["width"]) == state["width"] and int(profile.attrib["height"]) == state["height"],
            "Saved native XML profile differs from readback")
    if "titleBinId" in context:
        require(any(p.attrib.get("name") == "xmldata" and "Kdenlive native MCP" in (p.text or "") for p in root.iter("property")),
                "Saved title is missing native editable text")
        require(any(p.attrib.get("name") in ("kdenlive_id", "kdenlive:id") and p.text == "brightness" for p in root.iter("property")),
                "Saved native effect is missing")
        subtitles = driver.call("get_subtitles")["subtitles"]
        require(any(s["text"] == "Frame accurate subtitles" and s["startFrame"] == 5 and s["endFrame"] == 45 for s in subtitles),
                "Reopened native subtitles differ")
    previews = []
    for frame, name in ((10, "preview-red.png"), (35, "preview-blue.png")):
        preview = driver.mutate("extract_preview", path=str(work / name), frame=frame, width=160, height=128)
        require(Path(preview["path"]).is_file() and Path(preview["path"]).stat().st_size > 0, "Native preview is missing")
        require(preview["frame"] == frame and (preview["width"], preview["height"]) == (160, 128), f"Native preview geometry/range differs: {preview}")
        previews.append({k: preview[k] for k in ("path", "frame", "width", "height")})
    driver.mutate("control_playback", action="seek", frame=10)
    driver.mutate("control_playback", action="pause")
    driver.mutate("control_playback", action="set_zone", inFrame=0, outFrame=49)
    preset = choose_h264_preset(driver)
    started = driver.mutate("start_render", path=str(video), presetName=preset["id"], inFrame=0, outFrame=49)
    rendered = driver.wait_job("render_status", started["job"]["jobId"], timeout=args.render_timeout)
    require(rendered["job"]["status"] == "completed" and video.stat().st_size > 0, f"Native export did not complete: {rendered}")
    inspection = inspect_video(args, video, work, env, owned, driver.state())
    context.update(video=visual, binId=source["id"], finalProject=str(copy), finalVideo=str(video))
    return {"passed": True, "normalSave": str(base), "savedProjectPreserved": digest(base) == saved_hash,
            "editedReopenedProject": str(copy), "editableTitleVerified": "titleBinId" in context, "previews": previews,
            "render": rendered["job"], "inspection": inspection, "exactReopenedSignature": expected}

def sequence_checks(driver):
    state = driver.state()
    original_id, original_signature = state["sequenceId"], signature(state)
    initial = driver.call("list_sequences")["sequences"]
    created = driver.mutate("create_sequence", name="MCP owned temporary sequence", audioTracks=1, videoTracks=1)
    sequence = created["sequenceId"]
    require(sequence != original_id and driver.state()["sequenceId"] == sequence, "Native sequence was not created/activated")
    driver.mutate("rename_sequence", sequenceId=sequence, name="MCP owned sequence renamed")
    sequences = driver.call("list_sequences")["sequences"]
    require(any(s["sequenceId"] == sequence and s["name"] == "MCP owned sequence renamed" for s in sequences), "Native sequence rename missing")
    driver.mutate("switch_sequence", sequenceId=original_id)
    require(driver.state()["sequenceId"] == original_id and signature(driver.state()) == original_signature,
            "Switching sequences changed original content")
    # This driver owns every sequence/history entry in this separately launched test instance.
    deleted = driver.mutate("delete_sequence", sequenceId=sequence, acknowledgeHistoryReset=True)
    final = driver.state()
    remaining = driver.call("list_sequences")["sequences"]
    require(deleted.get("historyReset") is True and deleted.get("undoable") is False, "Permanent deletion did not report its native history consequence")
    require(final["undoCount"] == 0 and not final["canUndo"], "Native sequence deletion did not actually reset undo history")
    require(len(remaining) == len(initial) and not any(s["sequenceId"] == sequence for s in remaining), "Owned sequence was not removed")
    require(final["sequenceId"] == original_id and signature(final) == original_signature, "Deleting temporary sequence changed retained content")
    return {"passed": True, "deletedOwnedSequenceId": sequence, "retainedSequenceId": original_id,
            "historyReset": True, "finalUndoCount": final["undoCount"]}

def dialog_checks(driver):
    original = signature(driver.state())
    actions = driver.call("list_actions", {"query": "project"})["actions"]
    action = next((a for a in actions if a["id"] == "project_settings" and a["enabled"]), None)
    require(action is not None, "Discovered native Project Settings action is unavailable")
    ui = driver.stable_ui()
    require(not ui["needsUserInput"], "Unexpected dialog before planned round trip; full UI retained in diagnostics")
    accepted = driver.call("trigger_action", {"expectedUi": ui["uiToken"], "actionId": action["id"]})
    deadline = time.monotonic() + 20
    dialog = None
    while time.monotonic() < deadline:
        ui = driver.call("get_ui")["ui"]
        if ui["needsUserInput"]:
            dialog = next((c for c in ui["controls"] if c["id"] == ui["modalId"] and c.get("dialog")), None)
            require(dialog is not None and dialog["class"].endswith("ProjectSettings"),
                    f"Unexpected native dialog; it was not dismissed: {ui}")
            break
        status = driver.call("ui_job_status", {"jobId": accepted["jobId"]})["job"]
        require(status["status"] != "failed", f"Native QAction failed before opening the planned dialog: {status}")
        time.sleep(.03)
    require(dialog is not None, "Planned native Project Settings dialog did not appear")
    running = driver.call("ui_job_status", {"jobId": accepted["jobId"]})["job"]
    require(running["needsUserInput"] and running["status"] == "running", f"Native action completion was misreported while modal: {running}")
    # Let native deferred focus/layout initialization settle before preparing
    # one cancellation. A rejected stale request is never replayed.
    ui = driver.stable_ui()
    rejected = driver.call("activate_ui_control", {"expectedUi": ui["uiToken"], "controlId": dialog["id"], "operation": "reject_dialog"})
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        original_job = driver.call("ui_job_status", {"jobId": accepted["jobId"]})["job"]
        reject_job = driver.call("ui_job_status", {"jobId": rejected["jobId"]})["job"]
        require(original_job["status"] != "failed" and reject_job["status"] != "failed", f"Native dialog control failed: {original_job}, {reject_job}")
        if original_job["status"] == "returned" and reject_job["status"] == "returned":
            ui = driver.call("get_ui")["ui"]
            require(not ui["needsUserInput"], f"Unexpected dialog after rejection: {ui}")
            require(signature(driver.state()) == original, "Rejecting Project Settings changed timeline content")
            return {"passed": True, "actionId": action["id"], "dialogClass": dialog["class"],
                    "handlerReturned": True, "dialogAbsent": True, "timelinePreserved": True}
        time.sleep(.03)
    raise SmokeFailure("Planned dialog rejection did not complete")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("app", "proxy", "renderer", "ffmpeg", "ffprobe", "work-dir"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--python", type=Path, default=Path(r"C:\Users\USER\AppData\Local\Python\pythoncore-3.14-64\python.exe"))
    parser.add_argument("--phase", action="append", choices=("all", "subtitle_languages", "subtitle_ass", "monitors", "state") + PHASES,
                        help="Repeat for selected independent checks. Default: all.")
    parser.add_argument("--audio-backend", choices=("sdl2_audio", "rtaudio"), default="sdl2_audio",
                        help="Native backend in this owned test configuration only; record each backend separately.")
    parser.add_argument("--timeout", type=float, default=45)
    parser.add_argument("--startup-timeout", type=float, default=90)
    parser.add_argument("--render-timeout", type=float, default=180)
    args = parser.parse_args()
    if os.name != "nt":
        parser.error("This owned GUI driver requires Windows.")
    for name in ("timeout", "startup_timeout", "render_timeout"):
        if not math.isfinite(getattr(args, name)) or getattr(args, name) <= 0:
            parser.error(f"--{name.replace('_', '-')} must be positive and finite")
    if args.timeout > 120:
        parser.error("--timeout cannot exceed the proxy's 120-second deadline")
    if args.phase and "all" in args.phase and len(args.phase) > 1:
        parser.error("--phase all cannot be combined with another phase")
    requested = set(PHASES if not args.phase or args.phase == ["all"] else args.phase)
    requested.add("catalogs")
    for independent in ("subtitle_languages", "subtitle_ass", "monitors"):
        if independent in requested and requested != {"catalogs", independent}:
            parser.error(f"--phase {independent} runs independently in its fresh owned project")
    for name in ("app", "proxy", "renderer", "ffmpeg", "ffprobe", "python"):
        setattr(args, name, getattr(args, name).resolve(strict=True))
    work = args.work_dir.resolve() / ("gui-" + uuid.uuid4().hex[:12])
    work.mkdir(parents=True, exist_ok=False)
    config = work / "kdenlive-completion.rc"
    seed_config(config, args.renderer, args.ffmpeg)
    melt = args.app.with_name("melt.exe")
    if not melt.is_file():
        melt = args.renderer.with_name("melt.exe")
    require(melt.is_file(), "The selected app/dependency prefix has no native melt.exe")
    content = config.read_text(encoding="utf-8").replace("[env]\n", f"[env]\nmeltpath={melt.as_posix()}\n", 1)
    content = content.replace("[sdl]\n", f"[sdl]\naudiobackend={args.audio_backend}\n", 1)
    config.write_text(content, encoding="utf-8")
    env = os.environ.copy()
    env["PATH"] = str(args.app.parent) + os.pathsep + str(args.renderer.parent) + os.pathsep + env.get("PATH", "")
    dependency_prefix = args.renderer.parent.parent
    native_repository = dependency_prefix / "lib" / "mlt"
    native_data = dependency_prefix / "share" / "mlt"
    require(native_repository.is_dir() and (native_data / "profiles").is_dir(), "Selected native dependency prefix is incomplete")
    env["MLT_REPOSITORY"] = str(native_repository)
    env["MLT_PREFIX"] = str(dependency_prefix)
    env["MLT_DATA"] = str(native_data)
    env["MLT_PROFILES_PATH"] = str(native_data / "profiles")
    env["SDL_AUDIODRIVER"] = "dummy"
    env["QT_FORCE_STDERR_LOGGING"] = "1"
    env["QT_QPA_PLATFORM"] = "windows"
    for name, folder in (("TEMP", "temp"), ("TMP", "temp"), ("APPDATA", "appdata"), ("LOCALAPPDATA", "localappdata"),
                         ("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_DATA_HOME", "data")):
        path = work / folder
        path.mkdir(exist_ok=True)
        env[name] = str(path)
    endpoint = "kdenlive-complete-" + uuid.uuid4().hex
    report = {"status": "failed", "workDirectory": str(work), "config": str(config), "socket": endpoint,
              "audioBackend": args.audio_backend, "audioDriver": "SDL dummy for isolated test; RtAudio uses native device selection",
              "requestedPhases": [p for p in PHASES + ("subtitle_languages", "subtitle_ass", "monitors", "state") if p in requested], "completedPhases": [], "checks": {},
              "coverageMeaning": "Only executed checks are validated; discovery is not proof of every feature completing.",
              "qtLocationScope": "Explicit settings/cache/temp are task-specific. Auxiliary Qt known-folder data may use real Windows locations."}
    receipts, context = [], {}
    driver = app = proxy = None
    gui_log = proxy_log = None
    owned = OwnedJob()
    try:
        gui_log = (work / "gui.log").open("xb")
        app = subprocess.Popen([str(args.app), "--no-welcome", "--config", str(config), "--mcp-socket", endpoint],
                               stdin=subprocess.DEVNULL, stdout=gui_log, stderr=gui_log, env=env, **hidden_options())
        owned.attach(app)
        wait_for_pipe(endpoint, app, args.startup_timeout)
        proxy_log = (work / "proxy.log").open("xb")
        proxy = subprocess.Popen([str(args.python), "-B", str(args.proxy), "--socket", endpoint, "--timeout", str(args.timeout)],
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=proxy_log, env=env, **hidden_options())
        owned.attach(proxy)
        client = McpClient(proxy, args.timeout + 2, receipts)
        initialized = client.request("initialize", {"protocolVersion": "2025-11-25", "capabilities": {},
            "clientInfo": {"name": "kdenlive-completion-gui-regression", "version": "1"}})
        require(initialized.get("protocolVersion") == "2025-11-25", "Unexpected negotiated protocol")
        client.notify("notifications/initialized")
        names = {t["name"] for t in client.request("tools/list")["tools"]}
        required = {"get_info", "get_state", "get_capabilities", "list_actions", "get_ui", "new_project", "open_project", "save_document",
                    "move_clip", "cut_clip", "trim_clip", "duplicate_clip", "delete_item", "edit_effect", "set_effect_keyframes",
                    "create_title", "edit_subtitle", "extract_preview", "start_render", "render_status", "delete_sequence"}
        require(required <= names, f"Required expanded tools are missing: {sorted(required - names)}")
        driver = Driver(client, report)
        info = driver.call("get_info")
        require(info["processId"] == str(app.pid), "MCP endpoint belongs to a different process")
        report["applicationProcessId"] = app.pid
        report["prototypeVersion"] = info.get("prototypeVersion")
        deadline = time.monotonic() + args.startup_timeout
        while time.monotonic() < deadline:
            initial = driver.call("get_state")["state"]
            if initial.get("ready"):
                break
            time.sleep(.05)
        require(initial.get("ready") and not initial["projectPath"] and not clip_map(initial), f"Owned instance is not fresh and unsaved: {initial}")
        driver.phase("catalogs", lambda: catalogs(driver, names))
        report["loadedModules"] = loaded_module_provenance(app.pid)
        if "monitors" in requested:
            spec = importlib.util.spec_from_file_location("monitor_gui_regressions", Path(__file__).with_name("monitor_gui_regressions.py"))
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            fixture = build_fixture(args, work, env, owned)
            def monitor_checks():
                basic = module.verify_source_monitor(driver.call, fixture, work)
                context_spec = importlib.util.spec_from_file_location("monitor_action_context_gui", Path(__file__).with_name("monitor-context-staged") / "monitor_action_context_gui.py")
                context_module = importlib.util.module_from_spec(context_spec)
                context_spec.loader.exec_module(context_module)
                return {"basic": basic, "actionContext": context_module.verify_monitor_action_context(driver, basic)}
            driver.phase("monitors", monitor_checks)
        if "subtitle_languages" in requested:
            spec = importlib.util.spec_from_file_location("subtitle_language_gui_regressions", Path(__file__).with_name("subtitle_language_gui_regressions.py"))
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            driver.phase("subtitle_languages", lambda: module.verify_subtitle_languages(driver, work))
        if "subtitle_ass" in requested:
            spec = importlib.util.spec_from_file_location("subtitle_ass_gui_regressions", Path(__file__).with_name("subtitle_ass_gui_regressions.py"))
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            driver.phase("subtitle_ass", lambda: module.verify_subtitle_ass(driver, work))
        if "profile" in requested:
            driver.phase("profile", lambda: initial_profile(driver))
        needs_assembly = bool(requested & {"timeline", "effects", "lifecycle", "sequences", "state"})
        if needs_assembly:
            # Preserve the owned startup document/profile through normal native
            # saving before replacement; Kdenlive starts empty projects modified.
            driver.project_job("save_document", path=str(work / "initial-owned-project.kdenlive"), overwrite=False)
            fixture = build_fixture(args, work, env, owned)
            context = setup_project(driver, fixture)
            report["assemblySetup"] = context.copy()
        if "state" in requested:
            spec = importlib.util.spec_from_file_location("state_round2_gui", Path(__file__).with_name("r39-state") / "state_round2_gui.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            driver.phase("state", lambda: module.verify_state_view_and_notes(driver))
        if "timeline" in requested:
            driver.phase("timeline", lambda: timeline_checks(driver, context))
        if "effects" in requested:
            driver.phase("effects", lambda: effects_checks(driver, context))
        if "lifecycle" in requested:
            driver.phase("lifecycle", lambda: lifecycle_checks(driver, context, args, work, env, owned))
        if "sequences" in requested:
            driver.phase("sequences", lambda: sequence_checks(driver))
        if "dialogs" in requested:
            driver.phase("dialogs", lambda: dialog_checks(driver))
        report["finalState"] = driver.state()
        if context.get("fixture"):
            require(digest(context["fixture"]) == context["fixtureSha256"], "Generated source fixture was modified by editing/export")
            report["sourceFixtureUnchanged"] = True
        if context.get("finalProject"):
            report["finalProject"] = context["finalProject"]
            report["finalVideo"] = context["finalVideo"]
            report["projectSha256"] = digest(context["finalProject"])
            report["videoSha256"] = digest(context["finalVideo"])
        proxy.stdin.close()
        proxy.wait(timeout=10)
        require(proxy.returncode == 0, "Native stdio proxy did not finish cleanly")
        stop_owned(app)
        if context.get("finalProject"):
            verify_log = work / "native-file-verification.log"
            run_logged([str(args.app), "--config", str(config), "--verify-file", context["finalProject"]], verify_log, env, owned, 90)
            require("SUCCESS: Project file is valid:" in verify_log.read_text(encoding="utf-8", errors="replace"),
                    "Native saved-file consistency check did not confirm success")
            report["nativeSavedFileVerification"] = "passed"
        report["status"] = "passed"
        print(json.dumps({"status": "passed", "phases": report["completedPhases"], "report": str(work / "completion-report.json"),
                          "project": context.get("finalProject"), "video": context.get("finalVideo")}), flush=True)
        return 0
    except Exception as error:
        report["error"] = str(error)
        if driver:
            report["lastState"] = driver.last_state
            report["lastUi"] = driver.last_ui
        print(f"Integration check failed; no mutation was replayed: {error}\nDiagnostics: {work}", file=sys.stderr, flush=True)
        return 1
    finally:
        stop_owned(proxy)
        stop_owned(app)
        owned.close()
        if gui_log:
            gui_log.close()
        if proxy_log:
            proxy_log.close()
        (work / "mcp-receipts.json").write_text(json.dumps(receipts, ensure_ascii=True, indent=2), encoding="utf-8")
        (work / "completion-report.json").write_text(json.dumps(report, ensure_ascii=True, indent=2), encoding="utf-8")

if __name__ == "__main__":
    raise SystemExit(main())
