from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpeffects.cpp')
s=p.read_text(encoding='utf-8')
needle='''                if (!candidate(layer, start, end)) return false;
            }
        }
    }
    if (candidateCount == 0)'''
replacement='''                if (!candidate(layer, start, end)) return false;
            }
            // Native turn advances even for a line in an unknown section. A
            // later header is recognized only after an actual blank separator.
            turn = true;
        }
    }
    if (candidateCount == 0)'''
assert needle in s
s=s.replace(needle,replacement,1)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpsubtitle_format_cases.inc')
s=p.read_text(encoding='utf-8')
needle='''        {QStringLiteral("columns.ass"), "[Events]\\nFormat: Layer, End, Start, Style, Name, MarginL, MarginR, MarginV, Effect, Text\\nDialogue: 0,0:00:00.20,0:00:01.20,Default,,0,0,0,,Reordered\\n"}};'''
replacement='''        {QStringLiteral("columns.ass"), "[Events]\\nFormat: Layer, End, Start, Style, Name, MarginL, MarginR, MarginV, Effect, Text\\nDialogue: 0,0:00:00.20,0:00:01.20,Default,,0,0,0,,Reordered\\n"},
        {QStringLiteral("missing-section-separator.ass"), "Unknown preamble\\n[Events]\\nDialogue: 0,0:00:00.20,0:00:01.20,Default,,0,0,0,,Native will not enter this section\\n"}};'''
assert needle in s
s=s.replace(needle,replacement,1)
p.write_text(s,encoding='utf-8')
print('Matched native unknown-section turn advancement; source frozen.')
