from pathlib import Path
p=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\mcplifecycle.advanced.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('#include <QDir>', '#include <QDir>\n#include <QDirIterator>\n#include <functional>\n#include <memory>')
start=s.index('bool verifyRenderOutputs(')
end=s.index('QStringList stepArgs',start)
code=r'''class RenderOutputVerifier : public QObject
{
public:
    using Completion = std::function<void(bool, const QJsonArray &, const QString &)>;
    RenderOutputVerifier(const QJsonObject &job, Completion completion, QObject *parent)
        : QObject(parent)
        , m_stage(job.value(key("stagingDir")).toString())
        , m_target(job.value(key("path")).toString())
        , m_directoryOutput(job.value(key("outputKind")) == key("directory"))
        , m_planned(job.value(key("plannedOutputs")).toArray())
        , m_completion(std::move(completion))
    {
        m_profile.set_explicit(1);
        m_profile.set_frame_rate(job.value(key("frameRateNumerator")).toInt(), job.value(key("frameRateDenominator")).toInt());
    }
    void start() { QTimer::singleShot(0, this, [this] { advance(); }); }
    void stop()
    {
        m_stopped = true;
        deleteLater();
    }
private:
    void finish(bool ok, const QString &message = {})
    {
        if (m_stopped) return;
        m_stopped = true;
        m_completion(ok, m_outputs, message);
        deleteLater();
    }
    bool beginOutput()
    {
        m_output = m_planned[m_index].toObject();
        const QString path = m_output.value(key("stagedPath")).toString();
        if (!ownedLeafPath(path, m_stage)) {
            finish(false, key("Native output escaped the owned staging directory."));
            return false;
        }
        m_bytes = 0;
        m_count = 0;
        m_first = std::numeric_limits<int>::max();
        m_last = -1;
        m_numbers.clear();
        if (m_output.value(key("kind")) == key("imageSequence")) {
            const QString leaf = m_output.value(key("fileName")).toString();
            static const QRegularExpression counter(QStringLiteral("%[0-9]*d"));
            const auto match = counter.match(leaf);
            if (!match.hasMatch() || counter.match(leaf, match.capturedEnd()).hasMatch()) {
                finish(false, key("Native image sequence has an invalid counter pattern."));
                return false;
            }
            m_numbered = QRegularExpression(QRegularExpression::anchoredPattern(QRegularExpression::escape(leaf.left(match.capturedStart())) +
                                                  QStringLiteral("([0-9]+)") + QRegularExpression::escape(leaf.mid(match.capturedEnd()))));
            m_files = std::make_unique<QDirIterator>(m_stage, QDir::AllEntries | QDir::Hidden | QDir::NoDotAndDotDot);
        }
        return true;
    }
    void completeOutput()
    {
        const QString leaf = m_output.value(key("fileName")).toString();
        m_output.insert(key("path"), m_directoryOutput ? QDir(m_target).absoluteFilePath(leaf) : m_target);
        m_output.insert(key("bytes"), m_bytes);
        m_output.remove(key("stagedPath"));
        m_output.remove(key("subtitlePath"));
        m_outputs.append(m_output);
        m_output = {};
        m_files.reset();
        ++m_index;
    }
    bool verifyMedia()
    {
        const QString path = m_output.value(key("stagedPath")).toString(), leaf = m_output.value(key("fileName")).toString();
        const QFileInfo file(path);
        if (!file.isFile() || file.isSymLink() || file.size() <= 0) {
            finish(false, key("Native renderer did not produce a nonempty ordinary media file."));
            return false;
        }
        int frames = 0;
        {
            Mlt::Producer rendered(m_profile, path.toUtf8().constData());
            if (rendered.is_valid()) frames = rendered.get_length();
        }
        const int expected = m_output.value(key("expectedFrameCount")).toInt();
        const int tolerance = m_output.value(key("audioOnly")).toBool() ? 1 : 0;
        if (qAbs(qint64(frames) - expected) > tolerance) {
            finish(false, key("Native rendered media duration does not match the requested frame range."));
            return false;
        }
        m_bytes = double(file.size());
        m_output.insert(key("frameCount"), frames);
        if (m_directoryOutput && QFileInfo(path).fileName() != leaf) {
            const QString normalized = QDir(m_stage).absoluteFilePath(leaf);
            // Only the owned raw unembedded video may be removed inside staging.
            if ((QFileInfo::exists(normalized) && !QFile::remove(normalized)) || !QFile::rename(path, normalized)) {
                finish(false, key("Cannot finalize an owned subtitle-muxed output in staging."));
                return false;
            }
        }
        m_keep.insert(leaf);
        completeOutput();
        return true;
    }
    bool verifyImage(const QFileInfo &file)
    {
        const auto match = m_numbered.match(file.fileName());
        if (!match.hasMatch()) return true;
        bool valid = false;
        const int number = match.captured(1).toInt(&valid);
        QImageReader reader(file.absoluteFilePath());
        if (!valid || m_numbers.contains(number) || !file.isFile() || file.isSymLink() || file.size() <= 0 || !reader.canRead() || !reader.size().isValid()) {
            finish(false, key("Native image sequence contains an unreadable, duplicate, or invalid frame."));
            return false;
        }
        if (++m_count > m_output.value(key("expectedFrameCount")).toInt()) {
            finish(false, key("Native image sequence contains more frames than requested."));
            return false;
        }
        m_first = qMin(m_first, number);
        m_last = qMax(m_last, number);
        m_numbers.insert(number);
        m_keep.insert(file.fileName());
        m_bytes += double(file.size());
        return true;
    }
    void advance()
    {
        // Bounded batches yield between local headers so UI/cancel stay responsive.
        for (int budget = 0; budget < 16 && !m_stopped; ++budget) {
            if (m_index < m_planned.size()) {
                if (m_output.isEmpty() && !beginOutput()) return;
                if (m_output.value(key("kind")) != key("imageSequence")) {
                    if (!verifyMedia()) return;
                    continue;
                }
                if (m_files->hasNext()) {
                    m_files->next();
                    if (!verifyImage(m_files->fileInfo())) return;
                    continue;
                }
                const int expected = m_output.value(key("expectedFrameCount")).toInt();
                if (m_count != expected || qint64(m_last) - m_first + 1 != expected) {
                    finish(false, key("Native image sequence frame count or numbering does not match the exact requested range."));
                    return;
                }
                m_output.insert(key("frameCount"), m_count);
                m_output.insert(key("firstNumber"), m_first);
                m_output.insert(key("lastNumber"), m_last);
                completeOutput();
            } else {
                if (!m_directoryOutput) { finish(true); return; }
                if (!m_files) m_files = std::make_unique<QDirIterator>(m_stage, QDir::AllEntries | QDir::Hidden | QDir::NoDotAndDotDot);
                if (!m_files->hasNext()) { finish(true); return; }
                m_files->next();
                const QFileInfo file = m_files->fileInfo();
                if (file.isSymLink() || !file.isFile() || (!m_keep.contains(file.fileName()) && !QFile::remove(file.absoluteFilePath()))) {
                    finish(false, key("Cannot clean the private export staging directory before publication."));
                    return;
                }
            }
        }
        if (!m_stopped) QTimer::singleShot(0, this, [this] { advance(); });
    }
    QString m_stage, m_target;
    bool m_directoryOutput{false}, m_stopped{false};
    QJsonArray m_planned, m_outputs;
    QJsonObject m_output;
    Completion m_completion;
    Mlt::Profile m_profile;
    std::unique_ptr<QDirIterator> m_files;
    QRegularExpression m_numbered;
    QSet<QString> m_keep;
    QSet<int> m_numbers;
    int m_index{0}, m_count{0}, m_first{0}, m_last{-1};
    double m_bytes{0};
};
void stopRenderVerification(QProcess *process)
{
    if (!process) return;
    for (auto *child : process->children())
        if (auto *verifier = dynamic_cast<RenderOutputVerifier *>(child)) verifier->stop();
}
'''
s=s[:start]+code+s[end:]
start=s.index('                QString verificationError;')
end=s.index('\n            }\n            m_renderProcesses.remove(id);',start)
code=r'''                job.insert(key("status"), key("verifying"));
                auto *verifier = new RenderOutputVerifier(job, [this, id, process](bool verified, const QJsonArray &outputs, const QString &message) {
                    if (!m_lifecycleJobs.contains(id) || m_lifecycleJobs[id].value(key("cancelRequested")).toBool()) return;
                    auto &completed = m_lifecycleJobs[id];
                    if (!verified) {
                        completed.insert(key("status"), key("failed"));
                        completed.insert(key("message"), message);
                        completed.insert(key("recoveryPath"), completed.value(key("stagingDir")));
                        removeRenderArtifacts(completed, false);
                    } else {
                        const QString target = completed.value(key("path")).toString();
                        const QString stage = completed.value(key("stagingDir")).toString();
                        const bool directoryOutput = completed.value(key("outputKind")) == key("directory");
                        const QString publish = directoryOutput ? stage : completed.value(key("plannedOutputs")).toArray().first().toObject().value(key("stagedPath")).toString();
                        const bool published = directoryOutput ? publishDirectory(publish, target) : QFile::rename(publish, target);
                        if (published) {
                            completed.insert(key("status"), key("completed"));
                            completed.insert(key("progress"), 100);
                            completed.insert(key("outputs"), outputs);
                            double bytes = 0;
                            for (const auto &output : outputs) bytes += output.toObject().value(key("bytes")).toDouble();
                            completed.insert(key("bytes"), bytes);
                            removeRenderArtifacts(completed, !directoryOutput);
                        } else {
                            completed.insert(key("status"), key("failed"));
                            completed.insert(key("message"), key("Rendering verified, but non-replacing publication failed. Completed staged outputs are retained."));
                            completed.insert(key("recoveryPath"), publish);
                            removeRenderArtifacts(completed, false);
                        }
                    }
                    m_renderProcesses.remove(id);
                    process->deleteLater();
                }, process);
                verifier->start();
                return;'''
s=s[:start]+code+s[end:]
s=s.replace('''        job.insert(key("cancelRequested"), true);''','''        stopRenderVerification(m_renderProcesses.value(id));
        job.insert(key("cancelRequested"), true);''',1)
s=s.replace('''            disconnect(process, nullptr, this, nullptr);''','''            stopRenderVerification(process);
            disconnect(process, nullptr, this, nullptr);''')
s=s.replace(''' : job.value(key("path")));''',''' : job.value(key("path")).toString());''')
p.write_text(s,encoding='utf-8')
print('Prepared incremental output verification')
