$ErrorActionPreference='Stop'
$taskRoot='C:\Users\USER\.codex\work\kdenlive-mcp-completion'
$craftPrefix='C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot'
$buildRoot=Join-Path $craftPrefix 'build\kde\kdemultimedia\kdenlive\work\build'
$env:CRAFT_PYTHON='C:\Users\USER\AppData\Local\Python\pythoncore-3.14-64\python.exe'
function Clear-Host {}
. (Join-Path $craftPrefix 'craft\craftenv.ps1')
Set-Location -LiteralPath $taskRoot
& cmake -S 'C:\Users\USER\Documents\kdenlive' -B $buildRoot '-DMlt7_DIR=C:/Users/USER/.codex/work/kdenlive-mcp-completion/r39-mlt-api/isolated-app-prefix/lib/cmake/Mlt7' *> (Join-Path $taskRoot 'completion-reconfigure-isolated-mlt.log')
$configExit=$LASTEXITCODE
Get-Content -LiteralPath (Join-Path $taskRoot 'completion-reconfigure-isolated-mlt.log') -Tail 22
exit $configExit
