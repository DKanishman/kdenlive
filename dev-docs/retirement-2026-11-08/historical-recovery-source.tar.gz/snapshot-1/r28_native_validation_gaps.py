from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\bin\model\subtitlemodel.cpp')
s=p.read_text(encoding='utf-8')
needle='''    if (!std::isfinite(fps) || fps <= 0 || !std::isfinite(multiplier) || multiplier <= 0 || expectedCount < -1)'''
replacement='''    if (!std::isfinite(fps) || fps <= 0 || !std::isfinite(startFramerate) || startFramerate <= 0 ||
        !std::isfinite(targetFramerate) || targetFramerate <= 0 || !std::isfinite(multiplier) || multiplier <= 0 || expectedCount < -1)'''
assert needle in s
s=s.replace(needle,replacement,1)
needle='''        const QString line = raw.simplified();
        if (line.isEmpty()) { turn = false; continue; }
        if (!turn) {
            QString compact = line;
            compact.remove(QLatin1Char(' '));'''
replacement='''        const QString line = raw.simplified();
        if (line.isEmpty()) { turn = false; continue; }
        QString compact = line;
        compact.remove(QLatin1Char(' '));
        const bool sectionHeader = line.startsWith(QLatin1Char('[')) && line.endsWith(QLatin1Char(']')) &&
                                   (compact.contains(QStringLiteral("ScriptInfo")) || compact.contains(QStringLiteral("KdenliveExtradata")) ||
                                    line.contains(QStringLiteral("Styles")) || line.contains(QStringLiteral("Fonts")) || line.contains(QStringLiteral("Events")));
        // The existing native section state changes only after a blank line.
        // Reject missing separators instead of swallowing a header (especially
        // Events inside Fonts) and committing a misleading metadata-only import.
        if (turn && sectionHeader) return rejected(QStringLiteral("ASS sections must be separated by a blank line."));
        if (!turn) {'''
assert needle in s
s=s.replace(needle,replacement,1)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpsubtitle_transaction_cases.inc')
s=p.read_text(encoding='utf-8')
needle='''        QByteArray(assTransactionFixture()).replace("Style: Accent,Arial,37.001", "Style: Accent,Arial,NaN"),
        assTransactionFixture() + QByteArray::fromHex("e282")};'''
replacement='''        QByteArray(assTransactionFixture()).replace("Style: Accent,Arial,37.001", "Style: Accent,Arial,NaN"),
        // These must fail even with expectedCount left at its GUI default -1.
        QByteArray(assTransactionFixture()).replace("\\n\\n[Events]", "\\n[Events]"),
        QByteArray(assTransactionFixture()).replace("\\n\\n[Kdenlive Extradata]", "\\n[Kdenlive Extradata]"),
        assTransactionFixture() + QByteArray::fromHex("e282")};'''
assert needle in s
s=s.replace(needle,replacement,1)
s+=r'''

TEST_CASE("Native ASS transactions reject each invalid individual frame rate before changing history", "[mcp][subtitle][ass-transaction][fps]")
{
    McpProject project;
    project.open();
    project.document->setDocumentProperty(QStringLiteral("documentid"), QString::number(QDateTime::currentMSecsSinceEpoch()));
    auto args = project.expected();
    args.insert(QStringLiteral("operation"), QStringLiteral("add"));
    args.insert(QStringLiteral("startFrame"), 2);
    args.insert(QStringLiteral("endFrame"), 8);
    args.insert(QStringLiteral("text"), QStringLiteral("FPS rejection redo"));
    const int id = project.success(QStringLiteral("edit_subtitle"), args).value(QStringLiteral("id")).toInt();
    const auto model = project.timeline->getSubtitleModel();
    REQUIRE(model);
    project.undoStack->undo();
    REQUIRE(project.undoStack->canRedo());
    QTemporaryDir directory;
    REQUIRE(directory.isValid());
    const QString path = assTransactionFile(directory, assTransactionFixture());
    const QByteArray before = nativeAssSnapshot(model, directory);
    const auto script = model->scriptInfo();
    const int index = project.undoStack->index(), count = project.undoStack->count();
    struct Rates { float source; float target; };
    const Rates invalid[] = {{0, 25}, {25, 0}, {-25, 25}, {25, -25}, {-25, -25},
                             {std::numeric_limits<float>::quiet_NaN(), 25}, {25, std::numeric_limits<float>::quiet_NaN()},
                             {std::numeric_limits<float>::infinity(), 25}, {25, std::numeric_limits<float>::infinity()}};
    for (const auto &rates : invalid) {
        CAPTURE(rates.source, rates.target);
        const auto result = model->importSubtitleWithUndo(path, 0, true, rates.source, rates.target);
        CHECK_FALSE(result.success);
        CHECK(result.importedCount == 0);
        CHECK(model->count() == 0);
        CHECK(model->scriptInfo() == script);
        CHECK(nativeAssSnapshot(model, directory) == before);
        CHECK(project.undoStack->index() == index);
        CHECK(project.undoStack->count() == count);
        CHECK(project.undoStack->canRedo());
        REQUIRE(project.timeline->checkConsistency());
    }
    project.undoStack->redo();
    CHECK(model->hasSubtitle(id));
    CHECK(model->getText(id) == QStringLiteral("FPS rejection redo"));
}
'''
p.write_text(s,encoding='utf-8')
print('Repaired individual FPS validation and native ASS header boundaries; added focused atomic regressions.')
