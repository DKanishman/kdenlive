from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpeffects.cpp')
s=p.read_text(encoding='utf-8')
needle='''        model->importSubtitle(validatedPath, offset, true, float(sourceFps), float(pCore->getCurrentFps()), QByteArrayLiteral("UTF-8"));
        if (model->count() - before != candidateCount)
            return failure(QStringLiteral("SUBTITLE_IMPORT_PARTIAL"),
                           QStringLiteral("The native parser imported a different event count; inspect the returned state before any retry."), snapshot());'''
replacement='''        const auto imported = model->importSubtitleWithUndo(validatedPath, offset, true, float(sourceFps), float(pCore->getCurrentFps()),
                                                            QByteArrayLiteral("UTF-8"), candidateCount);
        if (!imported.success)
            return failure(QStringLiteral("SUBTITLE_IMPORT_FAILED"), imported.error, snapshot());
        if (imported.importedCount != candidateCount || model->count() - before != imported.importedCount)
            return failure(QStringLiteral("SUBTITLE_IMPORT_FAILED"), QStringLiteral("The native subtitle transaction returned an inconsistent result."), snapshot());'''
assert needle in s
s=s.replace(needle,replacement,1)
p.write_text(s,encoding='utf-8')
print('MCP now uses checked native result/count API; metadata guard remains.')
