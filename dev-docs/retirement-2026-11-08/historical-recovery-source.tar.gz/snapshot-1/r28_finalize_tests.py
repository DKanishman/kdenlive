from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpsubtitle_format_cases.inc')
s=p.read_text(encoding='utf-8')
s=s.replace('Comment: 0,0:00:02.04,0:00:03.24,Accent,Actor,12,13,14,fx,Second"));','Comment: 0,00:00:02.04,00:00:03.24,Accent,Actor,12,13,14,fx,Second"));')
s+=r'''
TEST_CASE("Subtitle import bounds reject oversized files records and event counts atomically", "[mcp][subtitle][formats][bounds]")
{
    QTemporaryDir directory;
    REQUIRE(directory.isValid());
    QList<QPair<QString, QByteArray>> cases;
    cases.append({QStringLiteral("oversized.srt"), QByteArray(16 * 1024 * 1024 + 1, 'a')});
    cases.append({QStringLiteral("long-line.srt"), QByteArray("1\n00:00:00,200 --> 00:00:01,200\n") + QByteArray(65537, 'a') + "\n"});
    QByteArray many;
    for (int index = 0; index <= 10000; ++index) {
        const int seconds = index / 25, milliseconds = (index % 25) * 40;
        const QString start = QStringLiteral("00:%1:%2,%3").arg(seconds / 60, 2, 10, QLatin1Char('0'))
                                  .arg(seconds % 60, 2, 10, QLatin1Char('0')).arg(milliseconds, 3, 10, QLatin1Char('0'));
        const int endSeconds = (index + 1) / 25, endMilliseconds = ((index + 1) % 25) * 40;
        const QString end = QStringLiteral("00:%1:%2,%3").arg(endSeconds / 60, 2, 10, QLatin1Char('0'))
                                .arg(endSeconds % 60, 2, 10, QLatin1Char('0')).arg(endMilliseconds, 3, 10, QLatin1Char('0'));
        many += QStringLiteral("%1\n%2 --> %3\nBounded cue\n\n").arg(index + 1).arg(start, end).toUtf8();
    }
    cases.append({QStringLiteral("event-count.srt"), many});
    for (const auto &entry : cases) {
        CAPTURE(entry.first);
        McpProject project;
        project.open();
        const QString path = subtitleFileFixture(directory, entry.first, entry.second);
        project.rejectWithoutChange(QStringLiteral("subtitle_file"), subtitleFileArgs(project, QStringLiteral("import"), path));
        CHECK_FALSE(project.timeline->hasSubtitleModel());
    }
}

TEST_CASE("ASS metadata mutations are explicit guarded limitations before native import", "[mcp][subtitle][formats][metadata]")
{
    QTemporaryDir directory;
    REQUIRE(directory.isValid());
    const QByteArray event = "[Events]\nDialogue: 0,0:00:00.20,0:00:01.20,Default,,0,0,0,,Plain\n";
    const QList<QByteArray> prefixes{
        "[Script Info]\nTitle: Changed script\n\n",
        "[V4+ Styles]\nStyle: Accent,Arial,37,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,2,2,10,11,12,1\n\n",
        "[Kdenlive Extradata]\nMaxLayer: 3\n\n",
        "[Kdenlive Extradata]\nDefaultStyles: Default\n\n",
        "[Fonts]\nfontname: unused.ttf\n!!!!\n\n"};
    int fixture = 0;
    for (const auto &prefix : prefixes) {
        McpProject project;
        project.open();
        const QString path = subtitleFileFixture(directory, QString::number(++fixture) + QStringLiteral(".ass"), prefix + event);
        const auto result = project.call(QStringLiteral("subtitle_file"), subtitleFileArgs(project, QStringLiteral("import"), path));
        REQUIRE(result.value(QStringLiteral("isError")).toBool());
        CHECK(result.value(QStringLiteral("structuredContent")).toObject().value(QStringLiteral("error")).toObject().value(QStringLiteral("code")).toString() ==
              QStringLiteral("ASS_METADATA_UNDO_UNSUPPORTED"));
        CHECK_FALSE(project.timeline->hasSubtitleModel());
        CHECK(project.undoStack->count() == 0);
    }
}
'''
p.write_text(s,encoding='utf-8')
print('Finalized subtitle format cases and bounds/metadata guards.')
