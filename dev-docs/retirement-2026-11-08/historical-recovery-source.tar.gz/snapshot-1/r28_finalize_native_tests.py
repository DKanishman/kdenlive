from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpsubtitle_transaction_cases.inc')
s=p.read_text(encoding='utf-8-sig')
s=s.replace("const QByteArray metadata = assTransactionFixture().split('[').isEmpty() ? QByteArray() : assTransactionFixture().left(assTransactionFixture().indexOf(\"[Events]\"));", "const QByteArray metadata = assTransactionFixture().left(assTransactionFixture().indexOf(\"[Events]\"));")
p.write_text(s,encoding='utf-8')
print('Added language/Save/Save As/native reopen regression without removing the MCP guard.')
