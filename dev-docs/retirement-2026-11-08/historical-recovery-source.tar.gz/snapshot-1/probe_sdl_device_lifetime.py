from pathlib import Path
import ctypes as C, importlib.util, json, os, subprocess, sys, time
root=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot')
if '--child' not in sys.argv:
    spec=importlib.util.spec_from_file_location('owned',prefix.parent/'live_smoke.py')
    owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
    job=owned.OwnedJob()
    try:
        for hold in [0,1]:
            log=root/f'sdl-device-lifetime-hold-{hold}.log'
            env=dict(os.environ,SDL_AUDIODRIVER='dummy',MLT_DATA=str(prefix/'share'/'mlt'),MLT_PROFILES_PATH=str(prefix/'share'/'mlt'/'profiles'))
            owned.run_logged([sys.executable,'-B',__file__,'--child',str(hold)],log,env,job,25)
            print(json.dumps({'hold_extra_audio_reference':bool(hold),'log':str(log),'status':'completed'}))
    finally:job.close()
    raise SystemExit
hold=int(sys.argv[-1]); dll_dirs=[os.add_dll_directory(str(prefix/'bin'))]
mlt=C.CDLL(str(prefix/'bin'/'mlt-7.dll')); sdl=C.CDLL(str(prefix/'bin'/'SDL2.dll'))
p=C.c_void_p; i=C.c_int; b=C.c_char_p
specs={'mlt_factory_init':([b],p),'mlt_factory_producer':([p,b,p],p),'mlt_factory_consumer':([p,b,p],p),'mlt_profile_init':([b],p),'mlt_consumer_properties':([p],p),'mlt_producer_service':([p],p),'mlt_properties_set_int':([p,b,i],i),'mlt_consumer_connect':([p,p],i),'mlt_consumer_start':([p],i),'mlt_consumer_stop':([p],i),'mlt_consumer_is_stopped':([p],i),'mlt_consumer_close':([p],None),'mlt_producer_close':([p],None),'mlt_profile_close':([p],None),'mlt_factory_close':([],None)}
for name,(args,result) in specs.items():fn=getattr(mlt,name);fn.argtypes=args;fn.restype=result
for name,args,result in [('SDL_InitSubSystem',[C.c_uint],i),('SDL_QuitSubSystem',[C.c_uint],None),('SDL_GetAudioDeviceStatus',[C.c_uint],i),('SDL_CloseAudioDevice',[C.c_uint],None),('SDL_GetCurrentAudioDriver',[],b)]:
    fn=getattr(sdl,name);fn.argtypes=args;fn.restype=result
assert mlt.mlt_factory_init(os.fsencode(prefix/'lib'/'mlt'))
profile=mlt.mlt_profile_init(b'dv_pal');assert profile
producer=mlt.mlt_factory_producer(profile,b'color',C.cast(C.c_char_p(b'red'),p));assert producer
consumer=mlt.mlt_factory_consumer(profile,b'sdl2_audio',None);assert consumer
props=mlt.mlt_consumer_properties(consumer)
for key,value in [(b'real_time',1),(b'channels',2),(b'frequency',48000),(b'video_off',1)]:assert mlt.mlt_properties_set_int(props,key,value)==0
assert mlt.mlt_consumer_connect(consumer,mlt.mlt_producer_service(producer))==0
if hold:assert sdl.SDL_InitSubSystem(0x10)==0
assert mlt.mlt_consumer_start(consumer)==0
deadline=time.monotonic()+8
while time.monotonic()<deadline:
    playing=[n for n in range(1,256) if sdl.SDL_GetAudioDeviceStatus(n)==1]
    if playing:break
    time.sleep(.05)
assert playing,'No playing dummy audio device was observed'
print(json.dumps({'phase':'before_stop','hold_extra_audio_reference':bool(hold),'driver':sdl.SDL_GetCurrentAudioDriver().decode(),'playing_device_ids':playing}),flush=True)
assert mlt.mlt_consumer_stop(consumer)==0
remaining=[n for n in playing if sdl.SDL_GetAudioDeviceStatus(n)!=0]
print(json.dumps({'phase':'after_stop','consumer_reports_stopped':bool(mlt.mlt_consumer_is_stopped(consumer)),'remaining_live_device_ids':remaining,'statuses':[sdl.SDL_GetAudioDeviceStatus(n) for n in remaining]}),flush=True)
# Diagnostic cleanup closes only devices owned by this child before freeing callback userdata.
for device in remaining:sdl.SDL_CloseAudioDevice(device)
mlt.mlt_consumer_close(consumer);mlt.mlt_producer_close(producer)
if hold:sdl.SDL_QuitSubSystem(0x10)
mlt.mlt_profile_close(profile);mlt.mlt_factory_close()
print(json.dumps({'phase':'clean_exit','device_lifetime_defect_observed':bool(remaining)}),flush=True)