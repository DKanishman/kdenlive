from pathlib import Path
work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpquick.cpp')
s=p.read_text(encoding='utf-8')
(work/'mcpquick.before-context-fix.cpp').write_text(s,encoding='utf-8')
old='''            if (!secret) {
                data.insert(k("valueHash"), hash(text));
                data.insert(k("truncated"), text.size() > 4096);
            }'''
new='''            if (!secret) {
                data.insert(k("valueHash"), hash(text));
                data.insert(k("truncated"), text.size() > 4096);
                if (control.kind == Kind::Input || control.kind == Kind::TextEdit) {
                    data.insert(k("cursorPosition"), object->property("cursorPosition").toInt());
                    data.insert(k("selectionStart"), object->property("selectionStart").toInt());
                    data.insert(k("selectionEnd"), object->property("selectionEnd").toInt());
                }
            }'''
assert old in s
s=s.replace(old,new)
old='''    std::function<void(QMenu *, QWidget *, int)> addMenu = [&](QMenu *menu, QWidget *host, int depth) {'''
new='''    std::function<void(QMenu *, QWidget *, int, const QVector<QPointer<QMenu>> &)> addMenu =
        [&](QMenu *menu, QWidget *host, int depth, const QVector<QPointer<QMenu>> &ancestors) {'''
assert old in s
s=s.replace(old,new)
s=s.replace('''        controls[id].listed = true;
        for (auto *action : menu->actions())''','''        controls[id].listed = true;
        QVector<QPointer<QMenu>> lineage{menu};
        lineage += ancestors;
        for (auto *action : menu->actions())''',1)
s=s.replace('''            control.menuOwners.append(menu);
            if (action->menu()) addMenu(action->menu(), host, depth + 1);''','''            control.menuOwners = lineage;
            if (action->menu()) addMenu(action->menu(), host, depth + 1, lineage);''',1)
s=s.replace('''if (action->menu()) addMenu(action->menu(), bar, 0);''','''if (action->menu()) addMenu(action->menu(), bar, 0, {});''',1)
old='''        if (auto *menu = qobject_cast<QMenu *>(widget); menu && menu->isVisible()) addMenu(menu, menu->parentWidget(), 0);
        if (auto *view'''
new='''    }
    // Discover menu-bar roots before visible submenus. Otherwise a submenu seen
    // first in allWidgets() would lose its active ancestor close chain.
    for (auto *widget : QApplication::allWidgets()) {
        if (auto *menu = qobject_cast<QMenu *>(widget); menu && menu->isVisible()) addMenu(menu, menu->parentWidget(), 0, {});
        if (auto *view'''
assert old in s
s=s.replace(old,new)
(work/'mcpquick.context-fix.cpp').write_text(s,encoding='utf-8')
print('Prepared Quick context fixes')
