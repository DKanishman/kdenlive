from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\bin\model\subtitlemodel.cpp')
s=p.read_text(encoding='utf-8')
helper=r'''namespace {
bool sameImportedStyle(const SubtitleStyle &a, const SubtitleStyle &b)
{
    return a.fontName() == b.fontName() && a.fontSize() == b.fontSize() && a.primaryColour() == b.primaryColour() &&
           a.secondaryColour() == b.secondaryColour() && a.outlineColour() == b.outlineColour() && a.backColour() == b.backColour() &&
           a.bold() == b.bold() && a.italic() == b.italic() && a.underline() == b.underline() && a.strikeOut() == b.strikeOut() &&
           a.scaleX() == b.scaleX() && a.scaleY() == b.scaleY() && a.spacing() == b.spacing() && a.angle() == b.angle() &&
           a.borderStyle() == b.borderStyle() && a.outline() == b.outline() && a.shadow() == b.shadow() && a.alignment() == b.alignment() &&
           a.marginL() == b.marginL() && a.marginR() == b.marginR() && a.marginV() == b.marginV() && a.encoding() == b.encoding();
}
bool validImportedAssStyle(const QString &line)
{
    if (!line.startsWith(QStringLiteral("Style:"))) return false;
    const auto fields = line.section(QLatin1Char(':'), 1).trimmed().split(QLatin1Char(','));
    if (fields.size() != 23 || fields.at(0).trimmed().isEmpty() || fields.at(1).trimmed().isEmpty()) return false;
    static const QRegularExpression color(QStringLiteral("^&H[0-9a-fA-F]{8}&?$"), QRegularExpression::CaseInsensitiveOption);
    for (int index = 2; index < fields.size(); ++index) {
        if (index >= 3 && index <= 6) {
            if (!color.match(fields.at(index).trimmed()).hasMatch()) return false;
        } else {
            bool valid = false;
            const double number = fields.at(index).toDouble(&valid);
            if (!valid || !std::isfinite(number)) return false;
            if ((index >= 7 && index <= 10) || index == 15 || index >= 18) {
                fields.at(index).toInt(&valid);
                if (!valid) return false;
            }
        }
    }
    return true;
}
bool importedAssTime(const QString &value, double fps, double multiplier, GenTime &time)
{
    static const QRegularExpression grammar(QStringLiteral("^([0-9]{1,3}):([0-5][0-9]):([0-5][0-9])\\.([0-9]{2})$"));
    const auto match = grammar.match(value);
    if (!match.hasMatch() || match.captured(1).toInt() > 596) return false;
    const qint64 milliseconds = ((match.captured(1).toLongLong() * 60 + match.captured(2).toLongLong()) * 60 + match.captured(3).toLongLong()) * 1000 +
                                match.captured(4).toLongLong() * 10;
    const double frames = double(milliseconds) * fps / (1000.0 * multiplier);
    const double outputMilliseconds = double(milliseconds) / multiplier;
    if (!std::isfinite(frames) || frames < 0 || frames >= std::numeric_limits<int>::max() ||
        outputMilliseconds >= std::numeric_limits<int>::max()) return false;
    time = SubtitleEvent::stringtoTime(value, fps, multiplier);
    return true;
}
} // namespace

SubtitleModel::ImportMetadata SubtitleModel::captureImportMetadata() const
{
    return {m_subtitleStyles, m_scriptInfo, m_defaultStyles, fontSection, m_maxLayer, m_activeSubLayer};
}

void SubtitleModel::restoreImportMetadata(const ImportMetadata &metadata)
{
    // Event maps are intentionally untouched. Older commands and language-state
    // exchanges retain their original event nodes and native IDs.
    m_subtitleStyles = metadata.styles;
    m_scriptInfo = metadata.script;
    m_defaultStyles = metadata.defaultStyles;
    fontSection = metadata.fonts;
    m_maxLayer = metadata.maxLayer;
    m_activeSubLayer = metadata.activeLayer;
}

SubtitleModel::ImportResult SubtitleModel::importAssSubtitle(const QString &filePath, int offset, float startFramerate, float targetFramerate,
                                                           const QByteArray &encoding, int expectedCount)
{
    const auto rejected = [](const QString &reason) { return ImportResult{false, 0, reason}; };
    if (isLocked()) return rejected(QStringLiteral("Subtitles are locked."));
    const double fps = pCore->getCurrentFps();
    const double multiplier = targetFramerate / startFramerate;
    if (!std::isfinite(fps) || fps <= 0 || !std::isfinite(multiplier) || multiplier <= 0 || expectedCount < -1)
        return rejected(QStringLiteral("Invalid subtitle frame rate or expected event count."));
    QFile file(filePath);
    constexpr qint64 maximumBytes = 16 * 1024 * 1024;
    if (!file.open(QIODevice::ReadOnly)) return rejected(file.errorString());
    const QByteArray bytes = file.read(maximumBytes + 1);
    if (file.error() != QFileDevice::NoError || !file.atEnd() || bytes.size() > maximumBytes)
        return rejected(QStringLiteral("ASS import exceeds the 16 MiB input limit or cannot be read."));
    auto codec = QStringConverter::encodingForName(encoding.constData());
    if (!codec) return rejected(QStringLiteral("The subtitle codec is not recognized by this Qt build."));
    if (bytes.startsWith(QByteArray::fromHex("efbbbf")) || bytes.startsWith(QByteArray::fromHex("fffe")) ||
        bytes.startsWith(QByteArray::fromHex("feff")) || bytes.startsWith(QByteArray::fromHex("0000feff"))) codec = QStringConverter::encodingForData(bytes);
    if (!codec) return rejected(QStringLiteral("Invalid ASS Unicode BOM."));
    QStringDecoder decoder(*codec, QStringConverter::Flag::Stateless);
    const QString contents = decoder.decode(bytes);
    if (decoder.hasError() || contents.contains(QChar::Null)) return rejected(QStringLiteral("ASS text decoding failed."));

    const auto before = std::make_shared<const ImportMetadata>(captureImportMetadata());
    ImportMetadata parsed = *before;
    struct ImportedEvent { int id; std::pair<int, GenTime> start; SubtitleEvent event; };
    std::vector<ImportedEvent> events;
    std::set<std::pair<int, int>> starts;
    QString section;
    bool turn = false;
    const auto growLayers = [&parsed](int layer) {
        parsed.maxLayer = qMax(parsed.maxLayer, layer);
        while (parsed.defaultStyles.size() <= parsed.maxLayer) parsed.defaultStyles.append(QStringLiteral("Default"));
    };
    const QString styleFormat = QStringLiteral("name,fontname,fontsize,primarycolour,secondarycolour,outlinecolour,backcolour,bold,italic,underline,"
                                               "strikeout,scalex,scaley,spacing,angle,borderstyle,outline,shadow,alignment,marginl,marginr,marginv,encoding");
    const QString eventFormat = QStringLiteral("layer,start,end,style,name,marginl,marginr,marginv,effect,text");
    for (const auto &raw : contents.split(QLatin1Char('\n'))) {
        if (raw.size() > 65536) return rejected(QStringLiteral("ASS records exceed the 65536 character limit."));
        const QString line = raw.simplified();
        if (line.isEmpty()) { turn = false; continue; }
        if (!turn) {
            QString compact = line;
            compact.remove(QLatin1Char(' '));
            if (compact.contains(QStringLiteral("ScriptInfo"))) section = QStringLiteral("script");
            else if (compact.contains(QStringLiteral("KdenliveExtradata"))) section = QStringLiteral("extra");
            else if (line.contains(QStringLiteral("Styles"))) section = QStringLiteral("styles");
            else if (line.contains(QStringLiteral("Fonts"))) section = QStringLiteral("fonts");
            else if (line.contains(QStringLiteral("Events"))) section = QStringLiteral("events");
            else section.clear();
            if (!section.isEmpty()) { turn = true; continue; }
        }
        if (section == QLatin1String("script")) {
            if (line.contains(QLatin1Char(':'))) parsed.script[line.section(QLatin1Char(':'), 0, 0).trimmed()] = line.section(QLatin1Char(':'), 1).trimmed();
        } else if (section == QLatin1String("extra")) {
            const auto fields = line.split(QLatin1Char(':'));
            if (fields.size() != 2) return rejected(QStringLiteral("Malformed ASS extra-data record."));
            if (fields.first().trimmed() == QLatin1String("MaxLayer")) {
                bool valid = false;
                const int layer = fields.last().trimmed().toInt(&valid);
                if (!valid || layer < 0 || layer > 50) return rejected(QStringLiteral("Invalid ASS maximum layer."));
                growLayers(layer);
            } else if (fields.first().trimmed() == QLatin1String("DefaultStyles")) {
                parsed.defaultStyles = fields.last().trimmed().split(QLatin1Char(','));
                if (parsed.defaultStyles.size() > 51) return rejected(QStringLiteral("Invalid ASS default-style count."));
                growLayers(parsed.maxLayer);
            }
        } else if (section == QLatin1String("styles")) {
            if (line.startsWith(QStringLiteral("Format:"))) {
                QString columns = line.section(QLatin1Char(':'), 1).toLower(); columns.remove(QLatin1Char(' '));
                if (columns != styleFormat) return rejected(QStringLiteral("Unsupported ASS style column order."));
            } else {
                if (!validImportedAssStyle(line)) return rejected(QStringLiteral("Malformed ASS style record."));
                const QString name = line.section(QLatin1Char(':'), 1).trimmed().section(QLatin1Char(','), 0, 0);
                parsed.styles[name] = SubtitleStyle(line);
            }
        } else if (section == QLatin1String("fonts")) {
            parsed.fonts += line + QLatin1Char('\n');
            if (parsed.fonts.size() > maximumBytes) return rejected(QStringLiteral("ASS embedded font data exceeds the input limit."));
        } else if (section == QLatin1String("events")) {
            if (line.startsWith(QStringLiteral("Format:"))) {
                QString columns = line.section(QLatin1Char(':'), 1).toLower(); columns.remove(QLatin1Char(' '));
                if (columns != eventFormat && columns != QString(eventFormat).replace(QStringLiteral(",name,"), QStringLiteral(",actor,")))
                    return rejected(QStringLiteral("Unsupported ASS event column order."));
                turn = true;
                continue;
            }
            if ((!line.startsWith(QStringLiteral("Dialogue:")) && !line.startsWith(QStringLiteral("Comment:"))) || line.contains(QStringLiteral("Format:")))
                return rejected(QStringLiteral("Malformed ASS event record."));
            const auto fields = line.section(QLatin1Char(':'), 1).split(QLatin1Char(','));
            if (fields.size() < 10) return rejected(QStringLiteral("Incomplete ASS event record."));
            bool valid = false;
            const int layer = fields.first().trimmed().toInt(&valid);
            GenTime first, last;
            if (!valid || layer < 0 || layer > 50 || !importedAssTime(fields.at(1), fps, multiplier, first) ||
                !importedAssTime(fields.at(2), fps, multiplier, last)) return rejected(QStringLiteral("Invalid ASS event layer or timestamp."));
            for (int index = 5; index <= 7; ++index) {
                fields.at(index).toInt(&valid);
                if (!valid) return rejected(QStringLiteral("Invalid ASS event margin."));
            }
            const qint64 firstFrame = qint64(first.frames(fps)) + offset, lastFrame = qint64(last.frames(fps)) + offset;
            if (firstFrame < 0 || lastFrame <= firstFrame || lastFrame >= std::numeric_limits<int>::max() ||
                GenTime(int(lastFrame), fps).ms() >= std::numeric_limits<int>::max())
                return rejected(QStringLiteral("Invalid ASS event range after frame conversion and offset."));
            const std::pair<int, int> key(layer, int(firstFrame));
            if (!starts.insert(key).second || getIdForStartPos(layer, GenTime(int(firstFrame), fps)) >= 0)
                return rejected(QStringLiteral("ASS events collide with an existing start in the same layer."));
            QString nativeLine = line;
            nativeLine.replace(QStringLiteral("\\N"), QStringLiteral("\n"));
            std::pair<int, GenTime> start;
            SubtitleEvent event(nativeLine, fps, multiplier, &start);
            if (event.endTime() == GenTime()) return rejected(QStringLiteral("The native ASS event constructor rejected a validated record."));
            start.second += GenTime(offset, fps);
            event.setEndTime(event.endTime() + GenTime(offset, fps));
            event.setText(event.text().trimmed());
            events.push_back({-1, start, event});
            if (events.size() > 10000) return rejected(QStringLiteral("ASS imports exceed the 10000 event limit."));
            growLayers(layer);
        }
        turn = true;
    }
    if (expectedCount >= 0 && int(events.size()) != expectedCount) return rejected(QStringLiteral("The ASS event count does not match the validated file."));
    bool sameStyles = parsed.styles.size() == before->styles.size();
    if (sameStyles) {
        for (const auto &entry : parsed.styles) {
            const auto old = before->styles.find(entry.first);
            if (old == before->styles.end() || !sameImportedStyle(old->second, entry.second)) { sameStyles = false; break; }
        }
    }
    const bool sameMetadata = sameStyles && parsed.script == before->script && parsed.fonts == before->fonts &&
                              parsed.defaultStyles == before->defaultStyles && parsed.maxLayer == before->maxLayer && parsed.activeLayer == before->activeLayer;
    if (events.empty() && sameMetadata) return rejected(QStringLiteral("The ASS file contains no new events or metadata changes."));
    // Only fully validated files allocate IDs. These are reused by every redo.
    for (auto &entry : events) entry.id = TimelineModel::getNextId();
    const auto imported = std::make_shared<const std::vector<ImportedEvent>>(std::move(events));
    const auto after = std::make_shared<const ImportMetadata>(std::move(parsed));
    const int language = pCore->currentDoc()->getSequenceProperty(m_timeline->uuid(), QStringLiteral("kdenlive:activeSubtitleIndex"), QStringLiteral("0")).toInt();
    const auto context = [this, language] {
        return !isLocked() && pCore->currentDoc() &&
               pCore->currentDoc()->getSequenceProperty(m_timeline->uuid(), QStringLiteral("kdenlive:activeSubtitleIndex"), QStringLiteral("0")).toInt() == language;
    };
    const auto notify = [this] {
        Q_EMIT m_timeline->maxSubLayerChanged();
        Q_EMIT activeSubLayerChanged();
        Q_EMIT modelChanged();
        pCore->refreshProjectMonitorOnce();
    };
    Fun redo = [this, imported, before, after, context, notify] {
        QWriteLocker locker(&m_lock);
        if (!context()) return false;
        for (const auto &entry : *imported)
            if (hasSubtitle(entry.id) || m_subtitleList.count(entry.start) > 0) return false;
        restoreImportMetadata(*after);
        size_t added = 0;
        for (const auto &entry : *imported) {
            if (!addSubtitle(entry.id, entry.start, entry.event, false, false)) {
                bool restored = true;
                while (added > 0) restored = removeSubtitle(imported->at(--added).id, false, false) && restored;
                restoreImportMetadata(*before);
                notify();
                Q_ASSERT(restored);
                return false;
            }
            ++added;
        }
        notify();
        return true;
    };
    Fun undo = [this, imported, before, after, context, notify] {
        QWriteLocker locker(&m_lock);
        if (!context()) return false;
        for (const auto &entry : *imported)
            if (!hasSubtitle(entry.id) || m_allSubtitles.at(entry.id) != entry.start || m_timeline->m_groups->isInGroup(entry.id)) return false;
        size_t removed = 0;
        for (auto entry = imported->rbegin(); entry != imported->rend(); ++entry) {
            if (!removeSubtitle(entry->id, false, false)) {
                bool restored = true;
                for (size_t index = imported->size() - removed; index < imported->size(); ++index) {
                    const auto &old = imported->at(index);
                    restored = addSubtitle(old.id, old.start, old.event, false, false) && restored;
                }
                restoreImportMetadata(*after);
                notify();
                Q_ASSERT(restored);
                return false;
            }
            ++removed;
        }
        restoreImportMetadata(*before);
        notify();
        return true;
    };
    if (!redo()) return rejected(QStringLiteral("The native ASS transaction failed before committing to history."));
    pCore->pushUndo(undo, redo, i18n("Edit subtitle"));
    return {true, int(imported->size()), {}};
}

'''
anchor='void SubtitleModel::importSubtitle(const QString &filePath'
assert 'bool sameImportedStyle' not in s
assert anchor in s
s=s.replace(anchor,helper+anchor,1)
p.write_text(s,encoding='utf-8')
print('Implemented deferred native ASS metadata/event transaction with stable IDs and one undo command.')
