from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpeffects.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('parsing and undo. Imports ASS, SRT, plain WebVTT cues and SBV; unsupported metadata is rejected.', 'parsing and undo. Imports event-only ASS, SRT, plain WebVTT cues and SBV; ASS metadata changes require native undo support.')
s=s.replace('    QSet<QPair<int, int>> starts;\n    // importSubtitle', '''    QSet<QPair<int, int>> starts;
    const auto unsupportedMetadata = [&] {
        code = QStringLiteral("ASS_METADATA_UNDO_UNSUPPORTED");
        reason = QStringLiteral("The native ASS importer cannot undo script/font/style/default-style/layer metadata changes. Import event-only ASS using existing layers and styles, or use the native GUI after reviewing that limitation.");
        return false;
    };
    // importSubtitle''',1)
s=s.replace('        const QPair<int, int> key(layer, int(first));', '''        if (format == QLatin1String("ass") && layer > (model ? model->getMaxLayer() : 0)) return unsupportedMetadata();
        const QPair<int, int> key(layer, int(first));''',1)
s=s.replace('                } else if (!validAssStyle(line)) return false;\n            } else if (section == QLatin1String("extra")) {', '''                } else {
                    if (!validAssStyle(line)) return false;
                    const QString name = line.section(QLatin1Char(':'), 1).trimmed().section(QLatin1Char(','), 0, 0);
                    if (!model) return unsupportedMetadata();
                    const auto &styles = model->getAllSubtitleStyles();
                    const auto old = styles.find(name);
                    if (old == styles.end() || old->second.toString(name) != SubtitleStyle(line).toString(name)) return unsupportedMetadata();
                }
            } else if (section == QLatin1String("script")) {
                if (line.contains(QLatin1Char(':'))) {
                    if (!model) return unsupportedMetadata();
                    const QString key = line.section(QLatin1Char(':'), 0, 0).trimmed();
                    const auto &script = model->scriptInfo();
                    const auto old = script.find(key);
                    if (old == script.end() || old->second != line.section(QLatin1Char(':'), 1).trimmed()) return unsupportedMetadata();
                }
            } else if (section == QLatin1String("fonts")) {
                // Font bytes and the complete default-style list have no public getters.
                return unsupportedMetadata();
            } else if (section == QLatin1String("extra")) {''',1)
s=s.replace('                    if (!valid || layer < 0 || layer > 50) return false;\n                } else if (fields.first().trimmed() == QLatin1String("DefaultStyles") && fields.last().split(QLatin1Char(\',\')).size() > 51) return false;', '''                    if (!valid || layer < 0 || layer > 50) return false;
                    if (layer > (model ? model->getMaxLayer() : 0)) return unsupportedMetadata();
                } else if (fields.first().trimmed() == QLatin1String("DefaultStyles")) {
                    if (fields.last().split(QLatin1Char(',')).size() > 51) return false;
                    return unsupportedMetadata();
                }''',1)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpsubtitle_format_cases.inc')
s=p.read_text(encoding='utf-8-sig')
s=s.replace('return QStringLiteral("[Script Info]\\nScriptType: v4.00+\\n\\n[Events]\\nFormat:', 'return QStringLiteral("[Events]\\nFormat:')
s=s.replace('Comment: 1,0:00:02.04','Comment: 0,0:00:02.04')
s=s.replace('model->getIdForStartPos(format == QLatin1String("ass") ? 1 : 0, GenTime(109, 25))','model->getIdForStartPos(0, GenTime(109, 25))')
s=s.replace('TEST_CASE("Native subtitle exports reimport ASS styles and plain SRT text without overwriting"','TEST_CASE("Native subtitle exports preserve ASS styles and reimport plain SRT without overwriting"')
needle='''        const QString source = subtitleFileFixture(directory, QStringLiteral("styled.ass"), contents.toUtf8());
        project.success'''
replacement='''        // Only identical pre-existing ASS metadata can currently be imported with
        // complete native undo. Native metadata-changing import needs a core fix.
        const auto seeded = project.timeline->createSubtitleModel();
        REQUIRE(seeded);
        const QString styleLine = contents.section(QLatin1Char('\\n'), 1, 1);
        seeded->setSubtitleStyle(QStringLiteral("Accent"), SubtitleStyle(styleLine));
        const QString source = subtitleFileFixture(directory, QStringLiteral("styled.ass"), contents.toUtf8());
        project.success'''
assert needle in s
s=s.replace(needle,replacement)
s=s.replace('''    for (const QString &path : {ass, srt}) {''','''    // Full native ASS exports contain a private default-style list. Keep their
    // import explicitly guarded until native import owns that metadata in undo.
    {
        McpProject project;
        project.open();
        const auto result = project.call(QStringLiteral("subtitle_file"), subtitleFileArgs(project, QStringLiteral("import"), ass));
        REQUIRE(result.value(QStringLiteral("isError")).toBool());
        CHECK(result.value(QStringLiteral("structuredContent")).toObject().value(QStringLiteral("error")).toObject().value(QStringLiteral("code")).toString() ==
              QStringLiteral("ASS_METADATA_UNDO_UNSUPPORTED"));
        CHECK_FALSE(project.timeline->hasSubtitleModel());
    }
    for (const QString &path : {srt}) {''',1)
start=s.index('        if (path == ass) {')
end=s.index('        REQUIRE(project.timeline->checkConsistency());',start)
s=s[:start]+s[end:]
s=s.replace('''        QFile exported(srt);''','''        QFile assExport(ass);
        REQUIRE(assExport.open(QIODevice::ReadOnly));
        const QByteArray assBytes = assExport.readAll();
        CHECK(assBytes.contains(style.toUtf8()));
        CHECK(assBytes.contains("Comment: 0,0:00:02.04,0:00:03.24,Accent,Actor,12,13,14,fx,Second"));
        QFile exported(srt);''',1)
p.write_text(s,encoding='utf-8')
print('Added explicit native ASS metadata undo guard and aligned tests.')
