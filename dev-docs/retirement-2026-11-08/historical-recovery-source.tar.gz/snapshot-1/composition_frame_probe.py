from pathlib import Path
import ctypes as C, os, json
from PIL import Image, ImageChops
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot');work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\composition-probe-e48c8eda33')
os.environ['PATH']=str(prefix/'bin')+os.pathsep+os.environ.get('PATH','');os.environ['MLT_REPOSITORY_DENY']='libmltqt:libmltglaxnimate';os.environ['MLT_DATA']=str(prefix/'share/mlt');os.environ['QT_QPA_PLATFORM']='offscreen'
handle=os.add_dll_directory(str(prefix/'bin')); lib=C.CDLL(str(prefix/'bin/mlt-7.dll'));ptr=C.c_void_p
spec={'mlt_factory_init':([C.c_char_p],ptr),'mlt_profile_init':([C.c_char_p],ptr),'mlt_factory_producer':([ptr,C.c_char_p,C.c_char_p],ptr),'mlt_producer_service':([ptr],ptr),'mlt_producer_seek':([ptr,C.c_int],C.c_int),'mlt_service_get_frame':([ptr,C.POINTER(ptr),C.c_int],C.c_int),'mlt_frame_get_image':([ptr,C.POINTER(ptr),C.POINTER(C.c_int),C.POINTER(C.c_int),C.POINTER(C.c_int),C.c_int],C.c_int),'mlt_frame_close':([ptr],None),'mlt_producer_close':([ptr],None),'mlt_profile_close':([ptr],None),'mlt_factory_close':([],None)}
for name,(args,result) in spec.items(): fn=getattr(lib,name);fn.argtypes=args;fn.restype=result
assert lib.mlt_factory_init(str(prefix/'lib/mlt').encode())
result=[]
try:
 for asset in ('slide','rotate','wipe'):
  for size in ((64,64),(720,576)):
   profile=lib.mlt_profile_init(b'dv_pal');producer=lib.mlt_factory_producer(profile,b'xml',str(work/(asset+'.mlt')).encode());assert producer
   images=[]
   try:
    for position in (0,19):
     lib.mlt_producer_seek(producer,position);frame=ptr();assert not lib.mlt_service_get_frame(lib.mlt_producer_service(producer),C.byref(frame),0)
     try:
      image=ptr();fmt=C.c_int(2);w=C.c_int(size[0]);h=C.c_int(size[1]);err=lib.mlt_frame_get_image(frame,C.byref(image),C.byref(fmt),C.byref(w),C.byref(h),0);assert not err,(asset,size,err)
      assert fmt.value==2,(asset,fmt.value);im=Image.frombytes('RGBA',(w.value,h.value),C.string_at(image,w.value*h.value*4));images.append(im.convert('RGB'));im.save(work/(asset+f'-direct-{size[0]}-{position}.png'))
     finally:lib.mlt_frame_close(frame)
    result.append({'asset':asset,'request':size,'actual':images[0].size,'diff':ImageChops.difference(*images).getbbox(),'first':images[0].getpixel((4,4)),'last':images[1].getpixel((4,4))})
   finally:lib.mlt_producer_close(producer);lib.mlt_profile_close(profile)
 print(json.dumps(result))
finally:lib.mlt_factory_close()
