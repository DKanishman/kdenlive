"""Owned actual-editor R39 checks. Invoke after a nonempty fixture is assembled.
The caller owns the driver/editor; this module never starts an app, writes files,
replays stale controls, or resolves unexpected dialogs. Native C++ tests cover
external saved-property changes independently of MCP revision increments.
"""
import time


def verify_state_view_and_notes(driver):
    def require(condition, detail):
        if not condition:
            raise AssertionError(detail)

    def wait_monitor(accepted):
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            result = driver.call("monitor_job_status", {"jobId": accepted["jobId"]})
            job = result["job"]
            if job["status"] == "completed":
                return result
            require(job["status"] not in ("failed", "interrupted", "needsUserAction"), job)
            time.sleep(.02)
        raise AssertionError("Owned project monitor did not complete")

    def control(operation, **fields):
        state = driver.state()
        monitor = driver.call("get_monitors")["monitors"]
        return wait_monitor(driver.call("control_monitor", {
            "expectedState": state["expectedState"], "expectedMonitor": monitor["expectedMonitor"],
            "monitor": "project", "operation": operation, **fields,
        }))

    def wait_ui(accepted):
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            result = driver.call("ui_job_status", {"jobId": accepted["jobId"]})
            job = result["job"]
            require(not job.get("needsUserInput"), job)
            if job["status"] == "returned":
                return result
            require(job["status"] not in ("failed", "canceled"), job)
            time.sleep(.02)
        raise AssertionError("Owned UI input did not return")

    require(driver.state()["durationFrames"] >= 25, "R39 GUI check requires a nonempty owned fixture of at least25 frames")
    control("activate")
    control("pause")
    baseline = driver.state()
    control("seek", frame=3)
    require(driver.state()["expectedState"] == baseline["expectedState"], "Paused project seek changed editing state")
    control("play")
    during = driver.state()
    time.sleep(.25)
    require(driver.state()["expectedState"] == during["expectedState"] == baseline["expectedState"],
            "Ordinary native project playback changed editing state")
    control("pause")
    require(driver.state()["expectedState"] == baseline["expectedState"], "Pausing project playback changed editing state")

    ui = driver.stable_ui()
    action = next((a for a in ui["actions"] if a["id"] == "raise_notes_widget" and a["enabled"]), None)
    require(action is not None, "Native Project Notes dock action is unavailable")
    wait_ui(driver.call("trigger_action", {"expectedUi": ui["uiToken"], "actionId": action["id"]}))
    observed = []
    for text in ("Owned R39 first notes", "Owned R39 second dirty notes"):
        ui = driver.stable_ui()
        notes = next((c for c in ui["controls"] if c["class"] == "NotesWidget" and c.get("writable") and c["enabled"]), None)
        require(notes is not None, "Actual native NotesWidget is not visible and writable")
        before = driver.state()
        wait_ui(driver.call("set_ui_value", {"expectedUi": ui["uiToken"], "controlId": notes["id"], "value": text}))
        state = driver.state()
        require(state["modified"] and text in state["documentNotes"], "Unsaved GUI notes were missing from native state")
        require((state["undoIndex"], state["undoCount"]) == (before["undoIndex"], before["undoCount"]),
                "Notes fixture unexpectedly changed native project undo history")
        observed.append(state["documentNotes"])
    require(observed[0] != observed[1], "Second already-dirty notes edit was not exposed")
    return {"passed": True, "pausedSeekTokenStable": True, "nativePlaybackTokenStable": True,
            "actualUnsavedNotesRead": True, "secondDirtyNotesRead": True,
            "notesUndoUnchanged": True, "scope": "Owned fixture only; native source tests separately cover saved view properties and raw graph telemetry"}
