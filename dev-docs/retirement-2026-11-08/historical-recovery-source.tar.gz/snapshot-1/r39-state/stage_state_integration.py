from pathlib import Path
import argparse,difflib,json,hashlib
ROOT=Path(r"C:\Users\USER\Documents\kdenlive")
WORK=Path(r"C:\Users\USER\.codex\work\kdenlive-mcp-completion\r39-state")

def once(s,old,new):
    if s.count(old)!=1: raise RuntimeError("Expected one integration anchor: "+old[:120])
    return s.replace(old,new,1)

def server(s):
    s=once(s,'#include "mcpserver.h"','#include "mcpserver.h"\n#include "mcpstate.h"')
    s=once(s,'#include "timeline2/model/timelineitemmodel.hpp"','#include "timeline2/model/timelineitemmodel.hpp"\n#include "timeline2/model/trackmodel.hpp"')
    s=once(s,'constexpr int MaxItems = 512;\n','')
    old='''    if (timeline->getClipsCount() + timeline->getCompositionsCount() > MaxItems || timeline->getTracksCount() > 64 || bin->getAllClipIds().size() > MaxItems) {
        state.insert(QStringLiteral("reason"), QStringLiteral("Project exceeds prototype state limits."));
        return state;
    }
'''
    s=once(s,old,'')
    begin=s.index('    QJsonArray tracks;\n',s.index('QJsonObject KdenliveMcpServer::snapshot()'))
    end=s.index('\n}\nQJsonObject KdenliveMcpServer::callTool',begin)
    replacement='''    QList<McpState::ImportedSource> imported;
    imported.reserve(m_imports.size());
    for (auto it = m_imports.cbegin(); it != m_imports.cend(); ++it)
        imported.append(McpState::ImportedSource{it.key(), it.value().path, it.value().clip});
    const McpState::ClipStateReader clipStateReader = [](const std::shared_ptr<TimelineItemModel> &model, int id) {
        QJsonObject result;
        if (model->getMixDuration(id) <= 0) return result;
        const auto track = model->getTrackById_const(model->getClipTrackId(id));
        const auto parameters = track->mixModel(id);
        if (!parameters || !parameters->getAsset()) return result;
        QJsonObject values;
        for (const auto &parameter : parameters->getAllParameters()) {
            const char *raw = parameters->getAsset()->get(parameter.first.toUtf8().constData());
            values.insert(parameter.first, QString::fromUtf8(raw ? raw : ""));
        }
        const auto binding = track->getMixTracks(id);
        result.insert(QStringLiteral("mix"), QJsonObject{{QStringLiteral("assetId"), parameters->getAssetId()}, {QStringLiteral("parameters"), values},
                                                          {QStringLiteral("cutFrame"), model->getMixCutPos(id)},
                                                          {QStringLiteral("aTrack"), binding.first}, {QStringLiteral("bTrack"), binding.second},
                                                          {QStringLiteral("inFrame"), parameters->getAsset()->get_int("in")},
                                                          {QStringLiteral("outFrame"), parameters->getAsset()->get_int("out")}});
        return result;
    };
    return McpState::snapshot(this, state, timeline, bin, document, imported, clipStateReader);'''
    s=s[:begin]+replacement+s[end:]
    s=once(s,'    return result;\n}\nKdenliveMcpServer::KdenliveMcpServer',
             '    for (const auto &entry : McpState::toolCatalog()) result.append(entry);\n    return result;\n}\nKdenliveMcpServer::KdenliveMcpServer')
    s=once(s,'    if (readOnly) {\n','''    if (readOnly) {
        const auto statePage = McpState::callTool(this, name, arguments, state, [this] { return snapshot(); });
        if (!statePage.isEmpty()) return statePage;
''')
    s=once(s,'''        if (bin->getAllClipIds().size() >= MaxItems - 1 || m_imports.size() >= MaxItems - 1)
            return failure(QStringLiteral("LIMIT"), QStringLiteral("Prototype import limit reached."), state);
''','')
    old='\n        if (timeline->getClipsCount() >= MaxItems - 1) return failure(QStringLiteral("LIMIT"), QStringLiteral("Prototype clip limit reached."), state);\n'
    if s.count(old)!=1: raise RuntimeError('Expected one media-placement global limit')
    s=s.replace(old,'\n',1)
    s=once(s,'''            if (timeline->getClipsCount() >= MaxItems - 1 || bin->getAllClipIds().size() >= MaxItems - 1)
                return failure(QStringLiteral("LIMIT"), QStringLiteral("Prototype clip limit reached."), state);
''','')
    s=once(s,'            if (timeline->getClipsCount() >= MaxItems - 1) return failure(QStringLiteral("LIMIT"), QStringLiteral("Prototype clip limit reached."), state);\n','')
    if 'MaxItems' in s: raise RuntimeError('Unconverted server MaxItems use')
    return s

def timeline(s):
    s=once(s,'#include "mcpsequence.h"','#include "mcpsequence.h"\n#include "mcpstate.h"')
    s=once(s,'constexpr int MaxItems = 512;','constexpr int MaxBatchItems = 8192;')
    s=once(s,'#include <functional>','#include <functional>\n#include <optional>')
    s=once(s,'QJsonObject binReadback(const std::shared_ptr<AbstractProjectItem> &item)',
             'QJsonObject binReadback(const std::shared_ptr<AbstractProjectItem> &item, std::optional<int> siblingRow = std::nullopt)')
    s=once(s,'{QStringLiteral("row"), item->row()},','{QStringLiteral("row"), siblingRow ? *siblingRow : item->row()},')
    start=s.index('bool binTree(');end=s.index('\nQJsonObject markerReadback',start)
    s=s[:start]+'''bool binTree(const std::shared_ptr<AbstractProjectItem> &parent, bool recursive, std::vector<std::shared_ptr<AbstractProjectItem>> &items)
{
    return McpState::binItems(parent, recursive, items);
}
'''+s[end:]
    s=s.replace('MaxItems','MaxBatchItems')
    s=once(s,'QStringLiteral("Bin tree exceeds 4096 nodes or depth 64.")','QStringLiteral("The native bin hierarchy contains a cycle or duplicate child.")')
    s=once(s,
'''            for (int row = offset; row < int(items.size()) && row - offset < limit; ++row)
                result.append(binReadback(items.at(row)));
''',
'''            QHash<const AbstractProjectItem *, int> nextSibling;
            for (int row = 0; row < int(items.size()) && row - offset < limit; ++row) {
                const auto &item = items.at(row);
                const auto parent = item->parent();
                const int siblingRow = nextSibling[parent.get()]++;
                if (row >= offset) result.append(binReadback(item, siblingRow));
            }
''')
    s=once(s,' || parent->depth() >= 64','')
    s=once(s,'QStringLiteral("Folder parent must be a native folder below depth 64.")','QStringLiteral("Folder parent must be a native folder.")')
    s=once(s,'''            std::vector<std::shared_ptr<AbstractProjectItem>> all;
            if (!binTree(root, true, all) || all.size() >= 4095) return reject(QStringLiteral("LIMIT"), QStringLiteral("Bin node limit reached."));
''','')
    s=once(s,'QStringLiteral("Bin subtree exceeds node/depth limit.")','QStringLiteral("The native bin subtree contains a cycle or duplicate child.")')
    s=once(s,'''                !Mcp::integer(arguments, QStringLiteral("videoTracks"), 0, 32, video) || audio + video < 1 ||
                Mcp::liveSequenceClips(pCore->projectItemModel()).size() >= 64)''',
             '''                !Mcp::integer(arguments, QStringLiteral("videoTracks"), 0, 32, video) || audio + video < 1)''')
    s=once(s,'Use nonempty name, 0..32 audio/video tracks and at least one track; at most 64 sequences.',
             'Use nonempty name, 0..32 audio/video tracks and at least one track.')
    s=once(s,'        if (timeline->getTracksCount() >= 64) return reject(QStringLiteral("LIMIT"), QStringLiteral("Native MCP track limit reached."));\n','')
    s=once(s,'''        if (timeline->getClipsCount() + timeline->getCompositionsCount() + int(allOnTracks.size()) + (insertion ? 1 : 0) > MaxBatchItems)
            return reject(QStringLiteral("LIMIT"), QStringLiteral("Operation could exceed item limit."));
''','')
    s=once(s,'        const int subtitleCount = subtitles ? int(subtitles->getAllSubIds().size()) : 0;\n','')
    s=once(s,'''        if (timeline->getClipsCount() + timeline->getCompositionsCount() + subtitleCount + int(affected.size()) > MaxBatchItems)
            return reject(QStringLiteral("LIMIT"), QStringLiteral("Item limit reached."));''',
             '''        if (affected.size() > MaxBatchItems)
            return reject(QStringLiteral("LIMIT"), QStringLiteral("Duplicate at most8192 group/mix members in one explicit transaction."));''')
    s=once(s,'''        if (timeline->getClipsCount() + timeline->getCompositionsCount() + int(affected.size()) >= MaxBatchItems)
            return reject(QStringLiteral("LIMIT"), QStringLiteral("Cut could exceed item limit."));''',
             '''        if (affected.size() > MaxBatchItems)
            return reject(QStringLiteral("LIMIT"), QStringLiteral("Cut at most8192 group members in one explicit transaction."));''')
    return s

def media(s):
    return once(s,'''        if (timeline->getClipsCount() + timeline->getCompositionsCount() + int(affected.size()) + int(placements.size()) > 512)
            return reject("LIMIT", "The operation could exceed the MCP native item limit.");
''','')

def tree_header(s):
    s=once(s,'#include <memory>','#include <memory>\n#include <vector>')
    return once(s,'    std::shared_ptr<TreeItem> child(int row) const;',
             '    std::shared_ptr<TreeItem> child(int row) const;\n\n    /** @brief Read-only child membership snapshot in sibling order. The model thread owns structural updates. */\n    std::vector<std::shared_ptr<TreeItem>> directChildren() const;')

def tree_source(s):
    return once(s,'std::shared_ptr<TreeItem> TreeItem::child(int row) const',
             'std::vector<std::shared_ptr<TreeItem>> TreeItem::directChildren() const\n{\n    return {m_childItems.cbegin(), m_childItems.cend()};\n}\n\nstd::shared_ptr<TreeItem> TreeItem::child(int row) const')

def cmake(s):
    return once(s,'    mcp/mcpsequence.h\n','    mcp/mcpsequence.h\n    mcp/mcpstate.cpp\n    mcp/mcpstate.h\n')
def tests(s):
    if '#include "mcpstate_cases.inc"' in s: raise RuntimeError('State tests already included')
    return s+'\n#include "mcpstate_cases.inc"\n'

parser=argparse.ArgumentParser(description='Stage R39 native-state integration; apply only after root coordination.')
parser.add_argument('--apply',action='store_true')
args=parser.parse_args()
transforms={'src/mcp/mcpserver.cpp':server,'src/mcp/mcptimeline.cpp':timeline,'src/mcp/mcpmedia.cpp':media,'src/abstractmodel/treeitem.hpp':tree_header,'src/abstractmodel/treeitem.cpp':tree_source,'src/CMakeLists.txt':cmake,'tests/mcptest.cpp':tests}
patch=[];manifest={};staged={}
for relative,transform in transforms.items():
    path=ROOT/relative;before=path.read_text(encoding='utf-8');after=transform(before)
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),'a/'+relative,'b/'+relative))
    target=WORK/(path.name+'.staged');target.write_text(after,encoding='utf-8')
    manifest[relative]={'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest()};staged[path]=after
(WORK/'r39-state-integration.patch').write_text(''.join(patch),encoding='utf-8')
(WORK/'integration-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
if args.apply:
    for path,after in staged.items():path.write_text(after,encoding='utf-8')
print(json.dumps({'applied':args.apply,'patch':str(WORK/'r39-state-integration.patch'),'files':list(transforms)}))
