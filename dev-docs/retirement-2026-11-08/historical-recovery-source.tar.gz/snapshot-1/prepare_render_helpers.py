from pathlib import Path
p=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\mcplifecycle.advanced.cpp')
s=p.read_text(encoding='utf-8')
anchor='QStringList stepArgs(const QJsonObject &step)'
helpers=r'''bool safeOutputLeaf(const QString &name)
{
    static const QRegularExpression invalid(QStringLiteral("[<>:\"/\\\\|?*%\\x00-\\x1f]"));
    static const QRegularExpression reserved(QStringLiteral("^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\\.|$)"), QRegularExpression::CaseInsensitiveOption);
    return !name.isEmpty() && name.size() <= 180 && name != key(".") && name != key("..") && QFileInfo(name).fileName() == name &&
           !name.endsWith(QLatin1Char('.')) && !name.endsWith(QLatin1Char(' ')) && !invalid.match(name).hasMatch() && !reserved.match(name).hasMatch();
}
bool ownedLeafPath(const QString &path, const QString &directory)
{
    const QFileInfo info(path);
    return QDir::isAbsolutePath(path) && info.absoluteDir().canonicalPath() == QDir(directory).canonicalPath() && !info.isSymLink();
}
QJsonObject nativeOutput(const RenderRequest::RenderJob &job, QString &error)
{
    QFile playlist(job.playlistPath);
    QDomDocument snapshot;
    if (!playlist.open(QIODevice::ReadOnly) || playlist.size() > 64 * 1024 * 1024 || !snapshot.setContent(&playlist)) {
        error = key("Cannot inspect the bounded native export snapshot.");
        return {};
    }
    const auto consumer = snapshot.documentElement().firstChildElement(key("consumer"));
    bool inValid = false, outValid = false;
    const int in = consumer.attribute(key("in")).toInt(&inValid), out = consumer.attribute(key("out")).toInt(&outValid);
    if (consumer.isNull() || !inValid || !outValid || in < 0 || out < in || qint64(out) - in + 1 > 1000000 ||
        consumer.attribute(key("target")) != job.outputPath) {
        error = key("Native export returned invalid bounds or target metadata.");
        return {};
    }
    const bool sequence = consumer.attribute(key("f")) == key("image2");
    return {{key("stagedPath"), job.outputFile}, {key("fileName"), QFileInfo(job.outputFile).fileName()},
            {key("kind"), sequence ? key("imageSequence") : key("media")}, {key("inFrame"), in}, {key("outFrame"), out},
            {key("expectedFrameCount"), out - in + 1}, {key("subtitlePath"), job.subtitlePath},
            {key("audioOnly"), consumer.attribute(key("video_off")).toInt() == 1 || consumer.attribute(key("vn")).toInt() == 1}};
}
bool verifyRenderOutputs(QJsonObject &job, QJsonArray &outputs, QString &error)
{
    const QString stage = job.value(key("stagingDir")).toString(), target = job.value(key("path")).toString();
    const bool directoryOutput = job.value(key("outputKind")) == key("directory");
    QSet<QString> keep;
    auto planned = job.value(key("plannedOutputs")).toArray();
    if (planned.isEmpty()) {
        error = key("Native export produced no output descriptors.");
        return false;
    }
    Mlt::Profile validationProfile(pCore->getProjectProfile());
    validationProfile.set_frame_rate(job.value(key("frameRateNumerator")).toInt(), job.value(key("frameRateDenominator")).toInt());
    for (int index = 0; index < planned.size(); ++index) {
        auto output = planned[index].toObject();
        const QString path = output.value(key("stagedPath")).toString(), leaf = output.value(key("fileName")).toString();
        if (!ownedLeafPath(path, stage)) {
            error = key("Native output escaped the owned staging directory.");
            return false;
        }
        const int expected = output.value(key("expectedFrameCount")).toInt();
        double bytes = 0;
        if (output.value(key("kind")) == key("imageSequence")) {
            static const QRegularExpression counter(QStringLiteral("%[0-9]*d"));
            const auto match = counter.match(leaf);
            if (!match.hasMatch() || counter.match(leaf, match.capturedEnd()).hasMatch()) {
                error = key("Native image sequence has an invalid counter pattern.");
                return false;
            }
            const QRegularExpression numbered(QRegularExpression::anchoredPattern(QRegularExpression::escape(leaf.left(match.capturedStart())) +
                                                   QStringLiteral("([0-9]+)") + QRegularExpression::escape(leaf.mid(match.capturedEnd()))));
            int count = 0, first = std::numeric_limits<int>::max(), last = -1;
            QSet<int> numbers;
            const auto files = QDir(stage).entryInfoList(QDir::Files | QDir::Hidden | QDir::NoDotAndDotDot);
            for (const auto &file : files) {
                const auto numberedMatch = numbered.match(file.fileName());
                if (!numberedMatch.hasMatch()) continue;
                bool valid = false;
                const int number = numberedMatch.captured(1).toInt(&valid);
                QImageReader reader(file.absoluteFilePath());
                if (!valid || numbers.contains(number) || file.isSymLink() || file.size() <= 0 || !reader.canRead() || !reader.size().isValid()) {
                    error = key("Native image sequence contains an unreadable, duplicate, or invalid frame.");
                    return false;
                }
                if (++count > expected) {
                    error = key("Native image sequence contains more frames than requested.");
                    return false;
                }
                first = qMin(first, number);
                last = qMax(last, number);
                numbers.insert(number);
                keep.insert(file.fileName());
                bytes += double(file.size());
            }
            if (count != expected || qint64(last) - first + 1 != expected) {
                error = key("Native image sequence frame count or numbering does not match the exact requested range.");
                return false;
            }
            output.insert(key("frameCount"), count);
            output.insert(key("firstNumber"), first);
            output.insert(key("lastNumber"), last);
        } else {
            const QFileInfo file(path);
            if (!file.isFile() || file.isSymLink() || file.size() <= 0) {
                error = key("Native renderer did not produce a nonempty ordinary media file.");
                return false;
            }
            int frames = 0;
            {
                Mlt::Producer rendered(validationProfile, path.toUtf8().constData());
                if (rendered.is_valid()) frames = rendered.get_length();
            }
            const int tolerance = output.value(key("audioOnly")).toBool() ? 1 : 0;
            if (qAbs(qint64(frames) - expected) > tolerance) {
                error = key("Native rendered media duration does not match the requested frame range.");
                return false;
            }
            bytes = double(file.size());
            output.insert(key("frameCount"), frames);
            if (directoryOutput && QFileInfo(path).fileName() != leaf) {
                const QString normalized = QDir(stage).absoluteFilePath(leaf);
                // The raw unembedded video is owned by this job and may be replaced
                // only inside its private stage before atomic publication.
                if ((QFileInfo::exists(normalized) && !QFile::remove(normalized)) || !QFile::rename(path, normalized)) {
                    error = key("Cannot finalize an owned subtitle-muxed output in staging.");
                    return false;
                }
                output.insert(key("stagedPath"), normalized);
            }
            keep.insert(leaf);
        }
        output.insert(key("path"), directoryOutput ? QDir(target).absoluteFilePath(leaf) : target);
        output.insert(key("bytes"), bytes);
        output.remove(key("stagedPath"));
        output.remove(key("subtitlePath"));
        outputs.append(output);
    }
    if (directoryOutput) {
        // Pass logs and unembedded intermediates are private implementation files.
        const auto files = QDir(stage).entryInfoList(QDir::AllEntries | QDir::Hidden | QDir::NoDotAndDotDot);
        for (const auto &file : files) {
            if (file.isSymLink() || !file.isFile() || (!keep.contains(file.fileName()) && !QFile::remove(file.absoluteFilePath()))) {
                error = key("Cannot clean the private export staging directory before publication.");
                return false;
            }
        }
    }
    return true;
}
'''
assert anchor in s
s=s.replace(anchor,helpers+anchor)
s=s.replace('#include <mlt++/MltProducer.h>','#include <mlt++/MltProducer.h>\n#include <limits>')
s=s.replace('{key("queueAfterJobId"), predecessor}, {key("sections"), sections}, {key("audioChannels"), channels},','''{key("queueAfterJobId"), predecessor}, {key("sections"), sections}, {key("audioChannels"), channels},
                           {key("frameRateNumerator"), pCore->getCurrentProfile()->frame_rate_num()},
                           {key("frameRateDenominator"), pCore->getCurrentProfile()->frame_rate_den()},''')
# Do not evict a finished prerequisite until its waiting dependent has reconciled.
s=s.replace('''        if (terminal(it.value().value(key("status")).toString())) {
            jobs.erase(it);''','''        if (terminal(it.value().value(key("status")).toString())) {
            bool needed = false;
            for (auto candidate = jobs.cbegin(); candidate != jobs.cend(); ++candidate)
                if (candidate.value().value(key("status")) == key("queued") && candidate.value().value(key("queueAfterJobId")) == it.key()) needed = true;
            if (needed) continue;
            jobs.erase(it);''')
p.write_text(s,encoding='utf-8')
print('Prepared output verification helpers')
