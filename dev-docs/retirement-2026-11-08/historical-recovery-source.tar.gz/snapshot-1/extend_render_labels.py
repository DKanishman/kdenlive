from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\render\renderrequest.cpp')
s=p.read_text(encoding='utf-8')
anchor='QStringList RenderRequest::argsByJob'
helper='''namespace {
// These labels become file-name suffixes, never paths or printf counters. Keep
// the visible track/guide labels intact and sanitize only the exported leaf.
QString safeRenderLabel(QString value)
{
    value.replace(QRegularExpression(QStringLiteral("[<>:\\\"/\\\\\\\\|?*%\\\\x00-\\\\x1f]")), QStringLiteral("_"));
    value = value.left(120);
    while (value.endsWith(QLatin1Char('.')) || value.endsWith(QLatin1Char(' '))) value.chop(1);
    if (value.isEmpty() || value == QLatin1String(".") || value == QLatin1String("..")) value = QStringLiteral("section");
    static const QRegularExpression reserved(QStringLiteral("^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\\\\.|$)"),
                                             QRegularExpression::CaseInsensitiveOption);
    if (reserved.match(value).hasMatch()) value.prepend(QLatin1Char('_'));
    return value;
}
QString uniqueRenderLabel(const QString &label, QStringList &used)
{
    const QString base = safeRenderLabel(label);
    QString candidate = base;
    int suffix = 2;
    while (used.contains(candidate, Qt::CaseInsensitive)) candidate = base + QStringLiteral("-%1").arg(suffix++);
    used.append(candidate);
    return candidate;
}
} // namespace

'''
assert anchor in s
s=s.replace(anchor,helper+anchor,1)
old='''                section.name.replace(QLatin1Char(':'), QLatin1Char('_'));
                section.name.replace(QLatin1Char('?'), QLatin1Char('_'));
                section.name.replace(QLatin1Char('/'), QLatin1Char('_'));
                section.name.replace(QLatin1Char('\\\\'), QLatin1Char('_'));
                section.name = QStringUtils::getUniqueName(names, section.name);
                names << section.name;'''
assert old in s
s=s.replace(old,'''                section.name = uniqueRenderLabel(section.name, names);''')
old='''.arg(trackName.replace(QStringLiteral(" "), QStringLiteral("_")));'''
assert old in s
s=s.replace(old,'''.arg(trackName.isEmpty() ? QString() : safeRenderLabel(trackName.replace(QStringLiteral(" "), QStringLiteral("_"))));''')
p.write_text(s,encoding='utf-8')
