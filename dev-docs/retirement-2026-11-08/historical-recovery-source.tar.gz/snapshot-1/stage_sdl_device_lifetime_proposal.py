from pathlib import Path
import difflib, json
root=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
source=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\short\cba01e4\mlt\src\modules\sdl2\consumer_sdl2_audio.c')
old=source.read_text(encoding='utf-8'); new=old
changes=[('    int out_channels;\n','    int out_channels;\n    SDL_AudioDeviceID audio_device;\n'),('''#ifdef _WIN32
        if (!self->no_quit_subsystem)
#endif
            SDL_QuitSubSystem(SDL_INIT_AUDIO);''','''        // Closing our device must finish callbacks before consumer memory is freed,
        // even while another consumer keeps SDL's audio subsystem initialized.
        if (self->audio_device) {
            SDL_CloseAudioDevice(self->audio_device);
            self->audio_device = 0;
        }
        pthread_mutex_lock(&mlt_sdl_mutex);
#ifdef _WIN32
        if (!self->no_quit_subsystem)
#endif
            SDL_QuitSubSystem(SDL_INIT_AUDIO);
        pthread_mutex_unlock(&mlt_sdl_mutex);'''),('''    if (init_audio == 1) {
        SDL_AudioSpec request;''','''    if (init_audio == 1) {
        // A timed-out device may be replaced by this same consumer. Finish its
        // callbacks before reusing buffers or losing ownership of the device.
        if (self->audio_device) {
            SDL_CloseAudioDevice(self->audio_device);
            self->audio_device = 0;
        }
        SDL_AudioSpec request;'''),('''            SDL_PauseAudioDevice(dev, 0);
            init_audio = 0;''','''            self->audio_device = dev;
            SDL_PauseAudioDevice(dev, 0);
            init_audio = 0;''')]
for oldpart,newpart in changes:
    if new.count(oldpart)!=1:raise RuntimeError('Unexpected SDL repair anchor: '+oldpart[:70])
    new=new.replace(oldpart,newpart,1)
staged=root/'sdl-device-lifetime-proposed.c';staged.write_text(new,encoding='utf-8')
patch=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/src/modules/sdl2/consumer_sdl2_audio.c',tofile='b/src/modules/sdl2/consumer_sdl2_audio.c'))
(root/'proposed-sdl-device-lifetime.patch').write_text(patch,encoding='utf-8')
plan='''PROPOSED ONLY: source/build/installed SDL module has not been changed.
Evidence: sdl-device-lifetime-hold-0.log and hold-1.log. Native public APIs, dummy audio driver, one real sdl2_audio consumer; holding one additional SDL audio initialization reference changes stop from closing device 2 to leaving it PLAYING. Consumer is still alive during observation; diagnostic explicitly closes its own device before freeing userdata. No intentional use-after-free was triggered.
Repair: retain each consumer-owned SDL device ID; close the previous device before timeout reinitialization and close its own device after stopping/joining workers, outside audio_mutex and before freeing callback userdata. Serialize QuitSubSystem with the existing shared initialization mutex. Preserve the existing Windows no_quit_subsystem timeout workaround pending separate evidence; no blanket backend switch and no SDL library binary patch.
Verification: independent review; apply only approved changes to a new isolated SDL module source/build under this task, using existing MLT/SDL dependencies. Old/new controlled public-API diagnostic must show the stopped consumer has no live device both with and without another SDL reference. Stress multiple consumer starts/stops and profile change using owned process jobs; dummy audio only. Check no callback deadlock, repeated start/stop, timeout reinitialization, failure cleanup. Then run the actual owned Kdenlive profile-change GUI test with SDL and inspect crash/hang/exit evidence. Do not claim the original GUI crash fixed until that test passes. Preserve existing Craft source/build/module until isolated proof succeeds; do not change the installed stock editor.
'''
(root/'proposed-sdl-device-lifetime-verification.txt').write_text(plan,encoding='utf-8')
print(json.dumps({'status':'staged_only','patch':str(root/'proposed-sdl-device-lifetime.patch'),'changed_lines':len(patch.splitlines())}))
checkpoint=root/'checkpoint.json'; data=json.loads(checkpoint.read_text(encoding='utf-8-sig'))
data['approvals'].update({'OpenFX':'Approved and exact 2-line dependency fix applied/rebuilt. Isolated old export absent/new export present and Factory.init PASS; no installed OFX providers; Craft installed module untouched.','SDL':'User requires KEEP SDL and investigate first. Native public-API dummy diagnostic proves consumer leaves owned device PLAYING while another SDL audio reference exists. Focused patch staged only; no native repair authorization yet.','categoryChanges':'User approved native range/stable-ID/whole-project single-undo repair. Author active, core independent review no findings; pending import counter extension being tested.','ASSImportUndo':'User approved whole ASS metadata/fonts/layers/styles/events undo. Source-only6native+8format cases; independent review active. Guard remains.','MLTReadOnlyQuery':'User approved isolated dependency read-only playlist bulk query. isolated_mlt_entry_api agent active; oldprefix/source preserved.'})
data['pendingApproval']=['SDL focused device-lifetime repair staged, root preparing question']
data['status']='ACTIVE; verified baseline27 preserved,115tools114nativecasesPASS. Native ASS/category repair source-only under review, R39state/wire staged-only. Isolated MLT readonly API build approved/in progress. OpenFX isolated load proof PASS. SDL owned-device leak proven; repair staged not applied. Full goal unfinished.'
data['authorOwners'].update({'root':'OpenFX approved fix/probe; SDL investigation/proposal; integration/evidence/buildcoordination','native_category_transactions':'native category core/MCP/tests+pending queued import preflight; source-only','review_ass_transaction':'independent review nativeASS import/helpers/persistence/tests, active','isolated_mlt_entry_api':'approved isolatedMLTAPI source/build/tests/probe, noCraft writes'})
from datetime import datetime,timezone
data['updatedAtUtc']=datetime.now(timezone.utc).isoformat();checkpoint.write_text(json.dumps(data,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')