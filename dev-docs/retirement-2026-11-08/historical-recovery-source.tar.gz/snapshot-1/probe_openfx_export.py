from pathlib import Path
import ctypes, json, os, sys
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot')
root=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
module=Path(sys.argv[1]); repository=module.parent
handles=[os.add_dll_directory(str(prefix/'bin'))]
os.environ['MLT_DATA']=str(prefix/'share'/'mlt')
os.environ['MLT_PROFILES_PATH']=str(prefix/'share'/'mlt'/'profiles')
dll=ctypes.CDLL(str(module))
try:
    getattr(dll,'mlt_register'); exported=True
except AttributeError:
    exported=False
result={'module':str(module),'mlt_register_exported':exported}
if exported:
    mlt=ctypes.CDLL(str(prefix/'bin'/'mlt-7.dll'))
    mlt.mlt_factory_init.argtypes=[ctypes.c_char_p]; mlt.mlt_factory_init.restype=ctypes.c_void_p
    mlt.mlt_repository_filters.argtypes=[ctypes.c_void_p]; mlt.mlt_repository_filters.restype=ctypes.c_void_p
    mlt.mlt_properties_count.argtypes=[ctypes.c_void_p]; mlt.mlt_properties_count.restype=ctypes.c_int
    mlt.mlt_properties_get_name.argtypes=[ctypes.c_void_p,ctypes.c_int]; mlt.mlt_properties_get_name.restype=ctypes.c_char_p
    repo=mlt.mlt_factory_init(os.fsencode(repository))
    if not repo: raise RuntimeError('Native MLT factory did not initialize')
    props=mlt.mlt_repository_filters(repo)
    names=[mlt.mlt_properties_get_name(props,i).decode('utf-8',errors='replace') for i in range(mlt.mlt_properties_count(props))]
    result.update(factory_initialized=True,registered_filters=names)
    mlt.mlt_factory_close.argtypes=[]; mlt.mlt_factory_close.restype=None; mlt.mlt_factory_close()
result['standard_plugin_directory_exists']=Path(r'C:\Program Files\Common Files\OFX\Plugins').is_dir()
print(json.dumps(result,ensure_ascii=True))