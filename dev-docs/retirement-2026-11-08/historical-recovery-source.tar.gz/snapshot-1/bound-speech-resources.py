from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpspeech.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('''        if (job->temporary && (!job->process || job->process->state() == QProcess::NotRunning)) job->temporary.reset();''','''        // completed() may still have a QFile on its stack. Defer removal until
        // both the process and that callback have released native file handles.
        QTimer::singleShot(0, this, [job] {
            if (job->temporary && (!job->process || job->process->state() == QProcess::NotRunning)) job->temporary.reset();
        });''',1)
s=s.replace('fragment.text().size() > 4096', 'fragment.text().size() > 256',1)
s=s.replace('!text(word.value(k("word")), value, 4096)', '!text(word.value(k("word")), value, 256)',1)
s=s.replace('Maximum tokens in this page, 1..256; default 128.', 'Maximum tokens in this page, 1..128; default 128.',1)
s=s.replace('k("limit"), 1, 256, limit', 'k("limit"), 1, 128, limit',1)
s=s.replace('existing token offset and limit 1..256.', 'existing token offset and limit 1..128.',1)
s=s.replace('''            job->source = source; job->document = pCore->currentDoc(); job->identity = sourceIdentity(source);''','''            if (job->model.endsWith(k(".en")) && !job->language.isEmpty() && job->language != k("English"))
                return reject("UNSUPPORTED_MODEL_LANGUAGE", "English-only Whisper checkpoints accept English or autodetect only.");
            job->source = source; job->document = pCore->currentDoc(); job->identity = sourceIdentity(source);''',1)
p.write_text(s,encoding='utf-8')
print('Deferred terminal resource cleanup and tightened transcript response bounds.')
