from pathlib import Path
import importlib.util,json,hashlib,os,sys,uuid
work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
run=work/('native-title-baseline-'+uuid.uuid4().hex[:10]);run.mkdir()
helper=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\live_smoke.py')
spec=importlib.util.spec_from_file_location('owned_title_helpers',helper)
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot')
build=prefix/'build/kde/kdemultimedia/kdenlive/work/build'
exe=build/'bin/titlertest.exe'
filter='Rich text outlines keep mixed fills after resize,Rich text outlined resize and undo preserve layout,Selective outlines paint only selected strokes without changing the fill,Selective shadow silhouette follows actual text alpha'
os.chdir(build/'tests')
summary={'work':str(run),'binarySha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'filter':filter,'runs':[]}
for platform in ['windows','offscreen']:
 folder=run/platform;folder.mkdir();(folder/'temp').mkdir();(folder/'artifacts').mkdir()
 env=dict(os.environ)
 env.update({'PATH':str(build/'bin')+os.pathsep+str(prefix/'bin')+os.pathsep+env.get('PATH',''),'QT_PLUGIN_PATH':str(prefix/'plugins'),'QT_QPA_PLATFORM':platform,'QT_FORCE_STDERR_LOGGING':'1','QT_QUICK_BACKEND':'software','QT_QUICK_CONTROLS_STYLE':'Basic','KDEROOT':str(prefix),'MLT_PREFIX':str(prefix),'MLT_DATA':str(prefix/'share/mlt'),'MLT_PROFILES_PATH':str(prefix/'share/mlt/profiles'),'TEMP':str(folder/'temp'),'TMP':str(folder/'temp'),'SHADOW_TEST_ARTIFACTS':str(folder/'artifacts')})
 job=common.OwnedJob()
 try:
  common.run_logged([str(exe),filter,'--reporter','compact'],folder/'native.log',env,job,120)
  status='passed'
 except Exception as error:status=str(error)
 finally:job.close()
 summary['runs'].append({'platform':platform,'status':status,'log':str(folder/'native.log')})
 (run/'report.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(summary['runs'][-1]),flush=True)
print(json.dumps({'report':str(run/'report.json')}),flush=True)
