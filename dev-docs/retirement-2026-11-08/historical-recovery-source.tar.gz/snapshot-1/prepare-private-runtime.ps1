$ErrorActionPreference='Stop'
$taskRoot='C:\Users\USER\.codex\work\kdenlive-mcp-completion'
$craftPrefix='C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot'
$buildRoot=Join-Path $craftPrefix 'build\kde\kdemultimedia\kdenlive\work\build'
$modules=Join-Path $buildRoot 'lib\mlt'
$original=Join-Path $craftPrefix 'lib\mlt'
$item=Get-Item -LiteralPath $modules
if ($item.LinkType -eq 'Junction') {
 if ([IO.Path]::GetFullPath($item.Target) -ne [IO.Path]::GetFullPath($original)) { throw 'Unexpected module junction target' }
 $retained=Join-Path $buildRoot 'lib\mlt-craft-baseline'
 if (Test-Path -LiteralPath $retained) { throw 'Baseline junction already exists' }
 Move-Item -LiteralPath $modules -Destination $retained
 New-Item -ItemType Directory -Path $modules | Out-Null
 foreach ($moduleFile in Get-ChildItem -LiteralPath $original -File -Filter '*.dll') { Copy-Item -LiteralPath $moduleFile.FullName -Destination (Join-Path $modules $moduleFile.Name) }
} elseif (-not (Test-Path -LiteralPath (Join-Path $buildRoot 'lib\mlt-craft-baseline'))) { throw 'Unknown private module directory' }
$runtimePrefix=Join-Path $taskRoot 'r39-mlt-api\isolated-app-prefix'
$mapping=@(
 @((Join-Path $runtimePrefix 'bin\mlt-7.dll'),(Join-Path $buildRoot 'bin\mlt-7.dll')),
 @((Join-Path $runtimePrefix 'bin\mlt++-7.dll'),(Join-Path $buildRoot 'bin\mlt++-7.dll')),
 @((Join-Path $runtimePrefix 'bin\melt.exe'),(Join-Path $buildRoot 'bin\melt.exe'))
)
foreach ($builtModule in Get-ChildItem -LiteralPath (Join-Path $runtimePrefix 'lib\mlt') -File -Filter '*.dll') {
 $mapping+=,@($builtModule.FullName,(Join-Path $modules $builtModule.Name))
}
$result=@()
foreach ($pair in $mapping) {
 if (-not (Test-Path -LiteralPath $pair[0] -PathType Leaf)) { throw "Missing validated dependency: $($pair[0])" }
 Copy-Item -LiteralPath $pair[0] -Destination $pair[1] -Force
 $result+=@{source=$pair[0];destination=$pair[1];sha256=(Get-FileHash -LiteralPath $pair[1] -Algorithm SHA256).Hash}
}
$result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskRoot 'private-runtime-manifest.json') -Encoding utf8
$result | ConvertTo-Json -Compress
