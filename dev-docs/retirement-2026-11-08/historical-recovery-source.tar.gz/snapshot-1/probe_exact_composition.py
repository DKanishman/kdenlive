from pathlib import Path
import ctypes as C, os, json, xml.etree.ElementTree as E, uuid
from PIL import Image,ImageChops
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot')
source=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\native-test-temp\kdenlive-rlMSwh\native-slide.mlt')
work=source.parents[2]/('exact-composition-'+uuid.uuid4().hex[:10]);work.mkdir()
os.environ['PATH']=str(prefix/'bin')+os.pathsep+os.environ.get('PATH','');os.environ['MLT_DATA']=str(prefix/'share/mlt');os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['QT_FORCE_STDERR_LOGGING']='1'
handle=os.add_dll_directory(str(prefix/'bin'));lib=C.CDLL(str(prefix/'bin/mlt-7.dll'));ptr=C.c_void_p
spec={'mlt_factory_init':([C.c_char_p],ptr),'mlt_profile_init':([C.c_char_p],ptr),'mlt_factory_producer':([ptr,C.c_char_p,C.c_char_p],ptr),'mlt_producer_service':([ptr],ptr),'mlt_producer_seek':([ptr,C.c_int],C.c_int),'mlt_service_get_frame':([ptr,C.POINTER(ptr),C.c_int],C.c_int),'mlt_frame_get_image':([ptr,C.POINTER(ptr),C.POINTER(C.c_int),C.POINTER(C.c_int),C.POINTER(C.c_int),C.c_int],C.c_int),'mlt_frame_close':([ptr],None),'mlt_producer_close':([ptr],None),'mlt_profile_close':([ptr],None),'mlt_factory_close':([],None)}
spec.update({'mlt_producer_properties':([ptr],ptr),'mlt_producer_cut_parent':([ptr],ptr),'mlt_tractor_field':([ptr],ptr),'mlt_field_plant_transition':([ptr,ptr,C.c_int,C.c_int],C.c_int),'mlt_service_get_producer':([ptr],ptr),'mlt_service_producer':([ptr],ptr),'mlt_service_properties':([ptr],ptr),'mlt_properties_get_int':([ptr,C.c_char_p],C.c_int),'mlt_properties_get':([ptr,C.c_char_p],C.c_char_p),'mlt_properties_set':([ptr,C.c_char_p,C.c_char_p],C.c_int),'mlt_properties_inc_ref':([ptr],C.c_int),'mlt_field_disconnect_service':([ptr,ptr],None),'mlt_service_disconnect_all_producers':([ptr],C.c_int),'mlt_factory_transition':([ptr,C.c_char_p,C.c_char_p],ptr),'mlt_transition_properties':([ptr],ptr),'mlt_transition_set_in_and_out':([ptr,C.c_int,C.c_int],None),'mlt_transition_close':([ptr],None),'mlt_field_service':([ptr],ptr)})
for n,(a,r) in spec.items():f=getattr(lib,n);f.argtypes=a;f.restype=r
assert lib.mlt_factory_init(str(prefix/'lib/mlt').encode())
print(json.dumps({'work':str(work)}),flush=True)
try:
 for variant in ['original','no-qtblend','no-fieldorder','progressive','distort','no-qtblend-distort','runtime-insert']:
  root=E.parse(source).getroot();t=root.findall('tractor')[-1];t.set('out','19');root.set('producer',t.attrib['id'])
  for prop in root.iter('property'):
   if prop.attrib['name']=='resource' and prop.text=='asymmetric.mkv':prop.text=(source.parent/'asymmetric.mkv').as_posix()
  if variant=='runtime-insert':
   t.remove(t.findall('transition')[0])
  if 'no-qtblend' in variant:
   for x in list(t.findall('transition')):
    if any(p.attrib['name']=='mlt_service' and p.text=='qtblend' for p in x):t.remove(x)
  if variant=='no-fieldorder':
   for x in list(t.findall('filter')):t.remove(x)
  if variant=='progressive':root.find('profile').set('progressive','1')
  if 'distort' in variant:
   for x in t.findall('transition'):
    if any(p.attrib['name']=='mlt_service' and p.text=='affine' for p in x):
     for p in x.findall('property'):
      if p.attrib['name']=='distort':p.text='1'
  path=work/(variant+'.mlt');E.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
  profile=lib.mlt_profile_init(b'dv_pal');producer=lib.mlt_factory_producer(profile,b'xml',str(path).encode());assert producer
  images=[]
  try:
   if variant=='runtime-insert':
    lib.mlt_producer_seek(producer,0);frame=ptr();assert not lib.mlt_service_get_frame(lib.mlt_producer_service(producer),C.byref(frame),0)
    image=ptr();fmt=C.c_int(2);w=C.c_int(720);h=C.c_int(576);assert not lib.mlt_frame_get_image(frame,C.byref(image),C.byref(fmt),C.byref(w),C.byref(h),0);lib.mlt_frame_close(frame)
    parent=lib.mlt_producer_cut_parent(producer);pp=lib.mlt_producer_properties(parent);print('PRODUCER',hex(producer),hex(parent),lib.mlt_properties_get(pp,b'resource'),lib.mlt_properties_get(pp,b'mlt_service'),flush=True);field=lib.mlt_tractor_field(parent);print('FIELD',field,flush=True);assert field;service=lib.mlt_service_get_producer(lib.mlt_field_service(field));internals=[]
    while service:
     props=lib.mlt_service_properties(service);print('SERVICE',service,props,flush=True);nxt=lib.mlt_service_producer(service)
     if lib.mlt_properties_get_int(props,b'internal_added'):
      lib.mlt_properties_inc_ref(props);internals.append((service,lib.mlt_properties_get_int(props,b'a_track'),lib.mlt_properties_get_int(props,b'b_track')))
     else:break
     service=nxt
    for svc,a,b in internals:lib.mlt_field_disconnect_service(field,svc);lib.mlt_service_disconnect_all_producers(svc)
    tr=lib.mlt_factory_transition(profile,b'affine',None);props=lib.mlt_transition_properties(tr);lib.mlt_properties_set(props,b'rect',b'0=-100% 0% 100% 100% 100%;19=0% 0% 100% 100% 100%');lib.mlt_transition_set_in_and_out(tr,0,19)
    assert not lib.mlt_field_plant_transition(field,tr,3,4)
    for svc,a,b in sorted(internals,key=lambda x:x[2]):assert not lib.mlt_field_plant_transition(field,svc,a,b)
    lib.mlt_transition_close(tr)
    for svc,a,b in internals:lib.mlt_transition_close(svc)

   for position in (0,19):
    lib.mlt_producer_seek(producer,position);frame=ptr();assert not lib.mlt_service_get_frame(lib.mlt_producer_service(producer),C.byref(frame),0)
    try:
     image=ptr();fmt=C.c_int(2);w=C.c_int(720);h=C.c_int(576);err=lib.mlt_frame_get_image(frame,C.byref(image),C.byref(fmt),C.byref(w),C.byref(h),0);assert not err,(variant,err)
     assert fmt.value==2,(variant,fmt.value);im=Image.frombytes('RGBA',(w.value,h.value),C.string_at(image,w.value*h.value*4));images.append(im.convert('RGB'));im.save(work/(variant+f'-{position}.png'))
    finally:lib.mlt_frame_close(frame)
   print(json.dumps({'variant':variant,'diff':ImageChops.difference(*images).getbbox(),'first':images[0].getpixel((4,4)),'last':images[1].getpixel((4,4))}),flush=True)
  finally:lib.mlt_producer_close(producer);lib.mlt_profile_close(profile)
finally:lib.mlt_factory_close()
