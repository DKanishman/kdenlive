from pathlib import Path
path=Path(r"C:\Users\USER\Documents\kdenlive\src\mcp\mcpeffects.cpp")
text=path.read_text(encoding='utf-8')
old='#include "mcphelpers.h"\n'
if text.count(old)!=1:raise RuntimeError('Helper include anchor changed')
text=text.replace(old,old+'#include "mcprotospline.h"\n',1)
old='''    converted = scalar(value);
    if (converted.size() > 65536'''
new='''    if (type == ParamType::Roto_spline) return McpRoto::normalizeProperty(value, converted, reason);
    converted = scalar(value);
    if (converted.size() > 65536'''
if text.count(old)!=1:raise RuntimeError('Parameter conversion marker changed')
text=text.replace(old,new,1)
old='''                        if (!values.value(i.key()).isArray())
                            return failure(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Rotoscoping keys require native spline point arrays."), state);
                        rotoAnimations[i.key()].insert(QString::number(sourceIn + frame), values.value(i.key()));'''
new='''                        if (!McpRoto::validatePoints(values.value(i.key()), reason))
                            return failure(QStringLiteral("INVALID_ARGUMENT"), reason, state);
                        const qint64 absoluteFrame = qint64(sourceIn) + frame;
                        if (absoluteFrame < 0 || absoluteFrame >= std::numeric_limits<int>::max())
                            return failure(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Native rotoscoping frame is outside its integer range."), state);
                        rotoAnimations[i.key()].insert(QString::number(absoluteFrame), values.value(i.key()));'''
if text.count(old)!=1:raise RuntimeError('Roto keyframe conversion marker changed')
text=text.replace(old,new,1)
path.write_text(text,encoding='utf-8')
print('Roto request validator integrated; shared source preserved outside checked spans')