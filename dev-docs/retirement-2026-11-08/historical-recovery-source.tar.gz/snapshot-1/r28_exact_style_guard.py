from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpeffects.cpp')
s=p.read_text(encoding='utf-8')
needle='''                    if (old == styles.end() || old->second.toString(name) != SubtitleStyle(line).toString(name)) return unsupportedMetadata();'''
replacement='''                    if (old == styles.end()) return unsupportedMetadata();
                    const auto &before = old->second;
                    const SubtitleStyle after(line);
                    // Serialization rounds floating-point fields; compare every public
                    // value so a small incoming change cannot escape the undo guard.
                    if (before.fontName() != after.fontName() || before.fontSize() != after.fontSize() ||
                        before.primaryColour() != after.primaryColour() || before.secondaryColour() != after.secondaryColour() ||
                        before.outlineColour() != after.outlineColour() || before.backColour() != after.backColour() ||
                        before.bold() != after.bold() || before.italic() != after.italic() || before.underline() != after.underline() ||
                        before.strikeOut() != after.strikeOut() || before.scaleX() != after.scaleX() || before.scaleY() != after.scaleY() ||
                        before.spacing() != after.spacing() || before.angle() != after.angle() || before.borderStyle() != after.borderStyle() ||
                        before.outline() != after.outline() || before.shadow() != after.shadow() || before.alignment() != after.alignment() ||
                        before.marginL() != after.marginL() || before.marginR() != after.marginR() || before.marginV() != after.marginV() ||
                        before.encoding() != after.encoding()) return unsupportedMetadata();'''
assert needle in s
s=s.replace(needle,replacement,1)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpsubtitle_format_cases.inc')
s=p.read_text(encoding='utf-8')
s+=r'''
TEST_CASE("ASS identical public metadata is allowed while subprecision style changes are guarded", "[mcp][subtitle][formats][metadata]")
{
    McpProject project;
    project.open();
    project.document->setDocumentProperty(QStringLiteral("documentid"), QString::number(QDateTime::currentMSecsSinceEpoch()));
    const auto model = project.timeline->createSubtitleModel();
    REQUIRE(model);
    const QString style = QStringLiteral("Style: Accent,Arial,37,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,2,2,10,11,12,1");
    model->setSubtitleStyle(QStringLiteral("Accent"), SubtitleStyle(style));
    QTemporaryDir directory;
    REQUIRE(directory.isValid());
    const QString header = QStringLiteral("[Script Info]\nScriptType: v4.00+\n\n[V4+ Styles]\n") + style + QStringLiteral("\n\n");
    const QString path = subtitleFileFixture(directory, QStringLiteral("identical.ass"),
        (header + subtitleFormatFixture(QStringLiteral("ass"), subtitleUnicode()).replace(QStringLiteral(",Default,"), QStringLiteral(",Accent,"))).toUtf8());
    project.success(QStringLiteral("subtitle_file"), subtitleFileArgs(project, QStringLiteral("import"), path));
    REQUIRE(model->count() == 2);
    const auto ids = model->getAllSubIds();
    project.success(QStringLiteral("undo"), project.expected());
    CHECK(model->count() == 0);
    CHECK(model->getSubtitleStyle(QStringLiteral("Accent")).fontSize() == 37.0);
    REQUIRE(project.undoStack->canRedo());
    const QString changed = subtitleFileFixture(directory, QStringLiteral("small-change.ass"),
        (header.replace(QStringLiteral(",37,"), QStringLiteral(",37.001,")) + subtitleFormatFixture(QStringLiteral("ass"), subtitleUnicode())).toUtf8());
    project.rejectWithoutChange(QStringLiteral("subtitle_file"), subtitleFileArgs(project, QStringLiteral("import"), changed));
    CHECK(model->getSubtitleStyle(QStringLiteral("Accent")).fontSize() == 37.0);
    REQUIRE(project.undoStack->canRedo());
    project.success(QStringLiteral("redo"), project.expected());
    CHECK(model->getAllSubIds() == ids);
}
'''
s=s.replace('const QString header = QStringLiteral("[Script Info]', 'QString header = QStringLiteral("[Script Info]')
p.write_text(s,encoding='utf-8')
print('Native subtitle source/tests frozen for root integration; no builds run.')
