from pathlib import Path
p=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\mcplifecycle.advanced.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('''        if (!localPath(arguments.value(key("path")), path, false))
            return failure(key("INVALID_PATH"), key("Choose a new absolute output path in a writable directory."), state);''','''        if (!localPath(arguments.value(key("path")), path, false) || !safeOutputLeaf(QFileInfo(path).fileName()))
            return failure(key("INVALID_PATH"), key("Choose a new absolute output path in a writable directory."), state);''')
p.write_text(s,encoding='utf-8')
