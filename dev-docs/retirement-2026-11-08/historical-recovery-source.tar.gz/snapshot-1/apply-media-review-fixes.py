from pathlib import Path
p=Path(r"C:\Users\USER\Documents\kdenlive\src\mcp\mcpmedia.cpp")
s=p.read_text(encoding="utf-8")
old='''            if (!current) { job.insert(k("status"), k("completed_detached")); job.insert(k("imported"), false); }
            else if (source->statusReady()) { job.insert(k("status"), k("completed")); job.insert(k("imported"), true); }
            else if (source->clipStatus() != FileStatus::StatusWaiting) { job.insert(k("status"), k("failed")); job.insert(k("error"), k("Native output import failed; the published file remains available.")); }'''
new='''            if (!current) {
                job.insert(k("status"), k("completed_detached")); job.insert(k("imported"), false);
            } else if (source->statusReady()) {
                const QString expected = QFileInfo(job.value(k("path")).toString()).canonicalFilePath();
                const QString actual = QFileInfo(source->url()).canonicalFilePath();
                if (!expected.isEmpty() && expected == actual) {
                    job.insert(k("status"), k("completed")); job.insert(k("imported"), true);
                } else {
                    job.insert(k("status"), k("completed_detached")); job.insert(k("imported"), false);
                    job.insert(k("error"), k("The native bin source was relinked before output loading completed; the published file was preserved."));
                }
            } else {
                const ObjectId owner(KdenliveObjectType::BinClip, source->clipId().toInt(), QUuid());
                const bool loading = source->clipStatus() == FileStatus::StatusWaiting &&
                                     pCore->taskManager.hasPendingJob(owner, AbstractTask::LOADJOB);
                if (!loading) {
                    job.insert(k("status"), k("failed")); job.insert(k("imported"), false);
                    job.insert(k("error"), k("Native output import failed or no native load job remains; the published file is available."));
                }
            }'''
assert s.count(old)==1
s=s.replace(old,new)
old='''            const auto items = timeline->getItemsInRange(track, 0, -1, true);'''
new='''            // Compositions have independent native occupancy and may legally
            // overlap a newly placed clip. Ripple/overwrite still inspect them.
            const auto items = timeline->getItemsInRange(track, 0, -1, mode != k("place"));'''
assert s.count(old)==1
s=s.replace(old,new)
p.write_text(s,encoding="utf-8")

p=Path(r"C:\Users\USER\Documents\kdenlive\src\jobs\transcodetask.h")
s=p.read_text(encoding="utf-8")
s=s.replace('#include "project/transcodeseek.h"', '#include "project/transcodeseek.h"\n#include <atomic>')
old='''                  int out, bool replaceProducer, QObject *object, bool checkProfile, const QString &outputPath = QString(), bool addToProject = true);'''
new=old+'\n    ~TranscodeTask() override;'
assert s.count(old)==1
s=s.replace(old,new)
s=s.replace('''private:
    int m_jobDuration;''','''private:
    std::atomic_bool m_hasRun{false};
    int m_jobDuration;''')
p.write_text(s,encoding="utf-8")
p=Path(r"C:\Users\USER\Documents\kdenlive\src\jobs\transcodetask.cpp")
s=p.read_text(encoding="utf-8")
needle='''void TranscodeTask::start(const ObjectId &owner'''
index=s.index(needle)
s=s[:index]+'''TranscodeTask::~TranscodeTask()
{
    // TaskManager may remove a queued QRunnable before run() is entered.
    // Its observers still need exactly one terminal cancellation result.
    if (!m_hasRun.load()) Q_EMIT transcodeFinished(false, true, QString(), QString());
}

'''+s[index:]
s=s.replace('''void TranscodeTask::run()
{
    AbstractTaskDone''', '''void TranscodeTask::run()
{
    m_hasRun.store(true);
    AbstractTaskDone''')
p.write_text(s,encoding="utf-8")
p=Path(r"C:\Users\USER\Documents\kdenlive\tests\mcpmedia_cases.inc")
s=p.read_text(encoding="utf-8")
s=s.replace('#include <QProcess>', '#include <QProcess>\n#include <QScopeGuard>\n#include "jobs/transcodetask.h"\n#include "transitions/transitionsrepository.hpp"')
p.write_text(s,encoding="utf-8")

p=Path(r"C:\Users\USER\Documents\kdenlive\tests\mcpmedia_cases.inc")
p.open("a",encoding="utf-8").write('\nnamespace {\nstruct MediaQueuedState { QAtomicInt started{0}; QAtomicInt release{0}; QAtomicInt finished{0}; };\nclass MediaQueuedBlocker : public AbstractTask\n{\npublic:\n    MediaQueuedBlocker(const ObjectId &owner, const std::shared_ptr<MediaQueuedState> &state)\n        : AbstractTask(owner, AbstractTask::TRANSCODEJOB, nullptr), state(state) {}\nprotected:\n    void run() override {\n        AbstractTaskDone completion(m_owner.itemId, this);\n        QMutexLocker lock(&m_runMutex); m_running = true; m_progress = 0; state->started.storeRelease(1);\n        QElapsedTimer deadline; deadline.start();\n        while (!state->release.loadAcquire() && !m_isCanceled.loadAcquire() && deadline.elapsed() < 5000) QThread::msleep(1);\n        m_progress = 100; state->finished.storeRelease(1);\n    }\nprivate:\n    std::shared_ptr<MediaQueuedState> state;\n};\nstruct MediaTranscodeConcurrency\n{\n    int previous = KdenliveSettings::proxythreads();\n    MediaTranscodeConcurrency() { KdenliveSettings::setProxythreads(1); pCore->taskManager.updateConcurrency(); }\n    ~MediaTranscodeConcurrency() { KdenliveSettings::setProxythreads(previous); pCore->taskManager.updateConcurrency(); }\n};\n}\nTEST_CASE("MCP queued native transcode deletion reaches terminal cancellation", "[MCP][MCPTranscode][Cancellation]")\n{\n    MediaFfmpeg ffmpeg; QTemporaryDir directory; REQUIRE(directory.isValid());\n    const auto path = multistreamFixture(directory, ffmpeg.path);\n    McpProject project; project.open(); const auto bin = importFixture(project, path);\n    MediaTranscodeConcurrency serial;\n    auto state = std::make_shared<MediaQueuedState>();\n    const auto release = qScopeGuard([state] { state->release.storeRelease(1); });\n    const ObjectId blockerOwner(KdenliveObjectType::BinClip, 999998, QUuid());\n    pCore->taskManager.startTask(blockerOwner.itemId, new MediaQueuedBlocker(blockerOwner, state));\n    QElapsedTimer started; started.start();\n    while (!state->started.loadAcquire() && started.elapsed() < 3000) { QCoreApplication::processEvents(); QThread::msleep(1); }\n    REQUIRE(state->started.loadAcquire());\n    const QString output = directory.filePath(QStringLiteral("never-started.mp4"));\n    const auto accepted = project.success(QStringLiteral("start_transcode"),\n        mediaFields(project, {{QStringLiteral("binId"), bin}, {QStringLiteral("profileId"), QStringLiteral("Lossy x264 I frame only")},\n                              {QStringLiteral("path"), output}, {QStringLiteral("importResult"), false}})).value(QStringLiteral("job")).toObject();\n    const ObjectId sourceOwner(KdenliveObjectType::BinClip, bin.toInt(), QUuid());\n    REQUIRE(pCore->taskManager.jobStatus(sourceOwner) == TaskManagerStatus::Pending);\n    pCore->taskManager.discardJobs(sourceOwner, AbstractTask::TRANSCODEJOB);\n    const auto terminal = nativeTranscodeTerminal(project, accepted.value(QStringLiteral("jobId")).toString());\n    CHECK(terminal.value(QStringLiteral("status")) == QStringLiteral("cancelled"));\n    CHECK(terminal.value(QStringLiteral("nativeFinished")).toBool());\n    CHECK_FALSE(terminal.value(QStringLiteral("imported")).toBool());\n    CHECK_FALSE(QFileInfo(output).exists());\n    state->release.storeRelease(1); started.restart();\n    while ((!state->finished.loadAcquire() || pCore->taskManager.hasPendingJob(blockerOwner)) && started.elapsed() < 3000) {\n        QCoreApplication::processEvents(); QThread::msleep(1);\n    }\n    REQUIRE(state->finished.loadAcquire());\n    CHECK_FALSE(pCore->taskManager.hasPendingJob(blockerOwner));\n}\nTEST_CASE("MCP explicit video placement can overlap a native composition", "[MCP][MCPMediaStreams]")\n{\n    McpProject project; project.open(); QTemporaryDir directory; REQUIRE(directory.isValid());\n    const auto bin = importFixture(project, pngFixture(directory));\n    const int upper = project.videoTracks.at(1), lower = project.videoTracks.at(0);\n    project.success(QStringLiteral("add_color_clip"), project.colorArgs(lower, 0, 30));\n    QString transition;\n    for (const auto &entry : TransitionsRepository::get()->getNames()) if (TransitionsRepository::get()->isComposition(entry.first)) { transition = entry.first; break; }\n    REQUIRE_FALSE(transition.isEmpty());\n    const auto added = project.success(QStringLiteral("edit_composition"),\n        mediaFields(project, {{QStringLiteral("operation"), QStringLiteral("add")}, {QStringLiteral("transitionId"), transition},\n                              {QStringLiteral("trackId"), upper}, {QStringLiteral("aTrackId"), lower},\n                              {QStringLiteral("startFrame"), 0}, {QStringLiteral("durationFrames"), 25}}));\n    const int composition = added.value(QStringLiteral("compositionId")).toInt(-1);\n    REQUIRE(project.timeline->isComposition(composition));\n    const auto inserted = project.success(QStringLiteral("insert_media_streams"),\n        mediaFields(project, {{QStringLiteral("binId"), bin}, {QStringLiteral("videoTrackId"), upper}, {QStringLiteral("startFrame"), 5},\n                              {QStringLiteral("sourceInFrame"), 0}, {QStringLiteral("durationFrames"), 12}}));\n    const int clip = inserted.value(QStringLiteral("items")).toArray().first().toObject().value(QStringLiteral("clipId")).toInt(-1);\n    CHECK(project.timeline->getClipTrackId(clip) == upper); CHECK(project.timeline->getClipPosition(clip) == 5);\n    CHECK(project.timeline->getCompositionPosition(composition) == 0); CHECK(project.timeline->getCompositionPlaytime(composition) == 25);\n    project.success(QStringLiteral("undo"), project.expected());\n    CHECK_FALSE(project.timeline->isClip(clip)); CHECK(project.timeline->isComposition(composition));\n    project.success(QStringLiteral("redo"), project.expected()); CHECK(project.timeline->isClip(clip));\n    REQUIRE(project.timeline->checkConsistency());\n}\n')
