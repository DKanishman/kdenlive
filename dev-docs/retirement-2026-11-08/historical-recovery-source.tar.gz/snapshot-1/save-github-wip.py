from pathlib import Path
import json,os,subprocess,uuid
root=Path(r'C:\Users\USER\Documents\kdenlive');work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion');stage=work/'fullscope'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
env=os.environ.copy();env['GIT_INDEX_FILE']=str(work/('github-wip-'+uuid.uuid4().hex+'.index'))
def git(*args,input=None):
 r=subprocess.run(['git','-c','core.longpaths=true',*args],cwd=root,env=env,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if r.returncode:raise RuntimeError(r.stderr.decode('utf-8',errors='replace')+r.stdout.decode('utf-8',errors='replace'))
 return r.stdout

git('read-tree',base)
patches=sorted((stage/'advanced').glob('*.patch'))
# Apply only narrow diffs, preserving newer integrated work outside these hunks.
for patch in patches:
 data=patch.read_bytes().replace(b'\r\n',b'\n')
 git('apply','--cached','--check','--ignore-space-change','--whitespace=nowarn','-',input=data)
 git('apply','--cached','--ignore-space-change','--whitespace=nowarn','-',input=data)

def put(name,data,cpp=False):
 if cpp:
  r=subprocess.run([r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot\bin\clang-format.exe','--style=file','--assume-filename='+str(root/name)],input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=root)
  if r.returncode:raise RuntimeError(r.stderr.decode())
  data=r.stdout.replace(b'\r\n',b'\n')
 if not cpp: data=b'\n'.join(line.rstrip() for line in data.replace(b'\r\n',b'\n').splitlines()).rstrip()+b'\n'
 sha=git('hash-object','-w','--stdin',input=data).decode().strip()
 git('update-index','--add','--cacheinfo',f'100644,{sha},{name}')

native=json.loads((stage/'advanced/native-manifest.json').read_text(encoding='utf-8-sig'))
for item in native['files']:
 name=item['path'];put(name,git('show',':'+name),cpp=True)
for name,path in [('src/mcp/mcpprojectextras.cpp',stage/'r36/mcpprojectextras.cpp'),('src/mcp/mcpprojectextras.h',stage/'r36/mcpprojectextras.h'),('tests/mcpadvancedediting_native_cases.inc',stage/'advanced/tests/mcpadvancedediting_native_cases.inc')]:put(name,path.read_bytes(),cpp=True)
notes='''# Full editor coverage WIP — paused 2026-11-04

This branch preserves unfinished work separately from `codex/mcp-prototype`. It is not build- or runtime-verified and must not be treated as a completed feature release.

Included prototypes:

- Native short/empty audio-correlation repairs, audio-envelope range/decode/cancellation corrections and timecode-unit/rate/overflow handling.
- A native regression fragment for those primitives, not yet registered in the test runner.
- Initial `mcpprojectextras` tools for project notes/history, exact non-destructive unused-bin cleanup, slideshow/title-template intake and asynchronous source status. The standalone module passed a syntax check before this snapshot; it is not yet in CMake or the tool dispatcher.

Outstanding integration includes checked alignment jobs/proposals/atomic apply, generated-media workflow tests, multicam and grouped audio time maps, complete rich template validation, and OTIO/library/archive services. No audio/video recording or optional model installation has been performed.

The intended contracts and remaining prerequisites are recorded alongside this document. Native changes here need independent review and real native/GUI execution. Work stopped at the user's request; resume only when requested.
'''
put('dev-docs/mcp-full-coverage-wip.md',notes.encode())
put('dev-docs/mcp-advanced-editing-plan.json',(stage/'advanced/implementation-plan.json').read_bytes())
put('dev-docs/mcp-projectextras-plan.txt',(work/'r36-projectextras-design.txt').read_bytes())
inventory=json.loads((work/'next-scope-r21-r23-r29-r38.json').read_text(encoding='utf-8-sig'));inventory.pop('source',None)
def sanitize(v):
 if isinstance(v,str):return v.replace(str(Path.home()),'<user-home>').replace(str(Path.home()).replace('\\','/'),'<user-home>')
 if isinstance(v,list):return [sanitize(x) for x in v]
 if isinstance(v,dict):return {k:sanitize(x) for k,x in v.items()}
 return v
put('dev-docs/mcp-feature-inventory.json',(json.dumps(sanitize(inventory),indent=2)+'\n').encode())
git('diff','--cached','--check')
tree=git('write-tree').decode().strip()
message=b'WIP: preserve advanced editing and project workflow prototypes\n\nUnverified native alignment/timecode repairs, initial project-extras tools and a test fragment. Catalog/CMake wiring, review and end-to-end verification remain pending. Saved separately at the user-requested pause.\n'
sha=git('commit-tree',tree,'-p',base,input=message).decode().strip()
branch='codex/mcp-full-coverage-wip'
git('update-ref','refs/heads/'+branch,sha,'0'*40)
info={'mainCommit':base,'wipCommit':sha,'wipBranch':branch,'mainBranch':'codex/mcp-prototype','workingTreePreserved':True}
(work/'github-save-manifest.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
print(json.dumps(info));print(git('diff','--stat',base,sha).decode());print(git('status','--short').decode())
