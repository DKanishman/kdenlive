from pathlib import Path
import hashlib,json,re
from datetime import datetime,timezone
ROOT=Path(r'C:\Users\USER\Documents\kdenlive')
WORK=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
CATALOGS={'src/mcp/mcpserver.cpp':'QJsonArray baseToolCatalog()','src/mcp/mcptimeline.cpp':'QJsonArray KdenliveMcpServer::timelineToolCatalog()','src/mcp/mcpeffects.cpp':'QJsonArray KdenliveMcpServer::effectToolCatalog()','src/mcp/mcplifecycle.cpp':'QJsonArray KdenliveMcpServer::lifecycleToolCatalog()','src/mcp/mcpui.cpp':'QJsonArray KdenliveMcpServer::uiToolCatalog()','src/mcp/mcpquick.cpp':'QJsonArray McpQuick::toolCatalog()','src/mcp/mcpmedia.cpp':'QJsonArray toolCatalog()','src/mcp/mcpmonitor.cpp':'QJsonArray toolCatalog()','src/mcp/mcpprofiles.cpp':'QJsonArray toolCatalog()','src/mcp/mcpspeech.cpp':'QJsonArray toolCatalog()','src/mcp/mcpmarkers.cpp':'QJsonArray toolCatalog()','src/mcp/mcptitles.cpp':'QJsonArray toolCatalog()'}
def line_number(text,offset):return text.count('\n',0,offset)+1
def extract_catalog(path,marker):
 text=path.read_text(encoding='utf-8');start=text.index(marker)
 ends=[p for p in [text.find('\nQJsonObject KdenliveMcpServer::',start),text.find('\n} // namespace',start)] if p>=0]
 end=min(ends) if ends else len(text);block=text[start:end];items=[]
 for m in re.finditer(r'\b(?:add|tool)\s*\(\s*(?:(?:QStringLiteral|k|key|mk)\(\s*)?"([a-z_]+)"',block):items.append({'name':m.group(1),'source':str(path.relative_to(ROOT)).replace('\\','/'),'line':line_number(text,start+m.start()),'evidence_level':'source_registration_only','runtime_verified':False})
 return items

def inventory():
 byname={};groups={}
 for relative,marker in CATALOGS.items():
  entries=extract_catalog(ROOT/relative,marker);groups[relative]=[i['name'] for i in entries]
  for item in entries:byname[item['name']]=item
 tests=[]
 for path in [ROOT/'tests/mcptest.cpp',*sorted((ROOT/'tests').glob('mcp*_cases.inc'))]:
  text=path.read_text(encoding='utf-8')
  for m in re.finditer(r'TEST_CASE\(\s*"([^"]+)"\s*,\s*"([^"]+)"',text):tests.append({'name':m.group(1),'tags':m.group(2),'source':str(path.relative_to(ROOT)).replace('\\','/'),'line':line_number(text,m.start()),'execution_status':'not_verified_by_inventory'})
 actions=[];standard=[]
 for relative in ['src/mainwindow_actions.cpp','src/mainwindow.cpp','src/bin/bin.cpp']:
  text=(ROOT/relative).read_text(encoding='utf-8')
  for m in re.finditer(r'\b(?:addAction|addBinAction|addClipAction)\s*\(\s*QStringLiteral\(\s*"([A-Za-z0-9_]+)"',text):
   start=text.rfind('\n',0,m.start())+1
   if text[start:m.start()].lstrip().startswith('//'):continue
   actions.append({'id':m.group(1),'source':relative,'line':line_number(text,m.start()),'status':'static_candidate_only; conditional compilation and runtime context not evaluated'})
  for m in re.finditer(r'KStandardAction::([A-Za-z0-9_]+)\s*\(',text):standard.append({'factory':m.group(1),'source':relative,'line':line_number(text,m.start()),'status':'runtime_action_id_not_inferred'})
 return {'generated_at_utc':datetime.now(timezone.utc).isoformat(),'tool_count_static_unique':len(byname),'tools':sorted(byname.values(),key=lambda i:i['name']),'catalog_sources':groups,'test_cases_in_source':tests,'static_action_candidates':actions,'standard_action_factories':standard,'source_hashes':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in CATALOGS},'inventory_limits':['Static source counts are not a live tools/list result.','Selected source action registrations are candidates, not a denominator for every editor function.','Dynamic/context-menu/QML/plugin actions and other registration sites are not exhaustively inventoried.','Test-case presence does not prove execution or semantic coverage.']}
if __name__=='__main__':
 path=WORK/'coverage-audit.json';data=json.loads(path.read_text(encoding='utf-8'));data['inventory']=inventory();path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps({'staticToolCount':data['inventory']['tool_count_static_unique'],'testCasesInSource':len(data['inventory']['test_cases_in_source']),'coverage':str(path)}))
