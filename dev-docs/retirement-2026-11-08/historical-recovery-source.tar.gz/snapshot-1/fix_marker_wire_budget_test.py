from pathlib import Path
path=Path(r"C:\Users\USER\Documents\kdenlive\tests\mcpmarkers_cases.inc")
text=path.read_text(encoding='utf-8')
old='''    state.insert(QStringLiteral("boundaryStatePadding"), QString(180000, QChar(0x4e2d)));
    const auto excessive = McpMarkers::callTool(
'''
new='''    // Complete structured data can fit even when its duplicate text would
    // exceed the protocol budget. Omitting that text must lose no native data.
    const QString structuredPadding(180000, QChar(0x4e2d));
    state.insert(QStringLiteral("boundaryStatePadding"), structuredPadding);
    const auto structuredOnly = McpMarkers::callTool(
        &project.server, QStringLiteral("inspect_marker_file"),
        {{QStringLiteral("scope"), QStringLiteral("guides")}, {QStringLiteral("path"), path}, {QStringLiteral("format"), QStringLiteral("json")}}, state,
        [&] { return state; });
    REQUIRE_FALSE(structuredOnly.value(QStringLiteral("isError")).toBool());
    CHECK(structuredOnly.value(QStringLiteral("_meta")).toObject().value(QStringLiteral("textCopyOmitted")).toBool());
    CHECK(wire(structuredOnly).size() <= 1024 * 1024);
    const auto structuredData = structuredOnly.value(QStringLiteral("structuredContent")).toObject();
    CHECK(structuredData.value(QStringLiteral("state")).toObject().value(QStringLiteral("boundaryStatePadding")).toString() == structuredPadding);
    const auto structuredPage = structuredData.value(QStringLiteral("markers")).toArray();
    REQUIRE_FALSE(structuredPage.isEmpty());
    for (int row = 0; row < structuredPage.size(); ++row) {
        CHECK(structuredPage.at(row).toObject().value(QStringLiteral("pos")).toInt() == row);
        CHECK(structuredPage.at(row).toObject().value(QStringLiteral("comment")).toString() == comment);
    }
    CHECK(structuredData.value(QStringLiteral("nextOffset")).toInt() == structuredPage.size());
    CHECK(structuredData.value(QStringLiteral("hasMore")).toBool() == (structuredPage.size() < input.size()));
    CHECK(markerFileBytes(path) == originalBytes);
    CHECK(project.timeline->getGuideModel()->rowCount() == 0);

    // A base state that cannot fit even once still leaves no room for a marker
    // preview; return the bounded explicit error without dropping marker rows.
    state.insert(QStringLiteral("boundaryStatePadding"), QString(400000, QChar(0x4e2d)));
    const auto excessive = McpMarkers::callTool(
'''
if text.count(old)!=1:raise RuntimeError('Marker wire budget test marker changed')
path.write_text(text.replace(old,new,1),encoding='utf-8')
print('Marker budget regression updated; source behavior unchanged, test released')