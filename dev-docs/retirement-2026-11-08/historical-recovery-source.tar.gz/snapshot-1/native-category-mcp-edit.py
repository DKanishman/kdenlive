from pathlib import Path
import shutil
root=Path(r'C:\Users\USER\Documents\kdenlive');p=root/'src/mcp/mcptimeline.cpp';t=p.read_text(encoding='utf-8')
b=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\src_mcp_mcptimeline.cpp.category-before')
if not b.exists():shutil.copy2(p,b)
a=t.index('    add("edit_marker_category",');z=t.index('    return catalog;',a)
t=t[:a]+'''    add("edit_marker_category",
        "Add/update/delete a global project marker category in one native project undo. Deletion defaults to rejecting used categories. Explicit remap "
        "preserves point/range markers and IDs; explicit marker deletion requires acknowledgement. Application defaults are unchanged.",
        {{QStringLiteral("operation"), choice("Operation.", {QStringLiteral("add"), QStringLiteral("update"), QStringLiteral("delete")})},
         {QStringLiteral("categoryId"), typed("integer", "Category ID 0..1000000.")},
         {QStringLiteral("name"), typed("string", "Nonempty name up to 160 characters.")},
         {QStringLiteral("color"), typed("string", "Color #RRGGBB.")},
         {QStringLiteral("markerPolicy"), choice("Delete only: reject used categories (default), remap markers, or delete markers.",
                                                {QStringLiteral("reject"), QStringLiteral("remap"), QStringLiteral("delete")})},
         {QStringLiteral("replacementCategoryId"), typed("integer", "Delete/remap only: another existing category ID.")},
         {QStringLiteral("acknowledgeMarkerDeletion"), typed("boolean", "Required true when markerPolicy is delete.")}},
        {QStringLiteral("operation"), QStringLiteral("categoryId")});
'''+t[z:]
a=t.index('    if (name == QLatin1String("edit_marker_category")) {');z=t.index('    if (name == QLatin1String("list_sequences")) {',a)
t=t[:a]+'''    if (name == QLatin1String("edit_marker_category")) {
        const auto operation = arguments.value(QStringLiteral("operation")).toString();
        int category = -1;
        if (!Mcp::integer(arguments, QStringLiteral("categoryId"), 0, 1000000, category) ||
            (operation != QLatin1String("add") && operation != QLatin1String("update") && operation != QLatin1String("delete")))
            return reject(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Use add/update/delete and bounded categoryId."));
        const bool exists = pCore->markerTypes.contains(category);
        if (operation == QLatin1String("add") ? exists : !exists)
            return reject(QStringLiteral("INVALID_CATEGORY"), QStringLiteral("Add requires new category ID; update/delete requires existing ID."));
        const auto model = timeline->getGuideModel();
        const auto document = pCore->currentDoc();
        if (!model || !document) return reject(QStringLiteral("NOT_READY"), QStringLiteral("Native guide/category model unavailable."));
        auto categories = pCore->markerTypes;
        QMap<int, int> remap;
        QString policy;
        int affectedMarkers = 0;
        if (operation == QLatin1String("delete")) {
            if (arguments.contains(QStringLiteral("name")) || arguments.contains(QStringLiteral("color")))
                return reject(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Category deletion does not take name/color."));
            if (categories.size() <= 1 || category == KdenliveSettings::default_marker_type())
                return reject(QStringLiteral("DEFAULT_CATEGORY"), QStringLiteral("Preserve at least one category and the current application default category."));
            policy = arguments.value(QStringLiteral("markerPolicy")).toString(QStringLiteral("reject"));
            if ((arguments.contains(QStringLiteral("markerPolicy")) && !arguments.value(QStringLiteral("markerPolicy")).isString()) ||
                (policy != QLatin1String("reject") && policy != QLatin1String("remap") && policy != QLatin1String("delete")))
                return reject(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("markerPolicy must be reject, remap, or delete."));
            if (policy == QLatin1String("remap")) {
                int replacement = -1;
                if (!Mcp::integer(arguments, QStringLiteral("replacementCategoryId"), 0, 1000000, replacement) || replacement == category ||
                    !categories.contains(replacement) || arguments.contains(QStringLiteral("acknowledgeMarkerDeletion")))
                    return reject(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Remap requires a different existing replacementCategoryId and no deletion acknowledgement."));
                remap.insert(category, replacement);
            } else if (arguments.contains(QStringLiteral("replacementCategoryId"))) {
                return reject(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("replacementCategoryId requires markerPolicy=remap."));
            }
            if (policy == QLatin1String("delete")) {
                const auto acknowledged = arguments.value(QStringLiteral("acknowledgeMarkerDeletion"));
                if (!acknowledged.isBool() || !acknowledged.toBool())
                    return reject(QStringLiteral("ACKNOWLEDGEMENT_REQUIRED"),
                                  QStringLiteral("Deleting markers/guides requires acknowledgeMarkerDeletion=true. This remains undoable."));
            } else if (arguments.contains(QStringLiteral("acknowledgeMarkerDeletion"))) {
                return reject(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("acknowledgeMarkerDeletion requires markerPolicy=delete."));
            }
            std::unordered_set<MarkerListModel *> seen;
            auto count = [&](const std::shared_ptr<MarkerListModel> &markers) {
                if (!markers) return false;
                if (seen.insert(markers.get()).second) affectedMarkers += markers->getAllMarkers(category).size();
                return true;
            };
            // Walk attached bin children; cached UUID/ID maps can retain deleted sequence entries.
            for (const auto &clip : pCore->projectItemModel()->getRootFolder()->childClips()) {
                if (!clip || !clip->statusReady() || !count(clip->getMarkerModel()))
                    return reject(QStringLiteral("MEDIA_NOT_READY"), QStringLiteral("Wait for all source/sequence marker models before deleting a global category."));
            }
            for (const auto &uuid : document->getTimelinesUuids()) {
                const auto sequence = document->getTimeline(uuid, true);
                if (!sequence || !count(sequence->getGuideModel()))
                    return reject(QStringLiteral("NOT_READY"), QStringLiteral("A native sequence guide model is unavailable."));
            }
            if (affectedMarkers > 0 && policy == QLatin1String("reject"))
                return reject(QStringLiteral("CATEGORY_USED"), QStringLiteral("Choose markerPolicy=remap, or explicitly acknowledge markerPolicy=delete, for used categories."));
            categories.remove(category);
        } else {
            if (arguments.contains(QStringLiteral("markerPolicy")) || arguments.contains(QStringLiteral("replacementCategoryId")) ||
                arguments.contains(QStringLiteral("acknowledgeMarkerDeletion")))
                return reject(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Marker deletion policy fields apply only to category deletion."));
            const auto title = arguments.value(QStringLiteral("name")), color = arguments.value(QStringLiteral("color"));
            if (!title.isString() || title.toString().isEmpty() || title.toString().size() > 160 || title.toString().contains(QChar::Null) ||
                !color.isString() || !QRegularExpression(QStringLiteral("^#[0-9A-Fa-f]{6}$")).match(color.toString()).hasMatch())
                return reject(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Use nonempty name up to 160 characters and #RRGGBB color."));
            categories[category] = {QColor(color.toString()), title.toString()};
        }
        QStringList next;
        for (auto i = categories.begin(); i != categories.end(); ++i)
            next.append(QStringLiteral("%1:%2:%3").arg(i.value().displayName, QString::number(i.key()), i.value().color.name()));
        if (!document->updateGuideCategories(next, remap))
            return reject(QStringLiteral("EDIT_FAILED"),
                          QStringLiteral("Native category transaction was rejected without changes. Check loading, pending legacy guides, category mappings, or busy models."));
        return finish({{QStringLiteral("categories"), QJsonDocument::fromJson(model->categoriesToJSon().toUtf8()).array()},
                       {QStringLiteral("affectedMarkerCount"), affectedMarkers}, {QStringLiteral("markerPolicy"), policy},
                       {QStringLiteral("undoable"), true}, {QStringLiteral("historyReset"), false}});
    }
'''+t[z:]
p.write_text(t,encoding='utf-8',newline='\n')
