from pathlib import Path
root=Path(r'C:\Users\USER\Documents\kdenlive')
h=root/'src/bin/model/subtitlemodel.hpp'
s=h.read_text(encoding='utf-8')
needle='''    /** @brief Function that imports a subtitle file */
    void importSubtitle(const QString &filePath, int offset = 0, bool externalImport = false, float startFramerate = 30.00, float targetFramerate = 30.00,
                        const QByteArray &encoding = "UTF-8");'''
replacement=needle+'''
    struct ImportResult
    {
        bool success{false};
        int importedCount{0};
        QString error;
    };
    /** Import with a checked result. ASS external imports validate the complete
     * file before applying events and metadata in one undo command. An optional
     * expected event count is checked before committing to document history. */
    ImportResult importSubtitleWithUndo(const QString &filePath, int offset = 0, bool externalImport = false, float startFramerate = 30.00,
                                        float targetFramerate = 30.00, const QByteArray &encoding = "UTF-8", int expectedCount = -1);'''
assert needle in s
s=s.replace(needle,replacement,1)
needle='''private:
    struct LanguageState'''
replacement='''private:
    struct ImportMetadata
    {
        std::map<QString, SubtitleStyle> styles;
        std::map<QString, QString> script;
        QStringList defaultStyles;
        QString fonts;
        int maxLayer{0};
        int activeLayer{0};
    };
    ImportMetadata captureImportMetadata() const;
    void restoreImportMetadata(const ImportMetadata &metadata);
    ImportResult importAssSubtitle(const QString &filePath, int offset, float startFramerate, float targetFramerate, const QByteArray &encoding,
                                   int expectedCount);
    struct LanguageState'''
assert needle in s
s=s.replace(needle,replacement,1)
h.write_text(s,encoding='utf-8')
p=root/'src/bin/model/subtitlemodel.cpp'
s=p.read_text(encoding='utf-8')
needle='''void SubtitleModel::importSubtitle(const QString &filePath, int offset, bool externalImport, float startFramerate, float targetFramerate,
                                   const QByteArray &encoding)
{'''
replacement='''void SubtitleModel::importSubtitle(const QString &filePath, int offset, bool externalImport, float startFramerate, float targetFramerate,
                                   const QByteArray &encoding)
{
    const auto result = importSubtitleWithUndo(filePath, offset, externalImport, startFramerate, targetFramerate, encoding);
    if (externalImport && !result.success) {
        pCore->displayMessage(i18n("The selected subtitle file %1 is invalid: %2", filePath, result.error), ErrorMessage);
    }
}

SubtitleModel::ImportResult SubtitleModel::importSubtitleWithUndo(const QString &filePath, int offset, bool externalImport, float startFramerate,
                                                                 float targetFramerate, const QByteArray &encoding, int expectedCount)
{
    if (externalImport && filePath.endsWith(QLatin1String(".ass"), Qt::CaseInsensitive)) {
        return importAssSubtitle(filePath, offset, startFramerate, targetFramerate, encoding, expectedCount);
    }'''
assert needle in s
s=s.replace(needle,replacement,1)
start=s.index('SubtitleModel::ImportResult SubtitleModel::importSubtitleWithUndo(')
end=s.index('\nvoid SubtitleModel::parseSubtitle(',start)
part=s[start:end]
part=part.replace('if (filePath.isEmpty() || (isLocked() && !m_languageStateChanging)) return;',
                  'if (filePath.isEmpty() || (isLocked() && !m_languageStateChanging)) return {false, 0, QStringLiteral("Subtitle path is empty or the model is locked.")};',1)
part=part.replace('            return;','            return {false, 0, QStringLiteral("Cannot read the subtitle file.")};')
part=part.replace('''        pCore->displayMessage(i18n("The selected file %1 is invalid.", filePath), ErrorMessage);
        return;''','''        return {false, 0, QStringLiteral("No subtitle events were imported.")};''',1)
needle='''    Fun update_model = [this]() {'''
replacement='''    const int importedCount = int(m_subtitleList.size() - initialCount);
    if (externalImport && expectedCount >= 0 && importedCount != expectedCount) {
        // No command has been pushed: the prior redo branch remains owned by
        // the stack. These legacy text formats have no file-level metadata.
        const bool restored = undo() && m_subtitleList.size() == initialCount;
        return {false, 0, restored ? QStringLiteral("Native subtitle event count did not match the validated file.")
                                  : QStringLiteral("Native subtitle rollback failed.")};
    }
    Fun update_model = [this]() {'''
assert needle in part
part=part.replace(needle,replacement,1)
part=part.replace('''        pCore->pushUndo(undo, redo, i18n("Edit subtitle"));
    }
}''','''        pCore->pushUndo(undo, redo, i18n("Edit subtitle"));
    }
    return {true, importedCount, {}};
}''',1)
s=s[:start]+part+s[end:]
assert '#include <limits>' not in s
s=s.replace('#include <utility>','#include <utility>\n#include <cmath>\n#include <limits>\n#include <set>',1)
# The native writer previously emitted the bytes without their required section.
needle='''            if (!fontSection.isEmpty()) out << fontSection << '\\n';'''
assert needle in s
s=s.replace(needle,'''            if (!fontSection.isEmpty()) out << "[Fonts]\\n" << fontSection << '\\n';''',1)
p.write_text(s,encoding='utf-8')
print('Preserved void wrapper; added checked native result API and scoped ASS font header correction.')
