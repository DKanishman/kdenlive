from pathlib import Path
work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
source=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcplifecycle.cpp')
assert source.read_text(encoding='utf-8') == (work/'mcplifecycle.before-advanced.cpp').read_text(encoding='utf-8'), 'Lifecycle changed during staging; merge required'
s=(work/'mcplifecycle.advanced.cpp').read_text(encoding='utf-8')
s=s.replace('''                    if (!verifyMedia()) return;
                    continue;''','''                    if (!verifyMedia()) return;
                    break;''')
source.write_text(s,encoding='utf-8')
tests=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcplifecycle_cases.inc')
t=tests.read_text(encoding='utf-8')
assert 'MCP publishes exact native PNG' not in t
t+='\n'+(work/'advanced_export_cases.inc').read_text(encoding='utf-8-sig')
tests.write_text(t,encoding='utf-8')
print('Integrated advanced exports and native regression cases')
