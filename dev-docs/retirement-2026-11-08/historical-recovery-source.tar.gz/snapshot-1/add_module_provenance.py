from pathlib import Path
import ast

runner = Path(r"C:\Users\USER\.codex\work\kdenlive-mcp-completion\completion_gui_smoke.py")
text = runner.read_text(encoding="utf-8")
anchor = "def clip_map(state):\n"
helper = '''def loaded_module_provenance(process_id, names=("mlt-7.dll", "mlt++-7.dll", "mltsdl2.dll", "mltopenfx.dll")):
    """Read the owned Windows process's actual loaded module paths and file hashes."""
    import ctypes
    from ctypes import wintypes

    require(os.name == "nt" and isinstance(process_id, int) and process_id > 0,
            "Module provenance requires the owned Windows application PID")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel.CloseHandle.restype = wintypes.BOOL
    kernel.K32EnumProcessModulesEx.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.HMODULE),
                                               wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), wintypes.DWORD)
    kernel.K32EnumProcessModulesEx.restype = wintypes.BOOL
    for function_name in ("K32GetModuleBaseNameW", "K32GetModuleFileNameExW"):
        function = getattr(kernel, function_name)
        function.argtypes = (wintypes.HANDLE, wintypes.HMODULE, wintypes.LPWSTR, wintypes.DWORD)
        function.restype = wintypes.DWORD
    # Query/read access to this runner's own app only; no debug privileges.
    process = kernel.OpenProcess(0x0400 | 0x0010, False, process_id)
    if not process:
        raise ctypes.WinError(ctypes.get_last_error())
    wanted = {name.casefold() for name in names}
    try:
        for attempt in range(5):
            try:
                capacity = 256
                while True:
                    modules = (wintypes.HMODULE * capacity)()
                    needed = wintypes.DWORD()
                    if not kernel.K32EnumProcessModulesEx(process, modules, ctypes.sizeof(modules), ctypes.byref(needed), 3):
                        raise ctypes.WinError(ctypes.get_last_error())
                    count = (needed.value + ctypes.sizeof(wintypes.HMODULE) - 1) // ctypes.sizeof(wintypes.HMODULE)
                    require(count <= 8192, "Owned process module enumeration exceeded its diagnostic bound")
                    if needed.value <= ctypes.sizeof(modules):
                        break
                    capacity = count
                found = []
                for module in modules[:count]:
                    short_name = ctypes.create_unicode_buffer(512)
                    if not kernel.K32GetModuleBaseNameW(process, module, short_name, len(short_name)):
                        raise ctypes.WinError(ctypes.get_last_error())
                    if short_name.value.casefold() not in wanted:
                        continue
                    path_capacity = 512
                    while True:
                        full_name = ctypes.create_unicode_buffer(path_capacity)
                        written = kernel.K32GetModuleFileNameExW(process, module, full_name, path_capacity)
                        if not written:
                            raise ctypes.WinError(ctypes.get_last_error())
                        if written < path_capacity - 1:
                            break
                        require(path_capacity < 32768, "Loaded module path exceeded the Windows diagnostic bound")
                        path_capacity = min(path_capacity * 2, 32768)
                    module_path = Path(full_name.value)
                    require(module_path.is_absolute(), "Windows returned a relative loaded module path")
                    found.append({"name": short_name.value.casefold(), "path": str(module_path),
                                  "sha256": digest(module_path), "sizeBytes": module_path.stat().st_size})
                return {"processId": process_id, "method": "Windows K32 process module enumeration",
                        "hashMeaning": "SHA256 of the file at the OS-reported loaded module path",
                        "modules": sorted(found, key=lambda item: (item["name"], item["path"].casefold())),
                        "missing": sorted(wanted - {item["name"] for item in found})}
            except OSError as error:
                # Loading/unloading can briefly invalidate the loader snapshot.
                if getattr(error, "winerror", None) not in (24, 299) or attempt == 4:
                    raise
                time.sleep(.05)
    finally:
        kernel.CloseHandle(process)

'''
if text.count(anchor) != 1 or "def loaded_module_provenance(" in text:
    raise RuntimeError("Module-provenance insertion anchor changed")
text = text.replace(anchor, helper + anchor, 1)
startup_anchor = '        driver.phase("catalogs", lambda: catalogs(driver, names))\n'
if text.count(startup_anchor) != 1:
    raise RuntimeError("Startup provenance anchor changed")
text = text.replace(startup_anchor, startup_anchor + '        report["loadedModules"] = loaded_module_provenance(app.pid)\n', 1)
ast.parse(text, filename=str(runner))
runner.write_text(text, encoding="utf-8")
print("Updated runner and AST syntax check PASS; no app process launched")