from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpspeech.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('double previousEnd = begin; int previousBlock = -1, block = 0;', 'double previousEnd = begin; int previousBlock = -1, nextBlock = 0, currentBlock = -1;',1)
s=s.replace('''                result.append({previousEnd, word.start, i18n("No speech"), block++, true});
            else ++block;
        }
        auto copy = word; copy.block = block; result.append(copy);''','''                result.append({previousEnd, word.start, i18n("No speech"), nextBlock++, true});
            currentBlock = nextBlock++;
        }
        auto copy = word; copy.block = currentBlock; result.append(copy);''',1)
s=s.replace('result.append({previousEnd, end, i18n("No speech"), block + 1, true});','result.append({previousEnd, end, i18n("No speech"), nextBlock, true});',1)
s=s.replace('job->modelRoot = engine->modelFolder(true, false);','job->modelRoot = QDir(engine->modelFolder(true, false)).canonicalPath();',1)
s=s.replace('job->modelRoot == engine->modelFolder(true, false)', 'job->modelRoot == QDir(engine->modelFolder(true, false)).canonicalPath()',1)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpspeech_cases.inc')
s=p.read_text(encoding='utf-8').replace('project.timeline->getClipOut(clip) == 24', 'project.timeline->getClipIn(clip) + project.timeline->getClipPlaytime(clip) - 1 == 24',1)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\data\scripts\whisper\whispertotext.py')
s=p.read_text(encoding='utf-8')
s=s.replace('''            json.dump({"language": result.get("language", ""), "segments": result["segments"]},
                      output, ensure_ascii=False, allow_nan=False)''','''            # Export only the native time/text contract, avoiding unrelated
            # decoder arrays/tensors that are not JSON serializable.
            segments = [{"start": float(segment["start"]), "end": float(segment["end"]),
                         "words": [{"start": float(word["start"]), "end": float(word["end"]), "word": word["word"]}
                                   for word in segment["words"]]} for segment in result["segments"]]
            json.dump({"language": result.get("language", ""), "segments": segments},
                      output, ensure_ascii=False, allow_nan=False)''',1)
p.write_text(s,encoding='utf-8')
print('Corrected native silence paragraph identities, canonical model roots, portable timeline assertions and bounded speech JSON fields.')
