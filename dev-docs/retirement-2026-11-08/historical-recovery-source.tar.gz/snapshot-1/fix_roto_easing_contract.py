from pathlib import Path
path=Path(r"C:\Users\USER\Documents\kdenlive\src\mcp\mcpeffects.cpp")
text=path.read_text(encoding='utf-8')
old='''                    if (i.value().first == ParamType::Roto_spline) {
                        if (!McpRoto::validatePoints'''
new='''                    if (i.value().first == ParamType::Roto_spline) {
                        if (type != int(mlt_keyframe_linear))
                            return failure(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Native rotoscoping supports Linear interpolation only."), state);
                        if (!McpRoto::validatePoints'''
if text.count(old)!=1:raise RuntimeError('Roto easing marker changed')
path.write_text(text.replace(old,new,1),encoding='utf-8')
path=Path(r"C:\Users\USER\Documents\kdenlive\tests\mcp_roto_validation_cases.inc")
text=path.read_text(encoding='utf-8')
old='''    REQUIRE(project.timeline->checkConsistency());
}

TEST_CASE("MCP native roto clears'''
new='''    for (const auto &interpolation : {QStringLiteral("Discrete"), QStringLiteral("Smooth"), QStringLiteral("CubicIn")}) {
        QJsonArray keys;
        keys.append(rotoNativeKey(0, valid));
        auto eased = rotoNativeKey(2, valid);
        eased.insert(QStringLiteral("interpolation"), interpolation);
        keys.append(eased);
        project.rejectWithoutChange(QStringLiteral("set_effect_keyframes"), rotoAnimatedArgs(project, clip, effect->getId(), keys));
        CHECK(effect->getParam(QStringLiteral("spline")) == original);
    }
    REQUIRE(project.timeline->checkConsistency());
}

TEST_CASE("MCP native roto clears'''
if text.count(old)!=1:raise RuntimeError('Roto easing test marker changed')
path.write_text(text.replace(old,new,1),encoding='utf-8')
print('Native roto non-Linear easing now explicitly rejected; regression added; source frozen')