from pathlib import Path
root=Path(r'C:\Users\USER\Documents\kdenlive')
def change(path, old, new):
    p=root/path
    s=p.read_text(encoding='utf-8')
    assert s.count(old)==1,(path,old,s.count(old))
    p.write_text(s.replace(old,new,1),encoding='utf-8')
change('src/CMakeLists.txt','    mcp/mcpprofiles.h\n','    mcp/mcpprofiles.h\n    mcp/mcpspeech.cpp\n    mcp/mcpspeech.h\n')
change('tests/mcptest.cpp','#include "mcpduplication_cases.inc"','#include "mcpduplication_cases.inc"\n\n#include "mcpspeech_cases.inc"')
change('src/mcp/mcpserver.cpp','#include "mcpquick.h"','#include "mcpquick.h"\n#include "mcpspeech.h"')
change('src/mcp/mcpserver.cpp','McpMonitor::toolCatalog(), McpProfiles::toolCatalog()})','McpMonitor::toolCatalog(), McpProfiles::toolCatalog(), McpSpeech::toolCatalog()})')
change('src/mcp/mcpserver.cpp','    if (name == QLatin1String("transcode_status") || name == QLatin1String("cancel_transcode"))','    if (name == QLatin1String("speech_job_status") || name == QLatin1String("cancel_speech_job"))\n        return McpSpeech::callTool(this, name, arguments, state, [this] { return snapshot(); });\n    if (name == QLatin1String("transcode_status") || name == QLatin1String("cancel_transcode"))')
change('src/mcp/mcpserver.cpp','''    if (readOnly) {
        auto result = McpProfiles::callTool''','''    if (readOnly) {
        auto result = McpSpeech::callTool(this, name, arguments, state, [this] { return snapshot(); });
        if (!result.isEmpty()) return result;
        result = McpProfiles::callTool''')
change('src/mcp/mcpserver.cpp','''    auto moduleResult = McpProfiles::callTool''','''    auto moduleResult = McpSpeech::callTool(this, name, arguments, state, [this] { return snapshot(); });
    if (!moduleResult.isEmpty()) return moduleResult;
    moduleResult = McpProfiles::callTool''')
print('Integrated only new speech CMake sources, test include, catalog/header and early-status/cancel/read-only/post-guard dispatch spans.')
