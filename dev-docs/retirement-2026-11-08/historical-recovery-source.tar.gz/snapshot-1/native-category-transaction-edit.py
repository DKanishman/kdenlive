from pathlib import Path
import shutil
root=Path(r"C:\Users\USER\Documents\kdenlive")
work=Path(r"C:\Users\USER\.codex\work\kdenlive-mcp-completion")
def edit(name, old, new):
    p=root/name
    text=p.read_text(encoding="utf-8")
    assert old in text, name
    backup=work/(name.replace("/","_")+".category-before")
    if not backup.exists(): shutil.copy2(p,backup)
    p.write_text(text.replace(old,new,1),encoding="utf-8",newline="\n")
edit("src/bin/model/markerlistmodel.hpp",
     "    void loadCategoriesWithUndo(const QStringList &categories, const QStringList &currentCategories, const QMap<int, int> remapCategories = {});",
     """    /** Category changes preserve marker IDs/ranges and never change application defaults.
     *  The overload accepting models composes one atomic project transaction without pushing history.
     */
    bool loadCategoriesWithUndo(const QStringList &categories, const QStringList &currentCategories, const QMap<int, int> remapCategories = {});
    bool loadCategoriesWithUndo(const QStringList &categories, const QStringList &currentCategories, const QMap<int, int> &remapCategories,
                                Fun &undo, Fun &redo, const QList<std::shared_ptr<MarkerListModel>> &models = {});
    /** Remove/remap markers in all supplied models atomically; true also means an unchanged successful operation. */
    static bool removeCategories(const QList<std::shared_ptr<MarkerListModel>> &models, const QList<int> &toRemove,
                                 const QMap<int, int> &remapCategories, Fun &undo, Fun &redo);""")
edit("src/bin/model/markerlistmodel.hpp", "private:\n    std::weak_ptr<DocUndoStack> m_undoStack;", """private:
    using CategoryMarkers = std::map<int, CommentedTime>;
    static bool categoryTransaction(const QList<std::shared_ptr<MarkerListModel>> &models, const QList<int> &toRemove,
                                    const QMap<int, int> &remapCategories, const QStringList &categories, bool updateMetadata, Fun &undo, Fun &redo);
    bool categoryMarkersMatch(const CategoryMarkers &expected, const CategoryMarkers &replacement) const;
    void replaceCategoryMarkers(const CategoryMarkers &expected, const CategoryMarkers &replacement);
    std::weak_ptr<DocUndoStack> m_undoStack;""")
edit("src/bin/model/markerlistmodel.cpp", "#include <QJsonObject>\n", "#include <QJsonObject>\n#include <QScopeGuard>\n#include <QSet>\n")
p=root/"src/bin/model/markerlistmodel.cpp"
text=p.read_text(encoding="utf-8")
a=text.index("void MarkerListModel::loadCategoriesWithUndo(")
b=text.index("QList<int> MarkerListModel::loadCategories(",a)
old=text[a:b]
new=r"""namespace {
bool categoryMetadataEqual(const QMap<int, Core::MarkerCategory> &left, const QMap<int, Core::MarkerCategory> &right)
{
    if (left.size() != right.size()) return false;
    for (auto i = left.cbegin(); i != left.cend(); ++i) {
        auto other = right.constFind(i.key());
        if (other == right.cend() || i->color != other->color || i->displayName != other->displayName) return false;
    }
    return true;
}

bool parseCategoryMetadata(const QStringList &categories, QMap<int, Core::MarkerCategory> &result)
{
    if (categories.isEmpty()) return false;
    for (const auto &category : categories) {
        if (category.count(QLatin1Char(':')) < 2) return false;
        bool ok = false;
        const int id = category.section(QLatin1Char(':'), -2, -2).toInt(&ok);
        const QString name = category.section(QLatin1Char(':'), 0, -3);
        const QColor color(category.section(QLatin1Char(':'), -1).simplified());
        if (!ok || id < 0 || result.contains(id) || name.isEmpty() || name.contains(QChar::Null) || !color.isValid()) return false;
        result.insert(id, {color, name});
    }
    return true;
}

bool sameCategoryMarker(const CommentedTime &left, const CommentedTime &right)
{
    // CommentedTime::operator== compares only time.
    return left.time() == right.time() && left.duration() == right.duration() && left.comment() == right.comment() &&
           left.markerType() == right.markerType();
}
} // namespace

bool MarkerListModel::categoryMarkersMatch(const CategoryMarkers &expected, const CategoryMarkers &replacement) const
{
    for (const auto &[id, marker] : expected) {
        auto found = m_markerList.find(id);
        if (found == m_markerList.end() || !sameCategoryMarker(found->second, marker) || getIdFromPos(marker.time()) != id) return false;
    }
    for (const auto &[id, marker] : replacement) {
        if (expected.count(id) == 0 && (m_markerList.count(id) > 0 || hasMarker(marker.time()))) return false;
    }
    return true;
}

void MarkerListModel::replaceCategoryMarkers(const CategoryMarkers &expected, const CategoryMarkers &replacement)
{
    for (const auto &[id, marker] : expected) {
        if (replacement.count(id) > 0) continue;
        const int row = getRowfromId(id);
        beginRemoveRows(QModelIndex(), row, row);
        m_markerList.erase(id);
        m_markerPositions.remove(marker.time().frames(pCore->getCurrentFps()));
        endRemoveRows();
        removeSnapPoint(marker.time());
        if (marker.hasRange()) removeSnapPoint(marker.time() + marker.duration());
    }
    for (const auto &[id, marker] : replacement) {
        if (expected.count(id) > 0) {
            // A category reassignment changes no snap point, position, comment, duration, or ID.
            m_markerList.at(id) = marker;
            const int row = getRowfromId(id);
            Q_EMIT dataChanged(index(row), index(row), {TypeRole, ColorRole});
        } else {
            const int row = static_cast<int>(std::distance(m_markerList.begin(), m_markerList.lower_bound(id)));
            beginInsertRows(QModelIndex(), row, row);
            m_markerList.emplace(id, marker);
            m_markerPositions.insert(marker.time().frames(pCore->getCurrentFps()), id);
            endInsertRows();
            addSnapPoint(marker.time());
            if (marker.hasRange()) addSnapPoint(marker.time() + marker.duration());
        }
    }
}

bool MarkerListModel::categoryTransaction(const QList<std::shared_ptr<MarkerListModel>> &inputModels, const QList<int> &toRemove,
                                         const QMap<int, int> &remapCategories, const QStringList &categories, bool updateMetadata, Fun &undo, Fun &redo)
{
    const auto oldCategories = pCore->markerTypes;
    auto newCategories = oldCategories;
    if (updateMetadata) {
        newCategories.clear();
        if (!parseCategoryMetadata(categories, newCategories)) return false;
    }
    QSet<int> removed(toRemove.cbegin(), toRemove.cend());
    if (updateMetadata) {
        for (auto i = oldCategories.cbegin(); i != oldCategories.cend(); ++i) {
            if (!newCategories.contains(i.key())) removed.insert(i.key());
        }
    }
    for (auto i = remapCategories.cbegin(); i != remapCategories.cend(); ++i) {
        if (!removed.contains(i.key()) || !newCategories.contains(i.value()) || removed.contains(i.value())) return false;
    }
    struct Changes {
        std::shared_ptr<MarkerListModel> model;
        CategoryMarkers before;
        CategoryMarkers after;
    };
    QList<Changes> changes;
    QSet<MarkerListModel *> seen;
    std::vector<QReadWriteLock *> locks;
    const auto unlock = qScopeGuard([&locks] { for (auto *lock : locks) lock->unlock(); });
    for (const auto &model : inputModels) {
        if (!model) return false;
        if (seen.contains(model.get())) continue;
        seen.insert(model.get());
        if (!model->m_lock.tryLockForWrite()) return false;
        locks.push_back(&model->m_lock);
        Changes change{model, {}, {}};
        for (const auto &[id, marker] : model->m_markerList) {
            if (!removed.contains(marker.markerType())) continue;
            change.before.emplace(id, marker);
            if (remapCategories.contains(marker.markerType())) {
                auto replacement = marker;
                replacement.setMarkerType(remapCategories.value(marker.markerType()));
                change.after.emplace(id, replacement);
            }
        }
        changes.push_back(std::move(change));
    }
    if (changes.isEmpty()) return false;
    const bool metadataChanged = !categoryMetadataEqual(oldCategories, newCategories);
    bool markersChanged = false;
    for (const auto &change : changes) markersChanged |= !change.before.empty();
    if (!metadataChanged && !markersChanged) return true;
    const auto apply = [changes, oldCategories, newCategories, updateMetadata](bool forward) {
        std::vector<QReadWriteLock *> transactionLocks;
        const auto release = qScopeGuard([&transactionLocks] { for (auto *lock : transactionLocks) lock->unlock(); });
        for (const auto &change : changes) {
            if (!change.model->m_lock.tryLockForWrite()) return false;
            transactionLocks.push_back(&change.model->m_lock);
        }
        if (!categoryMetadataEqual(pCore->markerTypes, forward ? oldCategories : newCategories)) return false;
        // Validate every model before the first change, including restore-position collisions.
        for (const auto &change : changes) {
            if (!change.model->categoryMarkersMatch(forward ? change.before : change.after, forward ? change.after : change.before)) return false;
        }
        if (updateMetadata) pCore->markerTypes = forward ? newCategories : oldCategories;
        for (const auto &change : changes) {
            change.model->replaceCategoryMarkers(forward ? change.before : change.after, forward ? change.after : change.before);
        }
        if (updateMetadata) {
            for (const auto &change : changes) {
                Q_EMIT change.model->categoriesChanged();
                if (change.model->rowCount() > 0)
                    Q_EMIT change.model->dataChanged(change.model->index(0), change.model->index(change.model->rowCount() - 1), {ColorRole});
            }
            Q_EMIT pCore->saveGuideCategories();
        }
        return true;
    };
    Fun localRedo = [apply] { return apply(true); };
    Fun localUndo = [apply] { return apply(false); };
    if (!localRedo()) return false;
    UPDATE_UNDO_REDO_NOLOCK(localRedo, localUndo, undo, redo);
    return true;
}

bool MarkerListModel::removeCategories(const QList<std::shared_ptr<MarkerListModel>> &models, const QList<int> &toRemove,
                                       const QMap<int, int> &remapCategories, Fun &undo, Fun &redo)
{
    return categoryTransaction(models, toRemove, remapCategories, {}, false, undo, redo);
}

bool MarkerListModel::loadCategoriesWithUndo(const QStringList &categories, const QStringList &currentCategories,
                                            const QMap<int, int> &remapCategories, Fun &undo, Fun &redo,
                                            const QList<std::shared_ptr<MarkerListModel>> &models)
{
    QMap<int, Core::MarkerCategory> expected;
    if (!parseCategoryMetadata(currentCategories, expected) || !categoryMetadataEqual(expected, pCore->markerTypes)) return false;
    auto affectedModels = models;
    affectedModels.prepend(shared_from_this());
    return categoryTransaction(affectedModels, {}, remapCategories, categories, true, undo, redo);
}

bool MarkerListModel::loadCategoriesWithUndo(const QStringList &categories, const QStringList &currentCategories, const QMap<int, int> remapCategories)
{
    auto stack = m_undoStack.lock();
    if (!stack) return false;
    const QStringList before = categoriesToStringList();
    Fun undo = [] { return true; }, redo = [] { return true; };
    if (!loadCategoriesWithUndo(categories, currentCategories, remapCategories, undo, redo)) return false;
    if (before != categoriesToStringList()) stack->push(new FunctionalUndoCommand(undo, redo, i18n("Update timeline markers categories")));
    return true;
}

"""
edit("src/bin/model/markerlistmodel.cpp",old,new)
p=root/"src/mltcontroller/clipcontroller.cpp"
t=p.read_text(encoding="utf-8");a=t.index("bool ClipController::removeMarkerCategories(");b=t.index("std::shared_ptr<Mlt::Producer> ClipController::sequenceProducer",a)
edit("src/mltcontroller/clipcontroller.cpp",t[a:b],'''bool ClipController::removeMarkerCategories(const QList<int> toRemove, const QMap<int, int> remapCategories, Fun &undo, Fun &redo)
{
    return m_markerModel && MarkerListModel::removeCategories({m_markerModel}, toRemove, remapCategories, undo, redo);
}

''')
