"""Apply only after the native subtitle history/reopen regressions pass."""
from pathlib import Path
root = Path(r"C:\Users\USER\Documents\kdenlive")
p = root / "src/mcp/mcpeffects.cpp"
s = p.read_text(encoding="utf-8")
a = s.index("        // Native activation rebuilds subtitle event IDs in this same model.")
b = s.index("        const auto before = model->getSubtitlesList();", a)
s = s[:a] + s[b:]
old = 'QStringLiteral("Create, activate, rename or delete a native subtitle language/file track. These native lifecycle operations are explicitly not " n)'
s = s.replace('Create, activate, rename or delete a native subtitle language/file track. These native lifecycle operations are explicitly not "\n                            "undoable; layer/clip edits use edit_subtitle.', 'Create, activate, rename or delete a native subtitle language/file track with native undo. Language changes preserve document history, "\n                            "event identity, styles and groups across undo/redo; layer/clip edits use edit_subtitle.')
needle = '        m_document->setModified(true);\n        auto data = subtitleReadback(model);\n        data.insert(QStringLiteral("trackId"), id);\n        data.insert(QStringLiteral("undoable"), false);'
assert needle in s
s = s.replace(needle, '        auto data = subtitleReadback(model);\n        data.insert(QStringLiteral("trackId"), id);\n        data.insert(QStringLiteral("undoable"), true);', 1)
p.write_text(s, encoding="utf-8")
p = root / "tests/mcpeffects_cases.inc"
s = p.read_text(encoding="utf-8")
needle = '    CHECK_FALSE(language.value(QStringLiteral("undoable")).toBool(true));\n    args = project.expected();\n    args.insert(QStringLiteral("operation"), QStringLiteral("activate"));\n    args.insert(QStringLiteral("trackId"), trackId);\n    project.rejectWithoutChange(QStringLiteral("subtitle_language"), args);\n    project.undoStack->clear();\n    args.insert(QStringLiteral("expectedState"), project.token());\n    const auto active = project.success(QStringLiteral("subtitle_language"), args);'
assert needle in s
s = s.replace(needle, '    CHECK(language.value(QStringLiteral("undoable")).toBool());\n    const int originalId = *model->getAllSubIds().begin();\n    const int beforeSwitch = project.undoStack->index();\n    args = project.expected();\n    args.insert(QStringLiteral("operation"), QStringLiteral("activate"));\n    args.insert(QStringLiteral("trackId"), trackId);\n    const auto active = project.success(QStringLiteral("subtitle_language"), args);\n    CHECK(project.undoStack->index() == beforeSwitch + 1);', 1)
needle = '    CHECK(model->getText(*model->getAllSubIds().begin()) == QStringLiteral("Native subtitle"));\n}'
assert needle in s
s = s.replace(needle, '    CHECK(model->getText(*model->getAllSubIds().begin()) == QStringLiteral("Native subtitle"));\n    project.success(QStringLiteral("undo"), project.expected());\n    CHECK(project.success(QStringLiteral("get_subtitles")).value(QStringLiteral("activeLanguageId")).toInt() == 0);\n    REQUIRE(model->hasSubtitle(originalId));\n    CHECK(project.undoStack->index() == beforeSwitch);\n    project.success(QStringLiteral("redo"), project.expected());\n    CHECK(project.success(QStringLiteral("get_subtitles")).value(QStringLiteral("activeLanguageId")).toInt() == trackId);\n    REQUIRE(model->count() == 1);\n    CHECK(model->getText(*model->getAllSubIds().begin()) == QStringLiteral("Native subtitle"));\n    REQUIRE(project.timeline->checkConsistency());\n}', 1)
p.write_text(s, encoding="utf-8")
print("Enabled verified native subtitle language history and replaced the obsolete fixture history reset with undo/redo assertions.")
