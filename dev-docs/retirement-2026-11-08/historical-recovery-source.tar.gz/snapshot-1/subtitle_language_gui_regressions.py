"""Real running-editor proof for subtitle language files, history, save and reopen.
Call verify_subtitle_languages(driver, work) from the owned completion GUI session.
"""
from pathlib import Path
import hashlib


def verify_subtitle_languages(driver, work):
    work = Path(work).resolve()

    def require(condition, message):
        if not condition:
            raise AssertionError(message)

    def subtitles():
        return driver.call("get_subtitles")

    def check_active(text, language_id):
        value = subtitles()
        require(value["activeLanguageId"] == language_id, f"Wrong language context: {value}")
        require(len(value["subtitles"]) == 1 and value["subtitles"][0]["text"] == text,
                f"Native language content differs: {value}")
        item = value["subtitles"][0]
        require(item["startFrame"] == 5 and item["endFrame"] == 30, f"Native subtitle timing differs: {item}")
        return value

    def files(value, field):
        return {int(item["id"]): Path(item[field]).resolve() for item in value["languageTracks"]}

    def read_all(paths):
        return {key: path.read_bytes() for key, path in paths.items()}

    def assert_published(snapshots):
        for path, expected in snapshots.items():
            require(path.is_file() and path.read_bytes() == expected, f"Undo changed a saved subtitle asset: {path}")

    def go_to(index):
        state = driver.state()
        while state["undoIndex"] != index:
            before = state["undoIndex"]
            driver.mutate("undo" if before > index else "redo")
            state = driver.state()
            require(state["undoIndex"] == before + (-1 if before > index else 1), "Native history did not advance exactly once")

    state = driver.state()
    # Kdenlive marks its initial empty document modified before any edit.
    # Confirm the actual fresh document/history/content instead of clearing it.
    require(not state["projectPath"] and state["undoCount"] == 0 and len(state["bin"]) == 1
            and all(not track["clips"] and not track["compositions"] for track in state["tracks"])
            and not subtitles()["subtitles"], "Subtitle integration phase requires its fresh owned project")
    video = next(t for t in state["tracks"] if not t["audio"])
    driver.mutate("add_color_clip", trackId=video["id"], startFrame=0, durationFrames=75, color="#204060ff", name="Subtitle language regression")
    added = driver.mutate("edit_subtitle", operation="add", startFrame=5, endFrame=30, text="Published language A")
    original_id = added["id"]
    project_a, project_b = work / "subtitle-save-A.kdenlive", work / "subtitle-save-B.kdenlive"
    driver.project_job("save_document", path=str(project_a), overwrite=False)
    before_creation = driver.state()["undoIndex"]
    created = driver.mutate("subtitle_language", operation="create", name="Second language", copyTrackId=0)
    second_id = created["trackId"]
    require(created["undoable"], "Language creation did not advertise native undo")
    driver.mutate("subtitle_language", operation="activate", trackId=second_id)
    second = check_active("Published language A", second_id)
    second_event = second["subtitles"][0]["id"]
    require(second_event != original_id, "Language activation reused another language's live event ID")
    driver.mutate("edit_subtitle", operation="update", id=second_event, text="Published language B")
    b_bytes = files(subtitles(), "workPath")[second_id].read_bytes()
    driver.mutate("subtitle_language", operation="activate", trackId=0)
    a = check_active("Published language A", 0)
    require(files(a, "workPath")[second_id].read_bytes() == b_bytes, "Switch overwrote the inactive B work file")
    driver.project_job("save_document", path=str(project_a), overwrite=True)
    saved_index = driver.state()["undoIndex"]
    a_files = files(subtitles(), "savedPath")
    a_bytes = read_all(a_files)
    require(b"Published language A" in a_bytes[0] and b"Published language B" in a_bytes[second_id], "Normal Save wrote the wrong language asset")
    snapshots = {path: a_bytes[key] for key, path in a_files.items()}
    work_files = files(subtitles(), "workPath")
    go_to(before_creation)
    check_active("Published language A", 0)
    require(subtitles()["subtitles"][0]["id"] == original_id, "Undo did not restore original event identity")
    require(not work_files[second_id].exists(), "Undo creation left the removed language work file")
    assert_published(snapshots)
    go_to(saved_index)
    check_active("Published language A", 0)
    driver.project_job("save_document", path=str(project_b), overwrite=False)
    b_files = files(subtitles(), "savedPath")
    b_saved = read_all(b_files)
    snapshots.update({path: b_saved[key] for key, path in b_files.items()})
    require(a_files != b_files, "Save As did not update actual subtitle saved paths")
    go_to(before_creation)
    assert_published(snapshots)
    go_to(saved_index)
    driver.mutate("subtitle_language", operation="delete", trackId=second_id)
    require(not work_files[second_id].exists(), "Language deletion did not remove its work file")
    assert_published(snapshots)
    driver.mutate("undo")
    require(b"Published language B" in work_files[second_id].read_bytes(), "Delete undo restored the wrong work file")
    driver.mutate("redo")
    assert_published(snapshots)
    driver.mutate("undo")
    require(not driver.state()["modified"], "Undo to saved boundary did not restore the clean document state")
    # Native file import/export is checked in the same actual editor session.
    for suffix in ("ass", "srt"):
        target = work / ("native-subtitle-export." + suffix)
        driver.mutate("subtitle_file", operation="export", path=str(target))
        require(b"Published language A" in target.read_bytes(), "Native subtitle export omitted active language content")
    # Exports do not modify the document's undo history; new_project may now close
    # the old document. Remove only this session's inactive owned temp work files
    # so reopens have to reconstruct from the actual published ASS assets.
    profile = driver.state()["profile"]
    if isinstance(profile, dict):
        profile = profile["path"]
    reopen_results = []
    for reopen_index, target in enumerate((project_a, project_b), 1):
        driver.project_job("new_project", profile=profile, videoTracks=2, audioTracks=1)
        # New native projects start modified. Save this owned empty bridge through
        # the normal API before replacement; never bypass the dirty-document guard.
        driver.project_job("save_document", path=str(work / f"reopen-bridge-{reopen_index}.kdenlive"), overwrite=False)
        for path in work_files.values():
            require(path.is_relative_to(work), f"Refusing cleanup outside the owned test directory: {path}")
            path.unlink(missing_ok=True)
        driver.project_job("open_project", path=str(target))
        reopened_a = check_active("Published language A", 0)
        driver.mutate("subtitle_language", operation="activate", trackId=second_id)
        check_active("Published language B", second_id)
        driver.mutate("undo")
        check_active("Published language A", 0)
        require(not driver.state()["modified"], "Undo language switch after reopen did not restore clean history")
        work_files = files(subtitles(), "workPath")
        reopen_results.append({"project": str(target), "languages": reopened_a["languageTracks"]})
    assert_published(snapshots)
    return {"passed": True, "normalSaveAndSaveAs": [str(project_a), str(project_b)], "nativeReopens": reopen_results,
            "publishedAssets": {str(path): hashlib.sha256(value).hexdigest() for path, value in snapshots.items()},
            "undoHistoryPreserved": True, "actualWorkFilesVerified": True, "nativeAssAndSrtExports": True}
