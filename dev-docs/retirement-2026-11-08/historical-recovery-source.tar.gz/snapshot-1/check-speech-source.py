from pathlib import Path
import ast, json
root=Path(r'C:\Users\USER\Documents\kdenlive')
paths=['src/mcp/mcpspeech.h','src/mcp/mcpspeech.cpp','tests/mcpspeech_cases.inc','data/scripts/whisper/whispertotext.py','data/scripts/vosk/speechtotext.py']
for rel in paths:
    s=(root/rel).read_text(encoding='utf-8')
    trailing=[i for i,line in enumerate(s.splitlines(),1) if line.rstrip()!=line]
    assert not trailing,(rel,trailing)
    assert not s.startswith('\ufeff'),rel
    if rel.endswith('.py'): ast.parse(s,filename=rel)
print(json.dumps({'checkedFiles':paths,'utf8AndWhitespace':'passed','nativePythonSyntax':'passed','recognitionExecuted':False}))
