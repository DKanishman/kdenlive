from pathlib import Path
import shutil
root=Path(r'C:\Users\USER\Documents\kdenlive');work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
def edit(name,old,new):
 p=root/name;t=p.read_text(encoding='utf-8');assert old in t,name
 b=work/(name.replace('/','_')+'.category-before')
 if not b.exists():shutil.copy2(p,b)
 p.write_text(t.replace(old,new,1),encoding='utf-8',newline='\n')
edit('src/bin/model/markerlistmodel.hpp','    bool importFromJson(const QString &data, bool ignoreConflicts, bool pushUndo = true);','''    bool importFromJson(const QString &data, bool ignoreConflicts, bool pushUndo = true);
    /** Queue a producer marker import and keep category transactions unavailable until it finishes. */
    void scheduleImportFromJson(const QString &data);
    bool hasPendingImport() const;''')
edit('src/bin/model/markerlistmodel.hpp','    std::weak_ptr<DocUndoStack> m_undoStack;','    int m_pendingImports{0};\n    std::weak_ptr<DocUndoStack> m_undoStack;')
edit('src/bin/model/markerlistmodel.cpp','        locks.push_back(&model->m_lock);\n        Changes change{model, {}, {}};','        locks.push_back(&model->m_lock);\n        if (model->m_pendingImports > 0) return false;\n        Changes change{model, {}, {}};')
edit('src/bin/model/markerlistmodel.cpp','            transactionLocks.push_back(&change.model->m_lock);\n        }','            transactionLocks.push_back(&change.model->m_lock);\n            if (change.model->m_pendingImports > 0) return false;\n        }')
marker='bool MarkerListModel::importFromFile(const QString &fileData, bool ignoreConflicts)'
edit('src/bin/model/markerlistmodel.cpp',marker,'''void MarkerListModel::scheduleImportFromJson(const QString &data)
{
    QWriteLocker locker(&m_lock);
    ++m_pendingImports;
    // The QObject context cancels queued work if the model is destroyed, matching
    // the former queued meta-method invocation's lifetime and timing.
    if (!QMetaObject::invokeMethod(this, [this, data] {
            QWriteLocker importLocker(&m_lock);
            const auto finished = qScopeGuard([this] { --m_pendingImports; });
            importFromJson(data, true, false);
        }, Qt::QueuedConnection)) {
        --m_pendingImports;
    }
}

bool MarkerListModel::hasPendingImport() const
{
    READ_LOCK();
    return m_pendingImports > 0;
}

'''+marker)
edit('src/bin/projectclip.cpp','        QMetaObject::invokeMethod(m_markerModel.get(), "importFromJson", Qt::QueuedConnection, Q_ARG(QString, markers), Q_ARG(bool, true), Q_ARG(bool, false));','        m_markerModel->scheduleImportFromJson(markers);')
edit('src/bin/bin.cpp','        if (!model) return false;\n        // ProjectClip queues', '        if (!model || model->hasPendingImport()) return false;\n        // ProjectClip queues')
