from pathlib import Path
import argparse,hashlib,json
parser=argparse.ArgumentParser()
parser.add_argument("--apply",action="store_true")
args=parser.parse_args()
root=Path(r"C:\Users\USER\Documents\kdenlive")
work=Path(__file__).parent
changes=json.loads((work/"manifest.json").read_text(encoding="utf-8"))
pending=[]
for relative,entry in changes.items():
 path=root/relative
 assert hashlib.sha256(path.read_bytes()).hexdigest()==entry["baselineSha256"],"Source changed; review narrow patch before applying: "+relative
 updated=path.read_text(encoding="utf-8")
 for before,after in entry["edits"]:
  assert updated.count(before)==1,(relative,before)
  updated=updated.replace(before,after,1)
 pending.append((path,updated))
if args.apply:
 for path,updated in pending:path.write_text(updated,encoding="utf-8")
print("Applied monitor/UI context guard." if args.apply else "All three baseline hashes/anchors match; live source unchanged.")
