"""Owned real-editor checks after monitor_gui_regressions.verify_source_monitor.
Call verify_monitor_action_context(driver, basic_result). No model mocks or replay.
The parent runner already owns the editor, source fixtures and its Windows Job.
"""
import time


def verify_monitor_action_context(driver, basic_result):
    def require(condition, message):
        if not condition:
            raise AssertionError(message)

    def native():
        return driver.state()

    def monitors():
        return driver.call("get_monitors")["monitors"]

    def wait_monitor(accepted):
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            result = driver.call("monitor_job_status", {"jobId": accepted["jobId"]})
            job = result["job"]
            if job["status"] == "completed":
                return result["monitors"]
            require(job["status"] not in ("failed", "interrupted", "needsUserAction"),
                    f"Monitor context fixture stopped: {job}")
            time.sleep(.02)
        raise AssertionError("Monitor context fixture did not complete")

    def control(operation, monitor="source", expected_monitor=None, **fields):
        state = native()
        token = expected_monitor if expected_monitor is not None else monitors()["expectedMonitor"]
        return wait_monitor(driver.call("control_monitor", {
            "expectedState": state["expectedState"], "expectedMonitor": token,
            "monitor": monitor, "operation": operation, **fields,
        }))

    def ui():
        value = driver.call("get_ui")["ui"]
        fingerprint = value.get("monitorFingerprint")
        require(isinstance(fingerprint, str) and len(fingerprint) == 64,
                "get_ui omitted its native monitor-context fingerprint")
        require(fingerprint == monitors()["expectedMonitor"],
                "Widget context differs from the native monitor token while paused")
        return value

    def zone_state(value):
        return {name: (value[name]["selectedBinId"], value[name]["requestedFrame"], value[name]["zone"])
                for name in ("source", "project")}

    def reject_action(old_ui, action):
        before, history = monitors(), native()
        result = driver.client.tool("trigger_action", {
            "expectedUi": old_ui["uiToken"], "actionId": action,
        }, error_code="STALE_UI")
        require("jobId" not in result, "Stale action was queued before rejection")
        after, state = monitors(), native()
        require(zone_state(after) == zone_state(before), "Rejected monitor action changed native cursor/zone/source")
        require((state["undoIndex"], state["undoCount"]) == (history["undoIndex"], history["undoCount"]),
                "Rejected monitor action changed native history")

    first = basic_result["binId"]
    second = basic_result["sameUrlSources"]["secondBinId"]
    require(first != second, "Context fixture requires distinct same-URL bin identities")
    control("open_bin_clip", binId=first, frame=20)
    old = ui()
    require(any(a["id"] == "mark_in" and a["enabled"] for a in old["actions"]),
            "Native Set Zone In action is unavailable")
    changed = control("open_bin_clip", binId=second, frame=20)
    current = ui()
    require(changed["source"]["selectedBinId"] == second, "Native source identity did not change")
    require(current["monitorFingerprint"] != old["monitorFingerprint"], "Same-URL source switch kept the UI monitor context")
    reject_action(old, "mark_in")

    old = ui()
    control("seek", frame=25)
    current = ui()
    require(current["monitorFingerprint"] != old["monitorFingerprint"], "Paused native seek kept the UI monitor context")
    reject_action(old, "mark_out")

    quick = driver.call("get_quick_ui", {"limit": 64})["ui"]
    target = next((c for c in quick["controls"] if "focus" in c.get("operations", [])
                   and c.get("visible", True) and c.get("enabled", True)), None)
    require(target is not None, "No actual native Quick control was available for the stale-context check")
    control("seek", frame=26)
    before_quick, before_state = monitors(), native()
    driver.client.tool("activate_quick_control", {
        "expectedQuick": quick["quickToken"], "controlId": target["id"], "operation": "focus",
    }, error_code="STALE_QUICK_UI")
    require(zone_state(monitors()) == zone_state(before_quick), "Rejected Quick action changed monitor state")
    after_state = native()
    require((after_state["undoIndex"], after_state["undoCount"]) == (before_state["undoIndex"], before_state["undoCount"]),
            "Rejected Quick action changed history")

    old = ui()
    activated = control("activate", monitor="project")
    current = ui()
    require(activated["project"]["active"], "Native project monitor did not activate")
    require(current["monitorFingerprint"] != old["monitorFingerprint"], "Native active-monitor switch kept the UI context")
    reject_action(old, "mark_in")

    control("activate")
    control("set_zone", inFrame=3, outFrameExclusive=37)
    played = control("loop_zone")
    require(played["source"]["playing"], "Native loop playback did not start")
    playing_ui = driver.call("get_ui")["ui"]
    playing_token = played["expectedMonitor"]
    require(playing_ui.get("monitorFingerprint") == playing_token, "Playback monitor context was not bound to UI")
    time.sleep(.6)
    during = monitors()
    during_ui = driver.call("get_ui")["ui"]
    require(during["source"]["playing"] and during["expectedMonitor"] == playing_token,
            "Native monitor token changed from ordinary playback")
    require(during_ui.get("monitorFingerprint") == playing_token,
            "UI monitor fingerprint changed from ordinary playback")
    # Reuse the original playback token after multiple frames; this must remain
    # usable for pausing even though the full UI still contains live timecodes.
    paused = control("pause", expected_monitor=playing_token)
    require(not paused["source"]["playing"], "Original monitor context could not pause after playback drift")
    control("activate", monitor="project")
    return {"passed": True, "sameUrlIdentityGuard": True, "pausedSeekGuard": True,
            "activeMonitorGuard": True, "quickContextGuard": True,
            "staleActionsQueued": False, "stablePlaybackMonitorFingerprint": True,
            "originalPlaybackTokenPaused": True,
            "fullUiTokenDriftedDuringPlayback": playing_ui["uiToken"] != during_ui["uiToken"],
            "genericUiPlaybackScope": "The existing full UI token includes live timecodes; this test validates stable monitor context and typed pause."}
