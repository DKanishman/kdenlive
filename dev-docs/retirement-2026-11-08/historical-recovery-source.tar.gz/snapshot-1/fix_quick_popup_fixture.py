from pathlib import Path
file=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpquick_cases.inc')
text=file.read_text(encoding='utf-8')
text=text.replace('#include <QVBoxLayout>','#include <QVBoxLayout>\n#include <QWindow>',1)
start=text.index('TEST_CASE("MCP nested context menus retain ancestor closure when the submenu is enumerated first"')
end=text.index('\nTEST_CASE(',start+1)
case=text[start:end]
case=case.replace('''    window.show();
    auto *one''','''    window.show();
    // Drain native window exposure before opening a popup. A delayed Windows
    // activation/exposure event can otherwise dismiss an already-open menu.
    QElapsedTimer exposure;
    exposure.start();
    while ((!window.windowHandle() || !window.windowHandle()->isExposed()) && exposure.elapsed() < 3000)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
    REQUIRE(window.windowHandle());
    REQUIRE(window.windowHandle()->isExposed());
    auto *one''',1)
case=case.replace('''    one->popup(window.mapToGlobal(QPoint(0, 40)));
    two->popup(window.mapToGlobal(QPoint(150, 40)));
    QCoreApplication::processEvents();
    one->hide();
    two->hide();''','''    one->popup(window.mapToGlobal(QPoint(0, 40)));
    QCoreApplication::processEvents();
    one->hide();
    QCoreApplication::processEvents();
    two->popup(window.mapToGlobal(QPoint(150, 40)));
    QCoreApplication::processEvents();
    two->hide();
    QCoreApplication::processEvents();''',1)
case=case.replace('''    root->setTitle(QStringLiteral("Context root"));
    submenu->setTitle(QStringLiteral("Nested context"));
    root->addMenu(submenu);''','''    root->setTitle(QStringLiteral("Context root"));
    submenu->setTitle(QStringLiteral("Nested context"));
    // Give the native popup an actual submenu owner after selecting the
    // deliberately reversed inventory order; addMenu(QMenu*) does not reparent.
    submenu->setParent(root);
    root->addMenu(submenu);''',1)
assert case!=text[start:end]
text=text[:start]+case+text[end:]
file.write_text(text,encoding='utf-8',newline='\n')
print('Quick test native popup setup synchronized; visibility, reversed order and closure assertions retained.')
