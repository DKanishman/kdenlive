$ErrorActionPreference = 'Stop'
$taskSdl = 'C:\Users\USER\.codex\work\kdenlive-mcp-completion\sdl-lifetime-validation'
$craftPrefix = 'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot'
$env:CRAFT_PYTHON = 'C:\Users\USER\AppData\Local\Python\pythoncore-3.14-64\python.exe'
function Clear-Host {}
. (Join-Path $craftPrefix 'craft\craftenv.ps1')
Set-Location -LiteralPath $taskSdl
& cmake -S (Join-Path $taskSdl 'source') -B (Join-Path $taskSdl 'build') -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo "-DCMAKE_PREFIX_PATH=$craftPrefix" *> (Join-Path $taskSdl 'configure.log')
if ($LASTEXITCODE) {Get-Content -LiteralPath (Join-Path $taskSdl 'configure.log') -Tail 30; exit $LASTEXITCODE}
& cmake --build (Join-Path $taskSdl 'build') --parallel 2 *> (Join-Path $taskSdl 'build.log')
Get-Content -LiteralPath (Join-Path $taskSdl 'build.log') -Tail 30
exit $LASTEXITCODE
