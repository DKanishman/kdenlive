from pathlib import Path
import difflib, hashlib, json, shutil, subprocess
ROOT=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\sdl-lifetime-validation')
MLT=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\short\cba01e4\mlt')
PREFIX=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot')
OUT=Path(r'C:\Users\USER\Documents\kdenlive\packaging\patches\mlt-7.43.0')
OUT.mkdir(parents=True,exist_ok=True)
base=subprocess.run(['git','-C',str(MLT),'rev-parse','HEAD'],text=True,capture_output=True,check=True).stdout.strip()
assert base=='eca4e32d28e2c588a9c3b7c23e2276d9cd1f4edb'
for relative,new_file,filename in [('src/modules/sdl2/consumer_sdl2_audio.c',ROOT/'source'/'consumer_sdl2_audio.c','sdl2-audio-device-lifetime.patch'),('src/modules/openfx/factory.c',MLT/'src/modules/openfx/factory.c','openfx-factory-export.patch')]:
    original=subprocess.run(['git','-C',str(MLT),'show',f'HEAD:{relative}'],capture_output=True,check=True).stdout.decode('utf-8')
    changed=new_file.read_text(encoding='utf-8')
    patch=''.join(difflib.unified_diff(original.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile=f'a/{relative}',tofile=f'b/{relative}'))
    assert patch
    (OUT/filename).write_text(patch,encoding='utf-8',newline='\n')
old=(ROOT/'regression.py').read_text(encoding='utf-8-sig')
old=old.replace('import ctypes as C, hashlib, importlib.util, json, os, shutil, sys, time','import argparse, ctypes as C, hashlib, json, os, shutil, subprocess, sys, time, uuid')
start=old.index("ROOT = Path(r'")
end=old.index("    cases = ",start)
new='''parser=argparse.ArgumentParser(description="Windows native SDL2 consumer lifetime regression. Uses dummy audio and generated colors only.")
parser.add_argument('--prefix',type=Path,required=True)
parser.add_argument('--old-module',type=Path,required=True)
parser.add_argument('--new-module',type=Path,required=True)
parser.add_argument('--work-dir',type=Path,required=True)
parser.add_argument('--child',nargs=3,metavar=('MODE','CASE','HOLD'))
args=parser.parse_args()
if os.name!='nt': parser.error('This dependency regression currently supports Windows only.')
PREFIX=args.prefix.resolve(strict=True)
ROOT=args.work_dir.resolve()
if args.child is None:
    ROOT=ROOT/('sdl-lifetime-'+uuid.uuid4().hex[:12]); ROOT.mkdir(parents=True)
    for mode,module in [('old',args.old_module),('new',args.new_module)]:
        repository=ROOT/mode; repository.mkdir()
        shutil.copy2(PREFIX/'lib'/'mlt'/'mltcore.dll',repository/'mltcore.dll')
        shutil.copy2(module.resolve(strict=True),repository/'mltsdl2.dll')
'''
old=old[:start]+new+old[end:]
old=old.replace("    logroot=ROOT/('run-'+str(time.time_ns())); logroot.mkdir(); results=[]; job=owned.OwnedJob()","    logroot=ROOT; results=[]")
old=old.replace("    try:\n        for mode, case, hold in cases:","    for mode, case, hold in cases:")
first=old.index('    for mode, case, hold in cases:')
end=old.index('    manifest=',first)
block=old[first:end]
block=block.replace('    finally: job.close()\n','')
lines=block.splitlines()
block='\n'.join([lines[0]]+[line[4:] for line in lines[1:]])+'\n'
block=block.replace("        owned.run_logged([sys.executable, '-B', __file__, '--child', mode, case, str(hold)], log, env, job, 55)","""        command=[sys.executable,'-B',__file__,'--prefix',str(PREFIX),'--old-module',str(args.old_module.resolve()),'--new-module',str(args.new_module.resolve()),'--work-dir',str(ROOT),'--child',mode,case,str(hold)]
        startup=subprocess.STARTUPINFO(); startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW; startup.wShowWindow=subprocess.SW_HIDE
        with log.open('xb') as stream:
            result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=env,timeout=55,startupinfo=startup,creationflags=subprocess.CREATE_NO_WINDOW)
        if result.returncode: raise RuntimeError(f'Native case failed ({result.returncode}); inspect {log}')""")
old=old[:first]+block+old[end:]
old=old.replace("hashlib.sha256((PREFIX/'lib'/'mlt'/'mltsdl2.dll').read_bytes()).hexdigest()","hashlib.sha256(args.old_module.read_bytes()).hexdigest()")
old=old.replace("hashlib.sha256((ROOT/'build'/'mltsdl2.dll').read_bytes()).hexdigest()","hashlib.sha256(args.new_module.read_bytes()).hexdigest()")
old=old.replace("mode, case, hold = sys.argv[-3], sys.argv[-2], int(sys.argv[-1])","mode,case,hold=args.child; hold=int(hold)")
header='''# SPDX-FileCopyrightText: 2026 Kdenlive MCP contributors
# SPDX-License-Identifier: GPL-3.0-or-later
"""Exercise real MLT consumers and SDL device status across owned lifetimes."""
'''
compile(header+old,str(OUT/'test_sdl2_audio_lifetime.py'),'exec')
(OUT/'test_sdl2_audio_lifetime.py').write_text(header+old,encoding='utf-8',newline='\n')
repository=ROOT/'runtime-repository'; repository.mkdir(exist_ok=False)
for source in (PREFIX/'lib'/'mlt').glob('*.dll'): shutil.copy2(source,repository/source.name)
shutil.copy2(ROOT/'build'/'mltsdl2.dll',repository/'mltsdl2.dll')
shutil.copy2(ROOT.parent/'openfx-approved-validation'/'new'/'mltopenfx.dll',repository/'mltopenfx.dll')
manifest={'mltSourceBase':base,'repository':str(repository),'modules':{name:hashlib.sha256((repository/name).read_bytes()).hexdigest() for name in ('mltsdl2.dll','mltopenfx.dll')},'craftInstalledRuntimeModified':False,'regressionReport':str(ROOT/'report.json')}
(ROOT/'runtime-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))
