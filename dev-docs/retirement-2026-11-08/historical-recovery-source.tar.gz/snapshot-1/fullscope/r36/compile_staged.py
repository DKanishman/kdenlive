from pathlib import Path
import ctypes as C,json,subprocess,sys
stage=Path(__file__).resolve().parent
build=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot\build\kde\kdemultimedia\kdenlive\work\build')
entries=json.loads((build/'compile_commands.json').read_text(encoding='utf-8'))
entry=next(row for row in entries if row['file'].replace('\\','/').endswith('/mcp/mcpprofiles.cpp'))
shell=C.WinDLL('shell32',use_last_error=True);shell.CommandLineToArgvW.argtypes=[C.c_wchar_p,C.POINTER(C.c_int)];shell.CommandLineToArgvW.restype=C.POINTER(C.c_wchar_p)
count=C.c_int();vector=shell.CommandLineToArgvW(entry['command'],C.byref(count));args=[vector[i] for i in range(count.value)]
kernel=C.WinDLL('kernel32',use_last_error=True);kernel.LocalFree.argtypes=[C.c_void_p];kernel.LocalFree(C.cast(vector,C.c_void_p))
args=[arg for arg in args if not arg.lower().startswith(('/fo','/fd','/fp','/yu','/fi','/yc')) and arg not in ('-c','/c','/Zi','/FS') and arg.replace('\\','/')!=entry['file'].replace('\\','/')]
args+=['/I'+r'C:\Users\USER\Documents\kdenlive\src\mcp','/Zs',str(stage/'mcpprojectextras.cpp')]
with (stage/'syntax.log').open('wb') as log:code=subprocess.run(args,cwd=stage,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
print((stage/'syntax.log').read_text(encoding='utf-8',errors='replace')[-8000:]);sys.exit(code)
