from pathlib import Path
import difflib,hashlib,json
ROOT=Path(r'C:\Users\USER\Documents\kdenlive'); STAGE=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\fullscope\advanced')
manifestPath=STAGE/'native-manifest.json';manifest=json.loads(manifestPath.read_text(encoding='utf-8'))
def stage(relative,text):
    original=(ROOT/relative).read_text(encoding='utf-8'); assert original!=text
    file=STAGE/relative;file.parent.mkdir(parents=True,exist_ok=True);file.write_text(text,encoding='utf-8',newline='\n')
    (STAGE/(relative.replace('/','_')+'.patch')).write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative)),encoding='utf-8',newline='\n')
    manifest['files']=[item for item in manifest['files'] if item['path']!=relative]
    manifest['files'].append({'path':relative,'originalSha256':hashlib.sha256((ROOT/relative).read_bytes()).hexdigest(),'stagedSha256':hashlib.sha256(file.read_bytes()).hexdigest()})
relative='src/lib/audio/audioEnvelope.h';text=(ROOT/relative).read_text(encoding='utf-8')
text=text.replace('#include <memory>','#include <memory>\n#include <atomic>\n#include <QString>',1)
text=text.replace('    QImage drawEnvelope();','''    QImage drawEnvelope();
    void cancel();
    bool isFinished() const;
    bool wasCancelled() const;
    QString error();''',1)
text=text.replace('''        qint64 amplitudeMax = 0;''','''        qint64 amplitudeMax = 0;
        QString error;''',1)
text=text.replace('''    size_t m_envelopeSize;''','''    size_t m_envelopeSize{0};
    QString m_inputError;
    mutable std::atomic_bool m_cancelled{false};
    bool m_started{false};''',1)
text=text.replace('''    void envelopeReady(AudioEnvelope *envelope);''','''    void envelopeReady(AudioEnvelope *envelope);
    void progress(int percent);''',1)
stage(relative,text)
relative='src/lib/audio/audioEnvelope.cpp';text=(ROOT/relative).read_text(encoding='utf-8')
text=text.replace('#include "bin/bin.h"','#include "bin/bin.h"\n#include "bin/projectitemmodel.h"',1)
start=text.index('    std::shared_ptr<ProjectClip> clip =',text.index('AudioEnvelope::AudioEnvelope'))
end=text.index('\n}\n\nAudioEnvelope::~',start)
text=text[:start]+'''    connect(&m_watcher, &QFutureWatcherBase::finished, this, [this] { Q_EMIT envelopeReady(this); });
    const auto model = pCore ? pCore->projectItemModel() : nullptr;
    const auto clip = model ? model->getClipByBinID(binId) : nullptr;
    if (!clip || !clip->statusReady()) {
        m_inputError = QStringLiteral("The audio source is missing or not ready.");
        return;
    }
    auto source = clip->cloneProducer();
    if (!source || !source->is_valid() || !clip->hasAudio()) {
        m_inputError = QStringLiteral("The source has no decodable audio producer.");
        return;
    }
    const size_t available = size_t(qMax(0, source->get_playtime()));
    if (offset >= available || (length && length > available - offset) || available > 1000000) {
        m_inputError = QStringLiteral("The requested audio range is empty or exceeds the analysis frame limit.");
        return;
    }
    const size_t selected = length ? length : available - offset;
    // Always analyze the exact requested source window, including short clips.
    // A native cut maps its frame zero to the requested source-in.
    m_producer.reset(source->cut(int(offset), int(offset + selected - 1)));
    m_offset = 0;
    if (!m_producer || !m_producer->is_valid()) {
        m_inputError = QStringLiteral("The native audio source cut could not be created.");
        return;
    }
    m_envelopeSize = selected;
    m_producer->set("set.test_image", 1);
    if (stream.first > -1) {
        m_producer->parent().set("audio_index", stream.first);
        m_producer->parent().set("astream", stream.second);
    }
    m_info = std::make_unique<AudioInfo>(m_producer);
'''+text[end:]
start=text.index('AudioEnvelope::~AudioEnvelope()')
end=text.index('\nconst AudioEnvelope::AudioSummary &AudioEnvelope::audioSummary()',start)
text=text[:start]+'''AudioEnvelope::~AudioEnvelope()
{
    disconnect(&m_watcher, nullptr, this, nullptr);
    cancel();
    if (m_started) {
        m_audioSummary.waitForFinished();
        m_watcher.waitForFinished();
    }
}

void AudioEnvelope::startComputeEnvelope()
{
    if (m_started) return;
    m_started = true;
    m_audioSummary = QtConcurrent::run(&AudioEnvelope::loadAndNormalizeEnvelope, this);
    m_watcher.setFuture(m_audioSummary);
}

bool AudioEnvelope::hasComputationStarted() const { return m_started; }
void AudioEnvelope::cancel() { m_cancelled.store(true); }
bool AudioEnvelope::isFinished() const { return m_started && m_audioSummary.isFinished(); }
bool AudioEnvelope::wasCancelled() const { return m_cancelled.load(); }
QString AudioEnvelope::error() { return audioSummary().error; }
'''+text[end:]
start=text.index('AudioEnvelope::AudioSummary AudioEnvelope::loadAndNormalizeEnvelope() const')
end=text.index('\nint AudioEnvelope::clipId() const',start)
text=text[:start]+'''AudioEnvelope::AudioSummary AudioEnvelope::loadAndNormalizeEnvelope() const
{
    AudioSummary summary;
    if (!m_inputError.isEmpty()) { summary.error = m_inputError; return summary; }
    if (!m_producer || !m_producer->is_valid() || !m_envelopeSize || !m_info || m_info->size() < 1) {
        summary.error = QStringLiteral("The selected source has no audio analysis data.");
        return summary;
    }
    summary.audioAmplitudes.resize(m_envelopeSize);
    for (size_t i = 0; i < m_envelopeSize; ++i) {
        if (m_cancelled.load()) { summary.audioAmplitudes.clear(); summary.error = QStringLiteral("Audio analysis cancelled."); return summary; }
        m_producer->seek(int(i));
        std::unique_ptr<Mlt::Frame> frame(m_producer->get_frame());
        if (!frame || !frame->is_valid()) { summary.error = QStringLiteral("Native audio frame decoding failed."); break; }
        mlt_audio_format format = mlt_audio_s16;
        int rate = 48000, channels = 1;
        int samples = mlt_audio_calculate_frame_samples(float(m_producer->get_fps()), rate, int(i));
        const auto *data = static_cast<const qint16 *>(frame->get_audio(format, rate, channels, samples));
        if (!data || format != mlt_audio_s16 || rate <= 0 || samples <= 0 || samples > 384000 || channels <= 0 || channels > 64) {
            summary.error = QStringLiteral("Native audio decoding returned an invalid sample buffer.");
            break;
        }
        qint64 amplitude = 0;
        for (qsizetype sample = 0; sample < qsizetype(samples) * channels; ++sample) amplitude += std::abs(int(data[sample]));
        summary.audioAmplitudes[i] = amplitude / channels;
        if (i % 25 == 0) Q_EMIT const_cast<AudioEnvelope *>(this)->progress(int(100 * i / m_envelopeSize));
    }
    if (!summary.error.isEmpty()) { summary.audioAmplitudes.clear(); return summary; }
    long double total = 0;
    for (const auto value : summary.audioAmplitudes) total += value;
    const qint64 mean = qint64(total / summary.audioAmplitudes.size());
    for (auto &value : summary.audioAmplitudes) {
        value -= mean;
        summary.amplitudeMax = std::max(summary.amplitudeMax, qAbs(value));
    }
    if (!summary.amplitudeMax) {
        summary.error = QStringLiteral("The selected audio is silent or has no varying alignment evidence.");
        summary.audioAmplitudes.clear();
    }
    return summary;
}
'''+text[end:]
stage(relative,text)
relative='src/lib/audio/audioCorrelation.h';text=(ROOT/relative).read_text(encoding='utf-8')
text=text.replace('#include <QList>','#include <QList>\n#include <QSet>',1)
text=text.replace('    void addChild(AudioEnvelope *envelope);','    void addChild(AudioEnvelope *envelope);\n    void cancel();',1)
text=text.replace('    QList<AudioCorrelationInfo *> m_correlations;','''    QList<AudioCorrelationInfo *> m_correlations;
    QSet<AudioEnvelope *> m_processed;
    bool m_cancelled{false};''',1)
text=text.replace('    void gotAudioAlignData(int, int);','''    void gotAudioAlignData(int, int);
    void alignmentFailed(int clipId, const QString &reason);
    void alignmentCancelled(int clipId);''',1)
stage(relative,text)
relative='src/lib/audio/audioCorrelation.cpp';text=(STAGE/relative).read_text(encoding='utf-8')
text=text.replace('''AudioCorrelation::~AudioCorrelation()
{
    for (AudioEnvelope *envelope''','''AudioCorrelation::~AudioCorrelation()
{
    cancel();
    for (AudioEnvelope *envelope''',1)
start=text.index('void AudioCorrelation::slotAnnounceEnvelope()')
end=text.index('\nint AudioCorrelation::getShift(',start)
text=text[:start]+'''void AudioCorrelation::cancel()
{
    m_cancelled = true;
    m_mainTrackEnvelope->cancel();
    for (auto *envelope : std::as_const(m_children)) envelope->cancel();
}

void AudioCorrelation::slotAnnounceEnvelope()
{
    const QString error = m_mainTrackEnvelope->error();
    Q_EMIT displayMessage(error.isEmpty() ? i18n("Audio analysis finished") : error,
                          error.isEmpty() ? OperationCompletedMessage : ErrorMessage, 300);
    for (auto *envelope : std::as_const(m_children))
        if (envelope->isFinished()) slotProcessChild(envelope);
}

void AudioCorrelation::addChild(AudioEnvelope *envelope)
{
    Q_ASSERT(envelope && !envelope->hasComputationStarted());
    if (!envelope) return;
    // Own running children immediately; otherwise closing/changing the
    // reference can orphan a worker whose producer outlives the editor.
    envelope->setParent(this);
    m_children.append(envelope);
    m_correlations.append(nullptr);
    connect(envelope, &AudioEnvelope::envelopeReady, this, &AudioCorrelation::slotProcessChild);
    if (m_cancelled) envelope->cancel();
    envelope->startComputeEnvelope();
}

void AudioCorrelation::slotProcessChild(AudioEnvelope *envelope)
{
    if (!envelope || m_processed.contains(envelope) || !m_mainTrackEnvelope->isFinished()) return;
    m_processed.insert(envelope);
    const int index = m_children.indexOf(envelope);
    if (index < 0) return;
    if (m_cancelled || envelope->wasCancelled() || m_mainTrackEnvelope->wasCancelled()) {
        Q_EMIT alignmentCancelled(envelope->clipId());
        return;
    }
    const QString error = !m_mainTrackEnvelope->error().isEmpty() ? m_mainTrackEnvelope->error() : envelope->error();
    if (!error.isEmpty()) {
        Q_EMIT displayMessage(error, ErrorMessage, 500);
        Q_EMIT alignmentFailed(envelope->clipId(), error);
        return;
    }
    const auto &envMain = m_mainTrackEnvelope->envelope();
    const auto &envSub = envelope->envelope();
    if (envMain.empty() || envSub.empty()) {
        Q_EMIT alignmentFailed(envelope->clipId(), QStringLiteral("The audio envelope is empty."));
        return;
    }
    auto *info = new AudioCorrelationInfo(envMain.size(), envSub.size());
    qint64 maximum = 0;
    if (envSub.size() > 200) FFTCorrelation::correlate(envMain.data(), envMain.size(), envSub.data(), envSub.size(), info->correlationVector());
    else { correlate(envMain.data(), envMain.size(), envSub.data(), envSub.size(), info->correlationVector(), &maximum); info->setMax(maximum); }
    m_correlations[index] = info;
    Q_EMIT gotAudioAlignData(envelope->clipId(), getShift(index));
}
'''+text[end:]
old='''    size_t indexOffset = m_correlations.at(childIndex)->maxIndex();
    indexOffset -= m_children.at(childIndex)->envelope().size();
    indexOffset += m_children.at(childIndex)->offset();

    return int(indexOffset);'''
new='''    Q_ASSERT(m_correlations.at(childIndex));
    const qint64 offset = qint64(m_correlations.at(childIndex)->maxIndex()) - qint64(m_children.at(childIndex)->envelope().size()) +
                          qint64(m_children.at(childIndex)->offset());
    return offset < std::numeric_limits<int>::min() || offset > std::numeric_limits<int>::max() ? 0 : int(offset);'''
assert old in text;text=text.replace(old,new,1)
stage(relative,text)
relative='src/timeline2/model/clipmodel.cpp';text=(ROOT/relative).read_text(encoding='utf-8');text=text.replace('        return recTC + getIn();','        return qint64(recTC) + getIn();',1);stage(relative,text)
manifestPath.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Native exact-range/cancellation/error/ownership repairs staged only.')
