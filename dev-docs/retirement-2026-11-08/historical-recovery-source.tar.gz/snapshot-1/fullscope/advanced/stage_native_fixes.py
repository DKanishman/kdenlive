from pathlib import Path
import difflib,hashlib,json
ROOT=Path(r'C:\Users\USER\Documents\kdenlive')
STAGE=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\fullscope\advanced')
manifest=[]
def stage(relative, changed):
    original=(ROOT/relative).read_text(encoding='utf-8')
    assert original!=changed
    out=STAGE/relative; out.parent.mkdir(parents=True,exist_ok=True);out.write_text(changed,encoding='utf-8',newline='\n')
    patch=''.join(difflib.unified_diff(original.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
    (STAGE/(relative.replace('/','_')+'.patch')).write_text(patch,encoding='utf-8',newline='\n')
    manifest.append({'path':relative,'originalSha256':hashlib.sha256((ROOT/relative).read_bytes()).hexdigest(),'stagedSha256':hashlib.sha256(out.read_bytes()).hexdigest()})
relative='src/lib/audio/audioCorrelation.cpp';text=(ROOT/relative).read_text(encoding='utf-8')
text=text.replace('#include <iostream>','#include <iostream>\n#include <algorithm>\n#include <limits>',1)
start=text.index('void AudioCorrelation::correlate(')
text=text[:start]+'''void AudioCorrelation::correlate(const qint64 *envMain, size_t sizeMain, const qint64 *envSub, size_t sizeSub, qint64 *correlation, qint64 *out_max)
{
    Q_ASSERT(correlation != nullptr);
    if (out_max) *out_max = 0;
    // Empty input has no alignment evidence. Initialize every advertised output
    // element, including the zero-overlap endpoints, before returning.
    std::fill(correlation, correlation + sizeMain + sizeSub + 1, qint64(0));
    if (!sizeMain || !sizeSub || !envMain || !envSub) return;
    if (sizeMain > size_t(std::numeric_limits<qint64>::max()) || sizeSub > size_t(std::numeric_limits<qint64>::max())) return;
    const qint64 mainSize = qint64(sizeMain), subSize = qint64(sizeSub);
    long double largestMain = 0, largestSub = 0;
    for (size_t i = 0; i < sizeMain; ++i) largestMain = std::max(largestMain, std::abs(static_cast<long double>(envMain[i])));
    for (size_t i = 0; i < sizeSub; ++i) largestSub = std::max(largestSub, std::abs(static_cast<long double>(envSub[i])));
    if (largestMain == 0 || largestSub == 0) return;
    // Preserve ordinary integer results, but scale values before products that
    // could overflow. The scale is constant across lags, preserving peak order.
    const long double worst = largestMain * largestSub * static_cast<long double>(std::min(sizeMain, sizeSub));
    const long double scale = worst > static_cast<long double>(std::numeric_limits<qint64>::max()) / 4
                                ? (static_cast<long double>(std::numeric_limits<qint64>::max()) / 4) / worst : 1;
    qint64 maximum = 0;
    // Lags are signed. An unsigned -sizeSub starts beyond sizeMain and leaves
    // the whole vector uninitialized for the native short-envelope branch.
    for (qint64 shift = -subSize; shift <= mainSize; ++shift) {
        const qint64 mainStart = std::max(qint64(0), shift);
        const qint64 subStart = std::max(qint64(0), -shift);
        const qint64 count = std::min(mainSize - mainStart, subSize - subStart);
        long double sum = 0;
        for (qint64 i = 0; i < count; ++i)
            sum += static_cast<long double>(envMain[size_t(mainStart + i)]) * static_cast<long double>(envSub[size_t(subStart + i)]) * scale;
        const qint64 value = qint64(std::llround(sum));
        correlation[size_t(subSize + shift)] = value;
        maximum = std::max(maximum, value);
    }
    if (out_max) *out_max = maximum;
}
'''
stage(relative,text)
relative='src/bin/projectclip.cpp';text=(ROOT/relative).read_text(encoding='utf-8')
text=text.replace('#include <QtMath>','#include <QtMath>\n#include <cmath>\n#include <limits>',1)
text=text.replace('return m_recStartCodePerStream.values().first() > 0;','return m_recStartCodePerStream.values().first() >= 0;',1)
text=text.replace('''    int recTime = m_masterProducer->get_int(cacheKey.toUtf8().constData());
    if (recTime > 0) {''','''    int recTime = m_masterProducer->get_int(cacheKey.toUtf8().constData());
    if (m_masterProducer->property_exists(cacheKey.toUtf8().constData()) && recTime >= 0) {''',1)
start=text.index('    int64_t timecode_ms =',text.index('int ProjectClip::getStartTCFromProperties'))
end=text.index('    const QString streamKey =',start)
text=text[:start]+'''    const double fps = pCore->getCurrentFps();
    const auto framesFromSeconds = [fps](long double seconds) {
        const long double frames = seconds * fps;
        if (!std::isfinite(fps) || fps <= 0 || !std::isfinite(frames) || frames < 0 ||
            frames > static_cast<long double>(std::numeric_limits<int>::max()) - 0.5L) return -1;
        return int(std::llround(frames));
    };
    if (m_masterProducer->property_exists("timecode")) {
        bool valid = false;
        const qint64 milliseconds = QString::fromUtf8(m_masterProducer->get("timecode")).toLongLong(&valid);
        if (valid && milliseconds >= 0) return framesFromSeconds(static_cast<long double>(milliseconds) / 1000);
    }

    const int sIndex = qMax(0, streamIndex);
    // Broadcast Wave time_reference is measured in audio samples, not project
    // frames or milliseconds. Convert once using its actual sample rate.
    if (m_masterProducer->property_exists("meta.attr.time_reference.markup")) {
        bool validSamples = false, validRate = false;
        const qint64 audioSamples = QString::fromUtf8(m_masterProducer->get("meta.attr.time_reference.markup")).toLongLong(&validSamples);
        const QString sampleRateKey = QStringLiteral("meta.media.%1.codec.sample_rate").arg(sIndex);
        const qint64 sampleRate = getProducerProperty(sampleRateKey).toLongLong(&validRate);
        if (validSamples && audioSamples >= 0 && validRate && sampleRate > 0)
            return framesFromSeconds(static_cast<long double>(audioSamples) / sampleRate);
        return -1;
    }

'''+text[end:]
stage(relative,text)
(STAGE/'native-manifest.json').write_text(json.dumps({'status':'staged_not_applied','files':manifest},indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))
