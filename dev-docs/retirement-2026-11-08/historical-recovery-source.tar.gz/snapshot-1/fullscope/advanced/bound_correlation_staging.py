from pathlib import Path
import difflib,hashlib,json
ROOT=Path(r'C:\Users\USER\Documents\kdenlive'); STAGE=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\fullscope\advanced')
relative='src/lib/audio/audioCorrelation.cpp'; staged=STAGE/relative;text=staged.read_text(encoding='utf-8')
text=text.replace('''    std::fill(correlation, correlation + sizeMain + sizeSub + 1, qint64(0));
    if (!sizeMain || !sizeSub || !envMain || !envSub) return;
    if (sizeMain > size_t(std::numeric_limits<qint64>::max()) || sizeSub > size_t(std::numeric_limits<qint64>::max())) return;''','''    const size_t maxIndex = size_t(std::numeric_limits<qint64>::max());
    if (sizeMain > maxIndex || sizeSub > maxIndex || sizeMain > maxIndex - sizeSub - 1) return;
    std::fill(correlation, correlation + sizeMain + sizeSub + 1, qint64(0));
    if (!sizeMain || !sizeSub || !envMain || !envSub) return;''',1)
staged.write_text(text,encoding='utf-8',newline='\n')
old=(ROOT/relative).read_text(encoding='utf-8')
(STAGE/(relative.replace('/','_')+'.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative)),encoding='utf-8',newline='\n')
manifest=STAGE/'native-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'))
for entry in data['files']:
    if entry['path']==relative:entry['stagedSha256']=hashlib.sha256(staged.read_bytes()).hexdigest()
manifest.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
