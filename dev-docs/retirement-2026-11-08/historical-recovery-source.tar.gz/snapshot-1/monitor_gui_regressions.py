"""Real-editor source/project monitor checks; call_tool returns structuredContent.
The caller supplies an owned red-then-blue 25 fps fixture and an owned output folder.
This helper never resolves unexpected dialogs or overwrites existing output files.
"""
from pathlib import Path
import time

def verify_source_monitor(call_tool, source_path, output_directory):
    output = Path(output_directory)
    assert output.is_dir()
    def native():
        state = call_tool("get_state", {})["state"]
        assert state["ready"], state
        return state
    def monitors():
        return call_tool("get_monitors", {})["monitors"]
    def wait_job(accepted):
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            result = call_tool("monitor_job_status", {"jobId": accepted["jobId"]})
            job = result["job"]
            if job["status"] == "completed":
                assert job["finished"], job
                return result
            if job["status"] in ("failed", "interrupted", "needsUserAction"):
                current_ui = call_tool("get_ui", {}).get("ui", {})
                raise AssertionError({"unexpectedMonitorOutcome": job, "modalId": current_ui.get("modalId"),
                                      "diagnostics": "Full UI is retained in the parent completion report."})
            time.sleep(0.02)
        raise AssertionError("Native monitor did not confirm completion")
    def control(operation, monitor="source", **fields):
        state, view = native(), monitors()
        return wait_job(call_tool("control_monitor", {
            "expectedState": state["expectedState"], "expectedMonitor": view["expectedMonitor"],
            "monitor": monitor, "operation": operation, **fields
        }))
    state = native()
    imported = call_tool("import_media", {"expectedState": state["expectedState"], "path": str(source_path)})
    bin_id = imported["binId"]
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        item = next(b for b in native()["bin"] if b["id"] == bin_id)
        if item["ready"]:
            assert item["status"] == "ready", item
            break
        time.sleep(0.02)
    else:
        raise AssertionError("Monitor fixture did not finish native loading")
    save = call_tool("save_document", {"expectedState": native()["expectedState"],
        "path": str(output / "monitor-validation.kdenlive"), "overwrite": False})
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        job = call_tool("project_job_status", {"jobId": save["job"]["jobId"]})["job"]
        if job["status"] == "completed":
            break
        if job["status"] in ("failed", "canceled", "needsUserAction") or job.get("needsUserInput"):
            raise AssertionError({"unexpectedSaveOutcome": job, "ui": call_tool("get_ui", {})})
        time.sleep(0.02)
    else:
        raise AssertionError("Native monitor test project did not finish saving")
    assert not native()["modified"], native()
    opened = control("open_bin_clip", binId=bin_id, frame=0)
    source = opened["monitors"]["source"]
    assert source["selectedBinId"] == bin_id and source["seekFinished"], source
    assert source["requestedFrame"] == 0 and source["displayedFrame"] == 0, source
    assert source["displayedSourceVerified"], source
    assert source["displayedClipIdentityVerified"] and source["displayedBinId"] == bin_id, source
    assert source["displayedRequestId"] == opened["job"]["jobId"], opened
    assert source["displayedSourceHash"] == source["sourceHash"], source
    assert source["displayedProducerGeneration"] == source["producerGeneration"], source
    before_noop = native()
    same_bounds = control("open_bin_clip", binId=bin_id, frame=0,
        inFrame=source["zone"]["inFrame"], outFrameExclusive=source["zone"]["outFrameExclusive"])
    after_noop = native()
    assert after_noop["undoIndex"] == before_noop["undoIndex"], (before_noop, after_noop)
    assert after_noop["modified"] == before_noop["modified"] == False, (before_noop, after_noop)
    first_token = same_bounds["monitors"]["expectedMonitor"]
    blue = control("seek", frame=30)
    source = blue["monitors"]["source"]
    assert source["requestedFrame"] == 30 and source["displayedFrame"] == 30, source
    assert source["seekFinished"] and source["displayedSourceVerified"], source
    assert blue["monitors"]["expectedMonitor"] != first_token
    before = monitors()
    previews = []
    for frame, name in ((5, "monitor-source-red.png"), (30, "monitor-source-blue.png")):
        path = output / name
        assert not path.exists()
        state = native()
        preview = call_tool("preview_source_frame", {
            "expectedState": state["expectedState"], "binId": bin_id, "frame": frame,
            "path": str(path), "width": 64, "height": 64
        })
        assert preview["nativeVerified"] and preview["detached"] and path.is_file(), preview
        assert len(preview["sourceHash"]) == 64
        previews.append(preview)
    after = monitors()
    assert after["source"]["requestedFrame"] == before["source"]["requestedFrame"]
    assert after["source"]["selectedBinId"] == before["source"]["selectedBinId"]
    assert after["expectedMonitor"] == before["expectedMonitor"]
    # Two independent bin producers can have the exact same physical URL. A
    # matching resource string or frame number alone must never prove identity.
    second = call_tool("import_media", {"expectedState": native()["expectedState"], "path": str(source_path)})
    second_bin = second["binId"]
    assert second_bin != bin_id, (bin_id, second)
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        item = next(b for b in native()["bin"] if b["id"] == second_bin)
        if item["ready"]:
            assert item["status"] == "ready", item
            break
        time.sleep(0.02)
    else:
        raise AssertionError("Same-URL second source did not finish native loading")
    audio_streams = call_tool("list_media_streams", {"binId": second_bin})["source"]["audioStreams"]
    if audio_streams:
        call_tool("configure_source_audio", {"expectedState": native()["expectedState"], "binId": second_bin,
            "streamId": audio_streams[0]["id"], "gainDb": -6})
    second_open = control("open_bin_clip", binId=second_bin, frame=30)
    second_source = second_open["monitors"]["source"]
    assert second_source["selectedBinId"] == second_source["displayedBinId"] == second_bin, second_source
    assert second_source["displayedSourceVerified"] and second_source["displayedFrame"] == 30, second_source
    assert second_source["displayedRequestId"] == second_open["job"]["jobId"], second_open
    assert second_source["displayedSourceHash"] == second_source["sourceHash"] != after["source"]["sourceHash"], second_source
    assert second_source["producerGeneration"] != after["source"]["producerGeneration"], second_source
    reopened = control("open_bin_clip", binId=bin_id, frame=30)
    original_again = reopened["monitors"]["source"]
    assert original_again["selectedBinId"] == original_again["displayedBinId"] == bin_id, original_again
    assert original_again["displayedSourceVerified"] and original_again["displayedFrame"] == 30, original_again
    assert original_again["displayedRequestId"] == reopened["job"]["jobId"], reopened
    assert original_again["sourceHash"] == original_again["displayedSourceHash"] == after["source"]["sourceHash"], original_again
    assert original_again["producerGeneration"] != second_source["producerGeneration"], original_again
    previous_zone = original_again["zone"]
    zoned = control("set_zone", inFrame=3, outFrameExclusive=37)
    assert zoned["monitors"]["source"]["zone"] == {"inFrame": 3, "outFrameExclusive": 37}
    stepped = control("step", delta=-2)
    assert stepped["job"]["completedFrame"] == 28, stepped
    set_in = control("set_in")
    assert set_in["monitors"]["source"]["zone"]["inFrame"] == 28, set_in
    control("seek", frame=35)
    set_out = control("set_out")
    assert set_out["monitors"]["source"]["zone"]["outFrameExclusive"] == 36, set_out
    control("set_zone", inFrame=3, outFrameExclusive=37)
    last = control("end")
    assert last["job"]["completedFrame"] == last["monitors"]["source"]["maximumFrame"], last
    zone_end = control("zone_end")
    assert zone_end["job"]["completedFrame"] == 36, zone_end
    looped = control("loop_zone")
    assert looped["monitors"]["source"]["playing"], looped
    stable_play_token = looped["monitors"]["expectedMonitor"]
    time.sleep(3)
    during_loop = monitors()
    assert during_loop["source"]["playing"], during_loop
    assert 3 <= during_loop["source"]["requestedFrame"] <= 37, during_loop
    assert during_loop["expectedMonitor"] == stable_play_token, during_loop
    paused = control("pause")
    assert not paused["monitors"]["source"]["playing"], paused
    project = control("activate", monitor="project")
    assert project["monitors"]["project"]["active"], project
    return {"passed": True, "binId": bin_id, "open": opened["job"], "seek": blue["job"],
            "previousZone": previous_zone, "zone": zoned["monitors"]["source"]["zone"], "sameBoundsKeptCleanHistory": True,
            "inOutEndpoints": [set_in["monitors"]["source"]["zone"], set_out["monitors"]["source"]["zone"]],
            "end": last["job"], "loop": looped["job"], "pause": paused["job"],
            "sameUrlSources": {"firstBinId": bin_id, "secondBinId": second_bin,
                "secondSourceEffectApplied": bool(audio_streams), "secondOpen": second_open["job"], "originalReopen": reopened["job"]},
            "previews": previews, "pixelProof": "Native C++ red/blue decoder regression validates PNG pixels."}
