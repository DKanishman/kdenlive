"""GUI regression case. call_tool(name, arguments) returns unwrapped structuredContent."""
import time

def verify_empty_unsaved_profile(call_tool):
    state = call_tool("get_state", {})["state"]
    assert state["ready"] and not state["projectPath"], state
    assert not any(track["clips"] or track["compositions"] for track in state["tracks"]), state
    profiles = call_tool("list_profiles", {})["profiles"]
    choices = [
        p for p in profiles
        if p["width"] <= 1920 and p["height"] <= 1920
        and (p["width"], p["height"], p["frameRateNumerator"] / p["frameRateDenominator"])
            != (state["width"], state["height"], state["fps"])
    ]
    assert choices, "No alternate installed profile for the initial-profile regression"
    profile = min(choices, key=lambda p: p["width"] * p["height"])
    initial_document = state["documentId"]
    initial_history = (state["undoIndex"], state["undoCount"])
    assert initial_history == (0, 0), state
    result = call_tool("set_project_profile", {
        "expectedState": state["expectedState"], "profile": profile["id"]
    })
    job_id = result["job"]["jobId"]
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        status = call_tool("project_job_status", {"jobId": job_id})
        job = status["job"]
        if job["status"] in ("failed", "needsUserAction"):
            raise AssertionError({"initialProfileChange": job, "state": status["state"]})
        if job["status"] == "completed":
            final = status["state"]
            assert final["ready"] and not final["projectPath"], final
            assert final["documentId"] == initial_document, final
            assert (final["undoIndex"], final["undoCount"]) == initial_history, final
            assert len(final["bin"]) == len(state["bin"]) == 1, final
            assert final["width"] == profile["width"] and final["height"] == profile["height"], final
            expected_fps = profile["frameRateNumerator"] / profile["frameRateDenominator"]
            assert abs(final["fps"] - expected_fps) < 1e-6, final
            return {"passed": True, "profile": profile, "job": job, "state": final}
        time.sleep(0.02)
    raise AssertionError("Initial empty-project profile switch did not complete")

