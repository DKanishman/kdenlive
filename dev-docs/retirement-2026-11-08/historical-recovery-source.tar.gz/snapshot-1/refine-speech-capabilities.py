from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpspeech.cpp')
s=p.read_text(encoding='utf-8')
start=s.index('            const QString script = existingFile(engine->speechScript());', s.index('if (name == k("speech_capabilities"))'))
end=s.index('\n        }\n        return finish(',start)
s=s[:start]+'''            const QString script = existingFile(engine->speechScript()), python = pythonPath();
            const bool localFiles = !python.isEmpty() && !installed.isEmpty() && scriptContract(script, id == k("whisper")) && !existingFile(KdenliveSettings::ffmpegpath()).isEmpty();
            bool packagesSeen = false, recognitionSeen = false, translationSeen = false;
            for (const auto &job : service->jobs) if (job->engine == id && job->python == python && job->data.value(k("status")) == k("completed")) {
                packagesSeen = packagesSeen || job->data.value(k("dependencyMetadataPresent")).toBool();
                if (job->mode == k("recognize") && installed.contains(job->model) && job->modelRoot == engine->modelFolder(true, false)) {
                    recognitionSeen = true; translationSeen = translationSeen || job->task == k("translate");
                }
            }
            QJsonObject modelTasks; QJsonArray translationModels;
            for (const auto &model : installed) {
                QJsonArray tasks{k("transcribe")};
                if (id == k("whisper") && !model.contains(k("turbo")) && !model.endsWith(k(".en"))) {
                    tasks.append(k("translate_english")); translationModels.append(model);
                }
                modelTasks.insert(model, tasks);
            }
            engines.append(QJsonObject{{k("id"), id}, {k("modelDirectory"), engine->modelFolder(true, false)}, {k("installedModels"), models}, {k("modelTasks"), modelTasks},
                                       {k("languages"), languages}, {k("languageSelection"), id == k("vosk") ? k("Determined by installed model.") : k("Native language ID or autodetect.")},
                                       {k("nativeScriptAvailable"), !script.isEmpty()}, {k("offlinePcmContract"), scriptContract(script, id == k("whisper"))},
                                       {k("pythonAvailable"), !python.isEmpty()}, {k("dependencyStatus"), packagesSeen ? k("metadata_present") : k("not_probed")},
                                       {k("recognitionVerified"), recognitionSeen}, {k("localFilesPresent"), localFiles}, {k("computeDevice"), k("cpu")},
                                       {k("verificationScope"), k("Only completed owned recognition jobs verify execution; changed model files/environments require another run.")},
                                       {k("translation"), QJsonObject{{k("available"), localFiles && packagesSeen && !translationModels.isEmpty()},
                                                                     {k("target"), id == k("whisper") ? k("English") : k("none")},
                                                                     {k("installedSupportedModels"), translationModels}, {k("verified"), translationSeen}}}});
''' +s[end:]
s=s.replace('const auto &word = words.at(i);\n        const int first', 'const auto &word = words.at(i);\n        const int first',1)
s=s.replace('''            int last = first; QString line = job->words.at(first).text;''','''            auto subtitleText = [](QString value) { return value.replace(QRegularExpression(k("[\\\\r\\\\n\\\\x{2028}\\\\x{2029}]+")), k(" ")); };
            int last = first; QString line = subtitleText(job->words.at(first).text);''',1)
s=s.replace('line += QLatin1Char(\' \') + job->words.at(++last).text;', 'line += QLatin1Char(\' \') + subtitleText(job->words.at(++last).text);',1)
s=s.replace('''    const QString action = arguments.value(k("action")).toString();
    if (action == k("apply_job"))''','''    const QString action = arguments.value(k("action")).toString();
    const bool hasIndex = arguments.contains(k("firstWord")), hasCount = arguments.contains(k("wordCount")), hasText = arguments.contains(k("text")), hasJob = arguments.contains(k("jobId"));
    if ((action == k("apply_job") && (hasIndex || hasCount || hasText)) ||
        (action == k("remove_silence") && (hasIndex || hasCount || hasText || hasJob)) ||
        (action == k("replace_word") && (hasCount || hasJob)) ||
        ((action == k("remove_words") || action == k("keep_words")) && (hasText || hasJob)))
        return reject("INVALID_ARGUMENT", "Supply only arguments belonging to this transcript edit action.");
    if (action == k("apply_job"))''',1)
p.write_text(s,encoding='utf-8')
print('Separated local file presence from verified readiness, gated model translation tasks, and normalized only SRT line breaks.')
