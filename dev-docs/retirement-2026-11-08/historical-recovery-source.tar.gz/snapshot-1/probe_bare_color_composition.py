from pathlib import Path
import ctypes as C,os,json,uuid
from PIL import Image,ImageChops
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot');source=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\native-test-temp\kdenlive-rlMSwh\asymmetric.mkv');work=source.parents[2]/('bare-color-composition-'+uuid.uuid4().hex[:10]);work.mkdir()
os.environ['PATH']=str(prefix/'bin')+os.pathsep+os.environ.get('PATH','');os.environ['MLT_DATA']=str(prefix/'share/mlt');os.environ['QT_QPA_PLATFORM']='offscreen';h=os.add_dll_directory(str(prefix/'bin'));lib=C.CDLL(str(prefix/'bin/mlt-7.dll'));P=C.c_void_p
spec={'mlt_factory_init':([C.c_char_p],P),'mlt_profile_init':([C.c_char_p],P),'mlt_factory_producer':([P,C.c_char_p,C.c_char_p],P),'mlt_tractor_new':([],P),'mlt_service_set_profile':([P,P],None),'mlt_tractor_set_track':([P,P,C.c_int],C.c_int),'mlt_tractor_field':([P],P),'mlt_factory_transition':([P,C.c_char_p,C.c_char_p],P),'mlt_transition_properties':([P],P),'mlt_producer_properties':([P],P),'mlt_properties_set':([P,C.c_char_p,C.c_char_p],C.c_int),'mlt_producer_set_in_and_out':([P,C.c_int,C.c_int],C.c_int),'mlt_transition_set_in_and_out':([P,C.c_int,C.c_int],None),'mlt_field_plant_transition':([P,P,C.c_int,C.c_int],C.c_int),'mlt_producer_seek':([P,C.c_int],C.c_int),'mlt_producer_service':([P],P),'mlt_service_get_frame':([P,C.POINTER(P),C.c_int],C.c_int),'mlt_frame_get_image':([P,C.POINTER(P),C.POINTER(C.c_int),C.POINTER(C.c_int),C.POINTER(C.c_int),C.c_int],C.c_int),'mlt_frame_close':([P],None),'mlt_producer_close':([P],None),'mlt_transition_close':([P],None),'mlt_profile_close':([P],None),'mlt_factory_close':([],None)}
for n,(a,r) in spec.items():f=getattr(lib,n);f.argtypes=a;f.restype=r
lib.mlt_factory_init(str(prefix/'lib/mlt').encode());print(json.dumps({'work':str(work)}),flush=True)
try:
 for mode in ['bare-rgb','bare-rgba','loader-rgb']:
  profile=lib.mlt_profile_init(b'dv_pal');tractor=lib.mlt_tractor_new();lib.mlt_service_set_profile(tractor,profile)
  lower=lib.mlt_factory_producer(profile,b'loader' if mode=='loader-rgb' else b'color',b'color:0x0000ffff' if mode=='loader-rgb' else b'0x0000ffff');assert lower
  lp=lib.mlt_producer_properties(lower);lib.mlt_properties_set(lp,b'mlt_image_format',b'rgba' if mode=='bare-rgba' else b'rgb');lib.mlt_properties_set(lp,b'length',b'20');lib.mlt_producer_set_in_and_out(lower,0,19)
  upper=lib.mlt_factory_producer(profile,b'loader',str(source).encode());assert upper
  assert not lib.mlt_tractor_set_track(tractor,lower,0);assert not lib.mlt_tractor_set_track(tractor,upper,1)
  tr=lib.mlt_factory_transition(profile,b'affine',None);assert tr
  lib.mlt_properties_set(lib.mlt_transition_properties(tr),b'rect',b'0=-100% 0% 100% 100% 100%;19=0% 0% 100% 100% 100%');lib.mlt_transition_set_in_and_out(tr,0,19);assert not lib.mlt_field_plant_transition(lib.mlt_tractor_field(tractor),tr,0,1)
  images=[]
  for position in [0,19]:
   lib.mlt_producer_seek(tractor,position);frame=P();assert not lib.mlt_service_get_frame(tractor,C.byref(frame),0)
   try:
    image=P();fmt=C.c_int(2);w=C.c_int(720);height=C.c_int(576);err=lib.mlt_frame_get_image(frame,C.byref(image),C.byref(fmt),C.byref(w),C.byref(height),0);assert not err
    im=Image.frombytes('RGBA' if fmt.value==2 else 'RGB',(w.value,height.value),C.string_at(image,w.value*height.value*(4 if fmt.value==2 else 3))).convert('RGB');images.append(im);im.save(work/(mode+f'-{position}.png'))
   finally:lib.mlt_frame_close(frame)
  print(json.dumps({'mode':mode,'diff':ImageChops.difference(*images).getbbox(),'first':images[0].getpixel((4,4)),'last':images[1].getpixel((4,4)),'format':fmt.value}),flush=True)
  lib.mlt_transition_close(tr);lib.mlt_producer_close(tractor);lib.mlt_producer_close(lower);lib.mlt_producer_close(upper);lib.mlt_profile_close(profile)
finally:lib.mlt_factory_close()
