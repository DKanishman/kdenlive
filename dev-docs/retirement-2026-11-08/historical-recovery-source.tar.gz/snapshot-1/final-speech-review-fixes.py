from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpspeech.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('''    QJsonArray page, speechRanges, editRanges;
    int begin''','''    QJsonArray page, speechRanges, editRanges;
    QHash<int, QPair<int, int>> paragraphBounds;
    for (const auto &word : words) {
        const int first = std::clamp(GenTime(word.start).frames(fps), 0, endBoundary);
        const int boundary = std::clamp(GenTime(word.end).frames(fps), first, endBoundary);
        auto found = paragraphBounds.find(word.block);
        if (found == paragraphBounds.end()) paragraphBounds.insert(word.block, {first, boundary - 1});
        else { found.value().first = std::min(found.value().first, first); found.value().second = std::max(found.value().second, boundary - 1); }
    }
    int begin''',1)
s=s.replace('''const QJsonObject range{{k("sourceInFrame"), begin}, {k("sourceOutFrame"), end}, {k("durationFrames"), end - begin + 1}};''','''const auto bounds = paragraphBounds.value(paragraph);
        if (bounds.second < bounds.first) return;
        const QJsonObject range{{k("paragraph"), paragraph}, {k("sourceInFrame"), bounds.first}, {k("sourceOutFrame"), bounds.second},
                                {k("durationFrames"), bounds.second - bounds.first + 1}};''',1)
s=s.replace('''{k("hasMore"), offset + limit < words.size()}, {k("fps"), fps},
            {k("frameConvention")''','''{k("hasMore"), offset + limit < words.size()}, {k("fps"), fps},
            {k("rangeScope"), k("Complete native paragraphs intersecting this token page; deduplicate by paragraph ID across pages. Individual word fields retain precise selection boundaries.")},
            {k("frameConvention")''',1)
s=s.replace('''    const QString previous = source->getProducerProperty(k("kdenlive:speech")), updated = nativeHtml(binId, words);
    if (updated != previous)''','''    if (words.size() > MaxWords) return reject("TRANSCRIPT_LIMIT", "Native transcript including silence exceeds its token bound; apply shorter recognition ranges.");
    const QString previous = source->getProducerProperty(k("kdenlive:speech")), updated = nativeHtml(binId, words);
    if (updated.size() > MaxResultBytes) return reject("TRANSCRIPT_LIMIT", "Generated native transcript exceeds its bounded HTML size.");
    if (updated != previous)''',1)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpspeech_cases.inc')
s=p.read_text(encoding='utf-8')
s += '''\nTEST_CASE("MCP native transcript pagination retains complete paragraph boundaries", "[MCP][Speech]")
{
    McpProject project; project.open(); QTemporaryDir directory; REQUIRE(directory.isValid());
    const QString id = speechFixtureBin(project, directory); const auto source = pCore->projectItemModel()->getClipByBinID(id);
    source->setProperties({{QStringLiteral("kdenlive:speech"),
        QStringLiteral("<p><a href=\\"%1#0:0.2\\">first</a> <a href=\\"%1#0.8:1\\">last</a></p>").arg(id)}});
    const auto first = project.success(QStringLiteral("get_speech_transcript"), {{QStringLiteral("binId"), id}, {QStringLiteral("limit"), 1}});
    const auto last = project.success(QStringLiteral("get_speech_transcript"), {{QStringLiteral("binId"), id}, {QStringLiteral("offset"), 1}, {QStringLiteral("limit"), 1}});
    const auto a = first.value(QStringLiteral("editRanges")).toArray(), b = last.value(QStringLiteral("editRanges")).toArray();
    REQUIRE(a.size() == 1); REQUIRE(b.size() == 1); CHECK(a == b);
    CHECK(a[0].toObject().value(QStringLiteral("durationFrames")).toInt() == 25);
    CHECK(first.value(QStringLiteral("words")).toArray()[0].toObject().value(QStringLiteral("sourceOutFrame")).toInt() == 4);
    CHECK(last.value(QStringLiteral("words")).toArray()[0].toObject().value(QStringLiteral("sourceInFrame")).toInt() == 20);
}
'''
p.write_text(s,encoding='utf-8')
print('Completed paragraph-safe pagination and generated transcript bounds.')
