param([string]$LogName='completion-build-28.log',[string[]]$Targets=@('kdenlive','mcptest','subtitlestest','groupstest','sequencetest','markertest','bintest','treetest'))
$ErrorActionPreference='Stop'
$taskRoot='C:\Users\USER\.codex\work\kdenlive-mcp-completion'
$craftPrefix='C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot'
$buildRoot=Join-Path $craftPrefix 'build\kde\kdemultimedia\kdenlive\work\build'
$env:CRAFT_PYTHON='C:\Users\USER\AppData\Local\Python\pythoncore-3.14-64\python.exe'
function Clear-Host {}
. (Join-Path $craftPrefix 'craft\craftenv.ps1')
Set-Location -LiteralPath $taskRoot
& cmake --build $buildRoot --parallel 6 --target @Targets *> (Join-Path $taskRoot $LogName)
$buildExit=$LASTEXITCODE
Get-Content -LiteralPath (Join-Path $taskRoot $LogName) -Tail 35
exit $buildExit
