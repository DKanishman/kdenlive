from pathlib import Path
p=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\mcplifecycle.advanced.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('''QJsonObject publicJob(QJsonObject job, bool dialog)
{
''','''QJsonObject publicJob(QJsonObject job, bool dialog)
{
    if (job.value(key("kind")) == key("render") && !job.contains(key("outputs"))) {
        QJsonArray pending;
        for (const auto &entry : job.value(key("plannedOutputs")).toArray()) {
            auto output = entry.toObject();
            output.insert(key("path"), job.value(key("outputKind")) == key("directory") ?
                              QDir(job.value(key("path")).toString()).absoluteFilePath(output.value(key("fileName")).toString()) : job.value(key("path")));
            output.remove(key("stagedPath"));
            output.remove(key("subtitlePath"));
            pending.append(output);
        }
        job.insert(key("outputs"), pending);
    }
''')
s=s.replace('''job.insert(key("status"), key("failed"));
            job.insert(key("message"), process->errorString());''','''job.insert(key("status"), job.value(key("cancelRequested")).toBool() ? key("canceled") : key("failed"));
            job.insert(key("message"), process->errorString());''')
p.write_text(s,encoding='utf-8')
