from pathlib import Path
work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
src=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcplifecycle.cpp')
s=src.read_text(encoding='utf-8')
(work/'mcplifecycle.before-advanced.cpp').write_text(s,encoding='utf-8')
s=s.replace('#include "mcphelpers.h"','#include "mcphelpers.h"\n#include "mcpquick.h"')
s=s.replace('#include <QDir>','#include <QDir>\n#include <QDomDocument>\n#include <QImageReader>\n#include <QSet>')
s=s.replace('"muxPath", "playlists"','"muxPath", "playlists", "plannedOutputs", "progressTail"')
s=s.replace('QApplication::activeModalWidget() != nullptr','QApplication::activeModalWidget() != nullptr || McpQuick::modalPopupActive(this)')
s=s.replace('if (QApplication::activeModalWidget() || QApplication::activePopupWidget() || QApplication::mouseButtons() != Qt::NoButton)', 'if (QApplication::activeModalWidget() || QApplication::activePopupWidget() || McpQuick::modalPopupActive(this) || QApplication::mouseButtons() != Qt::NoButton)')
s=s.replace('Export a native snapshot asynchronously through an installed preset. Outputs are staged and published without replacing existing files.', 'Export a native snapshot or queue it after an owned job. Single files and complete multioutput directories publish without replacement; queues belong to this session.')
s=s.replace('New absolute output path matching the preset extension.', 'New absolute file path, or new directory for image sequences, guide sections, or audio stems.')
s=s.replace('{key("presetName"), text("Exact preset name from list_render_presets.")},', '''{key("presetName"), text("Exact preset name from list_render_presets.")},
                   {key("outputName"), text("Directory exports only: plain filename with the preset extension; defaults to export.<extension>.")},
                   {key("guideSections"), boolean("Export each native guide section into a new output directory.")},
                   {key("guideCategory"), number("Guide category ID, or -1 for all guides; used with guideSections.")},
                   {key("audioFilePerTrack"), boolean("Native stem export: one audio file per unmuted audio track, plus video when enabled.")},
                   {key("audioChannels"), number("Optional output channel count: 1, 2, 4, or 6. Defaults to preset or project channels.")},
                   {key("queueAfterJobId"), text("Optional owned earlier render job. Starts only if it completes; session-only queue, canceled on editor exit.")},''',1)
s=s.replace('{key("category"), preset->groupId()},', '''{key("category"), preset->groupId()},
                             {key("imageSequence"), preset->params().isImageSequence()},
                             {key("typedExportSupported"), preset->isValid() && preset->renderer() == key("avformat")},
                             {key("audioOnly"), preset->hasParam(key("video_off")) || preset->hasParam(key("vn"))},''')
s=s.replace('''        else {
            job.insert(key("status"), key("canceled"));
            removeRenderArtifacts(job, true);
        }
        return toolResult''','''        else {
            job.insert(key("status"), key("canceled"));
            removeRenderArtifacts(job, true);
            if (const auto process = m_renderProcesses.take(id)) process->deleteLater();
        }
        return toolResult''',1)
s=s.replace('''        if (!preset || !preset->isValid() || preset->renderer() != key("avformat") || preset->params().isImageSequence())
            return failure(key("INVALID_PRESET"),
                           key("This typed exporter requires a valid single-file avformat preset. Use the native export UI for image sequences."), state);
        if (QFileInfo(path).suffix().compare(preset->extension(), Qt::CaseInsensitive) != 0)
            return failure(key("INVALID_PATH"), key("Output extension must match the selected native preset."), state);''','''        if (!preset || !preset->isValid() || preset->renderer() != key("avformat"))
            return failure(key("INVALID_PRESET"), key("Choose a valid installed native avformat preset."), state);
        const bool imageSequence = preset->params().isImageSequence();
        const bool guides = arguments.value(key("guideSections")).toBool(false);
        const bool stems = arguments.value(key("audioFilePerTrack")).toBool(false);
        const bool directoryOutput = imageSequence || guides || stems;
        const QString outputName = directoryOutput ? arguments.value(key("outputName")).toString(key("export.") + preset->extension())
                                                   : QFileInfo(path).fileName();
        if (!safeOutputLeaf(outputName) || QFileInfo(outputName).suffix().compare(preset->extension(), Qt::CaseInsensitive) != 0 ||
            (!directoryOutput && arguments.contains(key("outputName"))))
            return failure(key("INVALID_PATH"), key("Use a plain output filename with the preset extension; outputName is for directory exports only."), state);
        if (!guides && arguments.contains(key("guideCategory")))
            return failure(key("INVALID_ARGUMENT"), key("guideCategory requires guideSections=true."), state);
        int guideCategory = -1;
        if (guides && arguments.contains(key("guideCategory")) && !Mcp::integer(arguments, key("guideCategory"), -1, 1000000, guideCategory))
            return failure(key("INVALID_ARGUMENT"), key("Use a guide category ID or -1."), state);
        const QString predecessor = arguments.value(key("queueAfterJobId")).toString();
        if (!predecessor.isEmpty() && (!m_lifecycleJobs.contains(predecessor) || m_lifecycleJobs[predecessor].value(key("kind")) != key("render")))
            return failure(key("INVALID_JOB"), key("queueAfterJobId must be an owned render job."), state);''')
s=s.replace('''        if (embed && (QFileInfo(path).suffix().compare(key("mkv"), Qt::CaseInsensitive) != 0 || ffmpeg.isEmpty() || !QFileInfo(ffmpeg).isExecutable()))''','''        if (embed && (imageSequence || QFileInfo(outputName).suffix().compare(key("mkv"), Qt::CaseInsensitive) != 0 || ffmpeg.isEmpty() || !QFileInfo(ffmpeg).isExecutable()))''')
s=s.replace('''        if (speed.contains(QLatin1Char('='))) params.insertFromString(speed, false);
        if (!makeRoom''','''        if (speed.contains(QLatin1Char('='))) params.insertFromString(speed, false);
        int channels = params.contains(key("channels")) ? params.value(key("channels")).toInt() : pCore->audioChannels();
        if (arguments.contains(key("audioChannels")) &&
            (!Mcp::integer(arguments, key("audioChannels"), 1, 6, channels) || (channels != 1 && channels != 2 && channels != 4 && channels != 6)))
            return failure(key("INVALID_ARGUMENT"), key("Native output channels must be 1, 2, 4, or 6."), state);
        if (channels > 0) params.insert(key("channels"), QString::number(channels));
        if (imageSequence && arguments.value(key("twoPass")).toBool(false))
            return failure(key("INVALID_ARGUMENT"), key("Image sequences use a single native render pass."), state);
        if (!makeRoom''',1)
s=s.replace('''const QString staged = QDir(staging.path()).absoluteFilePath(QFileInfo(path).fileName());''','''const QString staged = QDir(staging.path()).absoluteFilePath(outputName);''')
s=s.replace('''        request.setEmbedSubtitles(embed);
        const auto nativeJobs''','''        request.setEmbedSubtitles(embed);
        request.setAudioFilePerTrack(stems);
        request.setGuideParams(document->getGuideModel(pCore->currentTimelineId()), guides, guideCategory);
        QJsonArray sections;
        if (guides) {
            const auto bounds = request.getSectionsInOut();
            const auto labels = request.getSectionsNames();
            if (bounds.isEmpty()) return failure(key("INVALID_ARGUMENT"), key("No guides in the requested range/category; no export was queued."), state);
            if (bounds.size() > 128) return failure(key("EXPORT_LIMIT"), key("Export at most 128 guide sections per job."), state);
            for (int index = 0; index < bounds.size(); ++index)
                sections.append(QJsonObject{{key("name"), labels.value(index)}, {key("inFrame"), bounds[index].first}, {key("outFrame"), bounds[index].second}});
        }
        const auto nativeJobs''')
start=s.index('        QJsonArray steps, playlists;')
end=s.index('        staging.setAutoRemove(false);',start)
s=s[:start]+'''        QJsonArray steps, playlists, plannedOutputs;
        QSet<QString> outputPaths;
        QString preparationError;
        for (const auto &job : nativeJobs) {
            playlists.append(job.playlistPath);
            if (!job.subtitlePath.isEmpty()) playlists.append(job.subtitlePath);
            if (!ownedLeafPath(job.outputFile, staging.path())) {
                preparationError = key("Native export generated an output outside its staging directory.");
                break;
            }
            QJsonArray args{key("-loglevel"), key("error"), key("-progress2"), QString::fromUtf8(QUrl::toPercentEncoding(job.playlistPath))};
            steps.append(QJsonObject{{key("program"), melt}, {key("arguments"), args}, {key("phase"), key("render")}});
            if (!outputPaths.contains(job.outputFile)) {
                auto output = nativeOutput(job, preparationError);
                if (!preparationError.isEmpty()) break;
                plannedOutputs.append(output);
                outputPaths.insert(job.outputFile);
            }
        }
        if (nativeJobs.size() > 512) preparationError = key("Export exceeds 512 native steps.");
        if (!preparationError.isEmpty()) {
            for (const auto &job : nativeJobs) {
                QFile::remove(job.playlistPath);
                if (!job.subtitlePath.isEmpty()) QFile::remove(job.subtitlePath);
            }
            return failure(key("RENDER_PREPARE_FAILED"), preparationError, state);
        }
        if (embed) {
            for (int index = 0; index < plannedOutputs.size(); ++index) {
                auto output = plannedOutputs[index].toObject();
                const QString subtitle = output.take(key("subtitlePath")).toString();
                if (subtitle.isEmpty()) continue;
                const QString mux = QDir(staging.path()).absoluteFilePath(key(".embedded-") + QString::number(index) + key(".mkv"));
                QJsonArray args{key("-nostdin"), key("-v"), key("error"), key("-n"), key("-i"), output.value(key("stagedPath")), key("-i"), subtitle,
                                key("-map"), key("0"), key("-map"), key("1"), key("-c"), key("copy"), key("-f"), key("matroska"), mux};
                steps.append(QJsonObject{{key("program"), ffmpeg}, {key("arguments"), args}, {key("phase"), key("subtitle_mux")}});
                output.insert(key("stagedPath"), mux);
                plannedOutputs[index] = output;
            }
        }
        QJsonObject record{{key("jobId"), id}, {key("kind"), key("render")}, {key("status"), key("queued")},
                           {key("path"), path}, {key("presetName"), presetName}, {key("inFrame"), in}, {key("outFrame"), out},
                           {key("progress"), 0}, {key("steps"), steps}, {key("stepIndex"), 0}, {key("stepCount"), steps.size()},
                           {key("outputKind"), directoryOutput ? key("directory") : key("file")}, {key("queueScope"), key("session")},
                           {key("queueAfterJobId"), predecessor}, {key("sections"), sections}, {key("audioChannels"), channels},
                           {key("stagingDir"), staging.path()}, {key("plannedOutputs"), plannedOutputs}, {key("playlists"), playlists}};
''' +s[end:]
s=s.replace('''            const QRegularExpression percentage(key("Percentage:\\\\s*(\\\\d+)"), QRegularExpression::CaseInsensitiveOption);
            auto matches = percentage.globalMatch(job.value(key("logTail")).toString());''','''            const QRegularExpression percentage(key("Percentage:\\\\s*(\\\\d+)"), QRegularExpression::CaseInsensitiveOption);
            const QString progressText = job.value(key("progressTail")).toString() + data;
            auto matches = percentage.globalMatch(progressText);
            job.insert(key("progressTail"), progressText.right(256));''')
s=s.replace('''                const int value = qBound(0, match.captured(1).toInt(), 100);''','''                const int value = qBound(0, match.captured(1).toInt(), 99);''')
s=s.replace('''                    job.insert(key("stepIndex"), next);
                    const auto step''','''                    job.insert(key("stepIndex"), next);
                    job.insert(key("progressTail"), QString());
                    job.insert(key("progress"), qMax(job.value(key("progress")).toInt(), next * 100 / nativeSteps.size()));
                    const auto step''')
start=s.index('                const QString publish =')
end=s.index('\n            }\n            m_renderProcesses.remove(id);',start)
s=s[:start]+'''                QString verificationError;
                QJsonArray outputs;
                if (!verifyRenderOutputs(job, outputs, verificationError)) {
                    job.insert(key("status"), key("failed"));
                    job.insert(key("message"), verificationError);
                    job.insert(key("recoveryPath"), job.value(key("stagingDir")));
                    removeRenderArtifacts(job, false);
                } else {
                    const QString target = job.value(key("path")).toString();
                    const QString stage = job.value(key("stagingDir")).toString();
                    const bool directoryOutput = job.value(key("outputKind")) == key("directory");
                    const QString publish = directoryOutput ? stage : job.value(key("plannedOutputs")).toArray().first().toObject().value(key("stagedPath")).toString();
                    const bool published = directoryOutput ? QDir().rename(publish, target) : QFile::rename(publish, target);
                    if (published) {
                        job.insert(key("status"), key("completed"));
                        job.insert(key("progress"), 100);
                        job.insert(key("outputs"), outputs);
                        double bytes = 0;
                        for (const auto &output : outputs) bytes += output.toObject().value(key("bytes")).toDouble();
                        job.insert(key("bytes"), bytes);
                        removeRenderArtifacts(job, !directoryOutput);
                    } else {
                        job.insert(key("status"), key("failed"));
                        job.insert(key("message"), key("Rendering verified, but non-replacing publication failed. Completed staged outputs are retained."));
                        job.insert(key("recoveryPath"), publish);
                        removeRenderArtifacts(job, false);
                    }
                }''' +s[end:]
start=s.index('        const auto first = steps.first().toObject();')
end=s.index('        return toolResult',start)
s=s[:start]+'''        const auto launch = [this, id, process] {
            const auto first = m_lifecycleJobs[id].value(key("steps")).toArray().first().toObject();
            m_lifecycleJobs[id].insert(key("phase"), first.value(key("phase")));
            process->start(first.value(key("program")).toString(), stepArgs(first));
        };
        if (predecessor.isEmpty()) launch();
        else {
            auto *queueTimer = new QTimer(process);
            queueTimer->setInterval(20);
            connect(queueTimer, &QTimer::timeout, this, [this, id, predecessor, process, queueTimer, launch] {
                if (!m_lifecycleJobs.contains(id) || terminal(m_lifecycleJobs[id].value(key("status")).toString())) {
                    queueTimer->stop();
                    return;
                }
                const QString priorStatus = m_lifecycleJobs.value(predecessor).value(key("status")).toString();
                if (priorStatus == key("completed")) {
                    queueTimer->stop();
                    launch();
                } else if (priorStatus.isEmpty() || terminal(priorStatus)) {
                    queueTimer->stop();
                    auto &job = m_lifecycleJobs[id];
                    job.insert(key("status"), key("canceled"));
                    job.insert(key("message"), key("The preceding render did not complete; dependent export was canceled."));
                    removeRenderArtifacts(job, true);
                    m_renderProcesses.remove(id);
                    process->deleteLater();
                }
            });
            queueTimer->start();
        }
''' +s[end:]
(work/'mcplifecycle.advanced.cpp').write_text(s,encoding='utf-8')
print('Prepared lifecycle patch',len(s))
