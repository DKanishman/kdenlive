"""Checked R39 wire integration; defaults to staging current-source diffs.
Run --apply only after root explicitly unlocks source/build coordination.
Never restores an old source copy: each transform checks freshly read files.
"""
from pathlib import Path
import argparse, difflib, hashlib, json
ROOT=Path(r'C:\Users\USER\Documents\kdenlive')
WORK=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\r39-wire')

def once(text,old,new):
    if text.count(old)!=1: raise RuntimeError('Expected one current marker: '+old[:100])
    return text.replace(old,new,1)

def helpers(text):
    if '#include "mcpwire.h"' not in text: text=once(text,'#pragma once','#pragma once\n#include "mcpwire.h"')
    a=text.index('inline QJsonObject toolResult(');b=text.index('\ninline QJsonObject failure(',a)
    return text[:a]+"""inline QJsonObject toolResult(const QJsonObject &data, bool error = false)
{
    return McpWire::toolResult(data, error);
}"""+text[b:]

def server(text):
    if '#include "mcpwire.h"' not in text: text=once(text,'#include "mcpserver.h"','#include "mcpserver.h"\n#include "mcpwire.h"')
    a=text.index('QJsonObject toolResult(');b=text.index('\nQJsonObject failure(',a)
    text=text[:a]+"""QJsonObject toolResult(const QJsonObject &data, bool error = false)
{
    return McpWire::toolResult(data, error);
}"""+text[b:]
    a=text.index('QJsonArray KdenliveMcpServer::toolCatalog()');b=text.index('\nKdenliveMcpServer::KdenliveMcpServer(',a)
    block=text[a:b]
    if 'McpWire::toolCatalog()' not in block: block=once(block,'    return result;','    for (const auto &entry : McpWire::toolCatalog()) result.append(entry);\n    return result;')
    text=text[:a]+block+text[b:]
    a=text.index('QJsonObject KdenliveMcpServer::handleRequest(');b=text.index('\nQJsonObject KdenliveMcpServer::snapshot()',a)
    block=text[a:b]
    if 'McpWire::boundRpcResponse' not in block:
        block=once(block,'    QJsonObject result;','    QJsonObject result;\n    QString wireToolName;\n    bool wireMutation = false;')
        block=once(block,'            result = callTool(params.value(QStringLiteral("name")).toString(), params.value(QStringLiteral("arguments")).toObject());',
"""            wireToolName = params.value(QStringLiteral("name")).toString();
            for (const auto &entry : toolCatalog()) {
                const auto definition = entry.toObject();
                if (definition.value(QStringLiteral("name")).toString() == wireToolName)
                    wireMutation = !definition.value(QStringLiteral("annotations")).toObject().value(QStringLiteral("readOnlyHint")).toBool();
            }
            result = callTool(wireToolName, params.value(QStringLiteral("arguments")).toObject());""")
        block=once(block,'    return {{QStringLiteral("jsonrpc"), QStringLiteral("2.0")}, {QStringLiteral("id"), id}, {QStringLiteral("result"), result}};',
"""    return McpWire::boundRpcResponse(this,
                                     QJsonObject{{QStringLiteral("jsonrpc"), QStringLiteral("2.0")}, {QStringLiteral("id"), id}, {QStringLiteral("result"), result}},
                                     wireToolName, wireMutation);""")
    elif not ('wireToolName' in block and 'wireMutation' in block): raise RuntimeError('Partial dispatcher integration needs manual review')
    text=text[:a]+block+text[b:]
    a=text.index('QJsonObject KdenliveMcpServer::callTool(');block=text[a:]
    if 'McpWire::mutationPreflight' not in block:
        block=once(block,'    QJsonObject schema;','    QJsonObject schema;\n    bool wireMutation = true;')
        block=once(block,'            schema = tool.value(QStringLiteral("inputSchema")).toObject();','            schema = tool.value(QStringLiteral("inputSchema")).toObject();\n            wireMutation = !tool.value(QStringLiteral("annotations")).toObject().value(QStringLiteral("readOnlyHint")).toBool();')
        block=once(block,'    if (name == QLatin1String("get_info"))',
"""    const auto receiptControl = McpWire::callTool(this, name, arguments);
    if (!receiptControl.isEmpty()) return receiptControl;
    const auto receiptPreflight = McpWire::mutationPreflight(this, name, wireMutation);
    if (!receiptPreflight.isEmpty()) return receiptPreflight;
    if (name == QLatin1String("get_info"))""")
    elif not ('McpWire::callTool' in block and 'wireMutation' in block): raise RuntimeError('Partial tool integration needs manual review')
    text=text[:a]+block
    if 'QStringLiteral("transport_fallback")' not in text:
        text=once(text,"""    if (bytes.size() > MaxResponseBytes)
        bytes = QJsonDocument(rpcError(response.value(QStringLiteral("id")), -32001, QStringLiteral("Response exceeds prototype limit.")))
                    .toJson(QJsonDocument::Compact);""",
"""    if (bytes.size() > MaxResponseBytes) {
        // Normally bounded by handleRequest. Preserve an unexpected tool
        // result at this last boundary instead of losing its native outcome.
        const bool toolData = response.value(QStringLiteral("result")).toObject().value(QStringLiteral("structuredContent")).isObject();
        bytes = QJsonDocument(McpWire::boundRpcResponse(this, response, QStringLiteral("transport_fallback"), toolData)).toJson(QJsonDocument::Compact);
    }""")
    return text

def cmake(text):
    if '    mcp/mcpwire.cpp\n' in text and '    mcp/mcpwire.h\n' in text:return text
    if 'mcp/mcpwire.' in text:raise RuntimeError('Partial CMake integration needs review')
    return once(text,'    mcp/mcphelpers.h\n','    mcp/mcphelpers.h\n    mcp/mcpwire.cpp\n    mcp/mcpwire.h\n')

def tests(text):
    return text if '#include "mcpwire_cases.inc"' in text else text+'\n#include "mcpwire_cases.inc"\n'

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply',action='store_true',help='Apply fresh checked transforms only after root unlock')
    args=parser.parse_args()
    transforms={'src/mcp/mcphelpers.h':helpers,'src/mcp/mcpserver.cpp':server,'src/CMakeLists.txt':cmake,'tests/mcptest.cpp':tests}
    before={name:(ROOT/name).read_text(encoding='utf-8')for name in transforms}
    after={name:transform(before[name])for name,transform in transforms.items()}
    WORK.mkdir(exist_ok=True)
    patch=''.join(''.join(difflib.unified_diff(before[name].splitlines(keepends=True),after[name].splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name,n=3))for name in transforms)
    (WORK/'integration-current.patch').write_text(patch,encoding='utf-8')
    for name,text in after.items():
        dest=WORK/'staged-current'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text,encoding='utf-8')
    (WORK/'integration-current-base-hashes.json').write_text(json.dumps({n:hashlib.sha256(t.encode('utf-8')).hexdigest()for n,t in before.items()},indent=2)+'\n',encoding='utf-8')
    if args.apply:
        for name in transforms:
            if (ROOT/name).read_text(encoding='utf-8')!=before[name]:raise RuntimeError('Concurrent source change; no source writes attempted: '+name)
        for name,text in after.items():
            if text!=before[name]:(ROOT/name).write_text(text,encoding='utf-8')
    print(json.dumps({'applied':args.apply,'patch':str(WORK/'integration-current.patch'),'changedFiles':[n for n in transforms if before[n]!=after[n]]}))

if __name__=='__main__':main()
