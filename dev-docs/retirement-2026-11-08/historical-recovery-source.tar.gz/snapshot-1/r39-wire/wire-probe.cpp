#include "mcpwire.h"
#include <QCoreApplication>
#include <QJsonDocument>
#include <QObject>
#include <iostream>
#include <QStringList>
#include <algorithm>
#include <stdexcept>
void require(bool value,const char *label){if(!value)throw std::runtime_error(label);}
QJsonObject rpc(const QJsonObject &value){return {{QStringLiteral("jsonrpc"),QStringLiteral("2.0")},{QStringLiteral("id"),QString(128,QChar::Null)},{QStringLiteral("result"),value}};}
QJsonObject data(const QJsonObject &result){return result.value(QStringLiteral("structuredContent")).toObject();}
int main(int argc,char **argv){QCoreApplication app(argc,argv);try{
 const QString unicode=QString::fromUtf8("שלום 中文 😀\"\\\n\t");
 const QJsonObject small{{QStringLiteral("ok"),true},{QStringLiteral("clipId"),73},{QStringLiteral("text"),unicode}};
 const auto smallResult=McpWire::toolResult(small);
 require(data(smallResult)==small,"small data");
 require(QJsonDocument::fromJson(smallResult.value(QStringLiteral("content")).toArray()[0].toObject().value(QStringLiteral("text")).toString().toUtf8()).object()==small,"small text");
 require(McpWire::jsonEncodedSize(small)==QJsonDocument(small).toJson(QJsonDocument::Compact).size(),"exact small size");
 const QString fitting(220000,QChar(u'中'));
 const QJsonObject complete{{QStringLiteral("ok"),true},{QStringLiteral("text"),fitting}};
 const auto structured=McpWire::toolResult(complete);
 require(structured.value(QStringLiteral("_meta")).toObject().value(QStringLiteral("textCopyOmitted")).toBool(),"text omitted");
 const auto fittingBytes=QJsonDocument(rpc(structured)).toJson(QJsonDocument::Compact).size();
 require(fittingBytes<=McpWire::MaxResponseBytes,"fitting wire");
 QObject owner;
 const QString large=QString(400000,QChar(u'中'))+QString::fromUtf8("😀");
 const QJsonObject payload{{QStringLiteral("ok"),true},{QStringLiteral("clipId"),37},{QStringLiteral("text"),large}};
 const auto bounded=McpWire::boundRpcResponse(&owner,rpc(McpWire::toolResult(payload)),QStringLiteral("native_edit"),true);
 const auto boundedBytes=QJsonDocument(bounded).toJson(QJsonDocument::Compact).size();
 require(boundedBytes<=McpWire::MaxResponseBytes,"receipt wire");
 const auto summary=data(bounded.value(QStringLiteral("result")).toObject());
 require(summary.value(QStringLiteral("ok")).toBool()&&summary.value(QStringLiteral("clipId")).toInt()==37,"native outcome");
 const auto id=summary.value(QStringLiteral("receipt")).toObject().value(QStringLiteral("id")).toString();
 require(!id.isEmpty(),"receipt id");
 require(!McpWire::mutationPreflight(&owner,QStringLiteral("move_clip"),true).isEmpty(),"mutation preflight");
 QString recovered;int offset=0,pages=0;
 while(offset<large.size()){
  auto pageResult=McpWire::callTool(&owner,QStringLiteral("get_result_page"),{{QStringLiteral("receiptId"),id},{QStringLiteral("path"),QStringLiteral("/text")},{QStringLiteral("offset"),offset},{QStringLiteral("limit"),8192}});
  require(!pageResult.value(QStringLiteral("isError")).toBool(),"page success");
  require(QJsonDocument(rpc(pageResult)).toJson(QJsonDocument::Compact).size()<=McpWire::MaxResponseBytes,"page wire");
  auto page=data(pageResult);recovered+=page.value(QStringLiteral("text")).toString();
  int next=page.value(QStringLiteral("nextOffset")).toInt();require(next>offset,"page progress");offset=next;++pages;
 }
 require(recovered==large,"lossless all text");
 const QJsonValue nested=QJsonObject{{QStringLiteral("a/b~c"),QJsonArray{QJsonObject{{QStringLiteral("text"),QString::fromUtf8("A😀B")}}}}};
 auto emoji=McpWire::pageValue(nested,QStringLiteral("/a~1b~0c/0/text"),1,1);
 require(emoji.value(QStringLiteral("ok")).toBool()&&emoji.value(QStringLiteral("text")).toString()==QString::fromUtf8("😀"),"surrogate page");
 require(!McpWire::pageValue(nested,QStringLiteral("/a~1b~0c/0/text"),2,1).value(QStringLiteral("ok")).toBool(),"surrogate refusal");
 auto release=McpWire::callTool(&owner,QStringLiteral("release_result_receipt"),{{QStringLiteral("receiptId"),id},{QStringLiteral("acknowledgeRelease"),true}});
 require(!release.value(QStringLiteral("isError")).toBool()&&McpWire::mutationPreflight(&owner,QStringLiteral("move_clip"),true).isEmpty(),"release");
 QObject asynchronous;
 const QJsonObject job{{QStringLiteral("jobId"),QStringLiteral("owned-17")},{QStringLiteral("status"),QStringLiteral("queued")},{QStringLiteral("finished"),false}};
 const QJsonObject accepted{{QStringLiteral("ok"),true},{QStringLiteral("accepted"),true},{QStringLiteral("changed"),false},{QStringLiteral("job"),job},{QStringLiteral("details"),QString(1200000,QLatin1Char('x'))}};
 auto queued=McpWire::boundRpcResponse(&asynchronous,rpc(McpWire::toolResult(accepted)),QStringLiteral("start_render"),true);
 auto queuedData=data(queued.value(QStringLiteral("result")).toObject());
 require(queuedData.value(QStringLiteral("job")).toObject()==job&&!queuedData.value(QStringLiteral("changed")).toBool(true),"queued outcome");
 const auto originalId=queuedData.value(QStringLiteral("receipt")).toObject().value(QStringLiteral("id")).toString();
 require(!originalId.isEmpty(),"queued receipt");
 require(McpWire::mutationPreflight(&asynchronous,QStringLiteral("cancel_render"),true).isEmpty(),"cancel allowed");
 auto stopJob=job;stopJob.insert(QStringLiteral("status"),QStringLiteral("canceling"));stopJob.insert(QStringLiteral("outputs"),QJsonArray{QString(1200000,QLatin1Char('p'))});
 auto stop=McpWire::boundRpcResponse(&asynchronous,rpc(McpWire::toolResult({{QStringLiteral("ok"),true},{QStringLiteral("job"),stopJob}})),QStringLiteral("cancel_render"),true);
 require(QJsonDocument(stop).toJson(QJsonDocument::Compact).size()<=McpWire::MaxResponseBytes,"cancel wire");
 auto stopData=data(stop.value(QStringLiteral("result")).toObject());
 require(stopData.value(QStringLiteral("ok")).toBool()&&stopData.value(QStringLiteral("job")).toObject().value(QStringLiteral("status")).toString()==QStringLiteral("canceling"),"cancel outcome");
 require(stopData.value(QStringLiteral("pendingResultReceipt")).toObject().value(QStringLiteral("id")).toString()==originalId,"original receipt immutable");
 auto metadata=data(McpWire::callTool(&asynchronous,QStringLiteral("get_result_page"),{}));
 require(metadata.value(QStringLiteral("pending")).toBool()&&metadata.value(QStringLiteral("receipt")).toObject().value(QStringLiteral("id")).toString()==originalId,"reconnect metadata");

 const QStringList tools{QStringLiteral("open_project"),QStringLiteral("start_render"),QStringLiteral("start_speech_job")};
 const QStringList cancels{QStringLiteral("cancel_media_job"),QStringLiteral("cancel_render"),QStringLiteral("cancel_speech_job")};
 qsizetype largestJobReply=0;
 for(int n=0;n<3;++n){
  QObject jobOwner;
  const QString nativeId=QStringLiteral("owned-large-%1").arg(n);
  const QJsonObject nativeJob{{QStringLiteral("jobId"),nativeId},{QStringLiteral("kind"),tools.at(n)},{QStringLiteral("operation"),tools.at(n)},{QStringLiteral("status"),QStringLiteral("queued")},{QStringLiteral("phase"),QStringLiteral("waiting")},{QStringLiteral("finished"),false},{QStringLiteral("cancelRequested"),false},{QStringLiteral("logTail"),QString(8192,QChar(u'中'))},{QStringLiteral("plannedOutputs"),QJsonArray{QString(1200000,QLatin1Char('p'))}},{QStringLiteral("segments"),QJsonArray{QJsonObject{{QStringLiteral("text"),QString(12000,QChar(u'中'))}}}}};
  const QJsonObject nativePayload{{QStringLiteral("ok"),true},{QStringLiteral("isError"),false},{QStringLiteral("accepted"),true},{QStringLiteral("changed"),false},{QStringLiteral("noop"),true},{QStringLiteral("job"),nativeJob}};
  auto nativeBound=McpWire::boundRpcResponse(&jobOwner,rpc(McpWire::toolResult(nativePayload)),tools.at(n),true);
  auto nativeSummary=data(nativeBound.value(QStringLiteral("result")).toObject());
  const auto nativeBytes=QJsonDocument(nativeBound).toJson(QJsonDocument::Compact).size();
  require(nativeBytes<=McpWire::MaxResponseBytes,"large job wire");largestJobReply=std::max(largestJobReply,nativeBytes);
  require(nativeSummary.value(QStringLiteral("ok")).toBool()&&nativeSummary.value(QStringLiteral("accepted")).toBool()&&!nativeSummary.value(QStringLiteral("changed")).toBool(true)&&nativeSummary.value(QStringLiteral("noop")).toBool()&&!nativeSummary.value(QStringLiteral("isError")).toBool(true),"large job original flags");
  const auto nativeCompact=nativeSummary.value(QStringLiteral("job")).toObject();
  for(const auto &key:{QStringLiteral("jobId"),QStringLiteral("kind"),QStringLiteral("operation"),QStringLiteral("status"),QStringLiteral("phase"),QStringLiteral("finished"),QStringLiteral("cancelRequested")})require(nativeCompact.value(key)==nativeJob.value(key),"large job identity/outcome");
  require(!nativeCompact.contains(QStringLiteral("logTail"))&&!nativeCompact.contains(QStringLiteral("plannedOutputs"))&&!nativeCompact.contains(QStringLiteral("segments"))&&nativeCompact.value(QStringLiteral("readbackTruncated")).toBool(),"large job bulky fields omitted");
  auto nativeReceipt=nativeSummary.value(QStringLiteral("receipt")).toObject().value(QStringLiteral("id")).toString();require(!nativeReceipt.isEmpty(),"large job receipt");
  require(McpWire::mutationPreflight(&jobOwner,cancels.at(n),true).isEmpty(),"large job cancel preflight");
  auto cancelJob=nativeJob;cancelJob.insert(QStringLiteral("status"),n==2?QStringLiteral("cancelled"):QStringLiteral("canceling"));cancelJob.insert(QStringLiteral("phase"),QStringLiteral("stopping"));cancelJob.insert(QStringLiteral("finished"),n==2);cancelJob.insert(QStringLiteral("cancelRequested"),true);
  auto cancelBound=McpWire::boundRpcResponse(&jobOwner,rpc(McpWire::toolResult({{QStringLiteral("ok"),true},{QStringLiteral("changed"),false},{QStringLiteral("job"),cancelJob}})),cancels.at(n),true);
  const auto cancelSummary=data(cancelBound.value(QStringLiteral("result")).toObject());
  const auto cancelCompact=cancelSummary.value(QStringLiteral("job")).toObject();
  for(const auto &key:{QStringLiteral("jobId"),QStringLiteral("status"),QStringLiteral("phase"),QStringLiteral("finished"),QStringLiteral("cancelRequested")})require(cancelCompact.value(key)==cancelJob.value(key),"large job cancel identity/outcome");
  require(cancelSummary.value(QStringLiteral("pendingResultReceipt")).toObject().value(QStringLiteral("id")).toString()==nativeReceipt,"large job original receipt unchanged");
  auto originalStatus=data(McpWire::callTool(&jobOwner,QStringLiteral("get_result_page"),{{QStringLiteral("receiptId"),nativeReceipt},{QStringLiteral("path"),QStringLiteral("/job/status")}}));
  require(originalStatus.value(QStringLiteral("text")).toString()==QStringLiteral("queued"),"large job frozen queued status");
  require(QJsonDocument(cancelBound).toJson(QJsonDocument::Compact).size()<=McpWire::MaxResponseBytes,"large cancel wire");
 }
 QObject failedOwner;
 const QString errorMessage=QString(400000,QChar(u'中'))+QString::fromUtf8("😀");
 const QJsonObject failedJob{{QStringLiteral("jobId"),QStringLiteral("failed-speech-job")},{QStringLiteral("status"),QStringLiteral("failed")},{QStringLiteral("finished"),true},{QStringLiteral("error"),QJsonObject{{QStringLiteral("code"),QStringLiteral("NATIVE_SPEECH_FAILED")},{QStringLiteral("message"),errorMessage}}}};
 auto failedBound=McpWire::boundRpcResponse(&failedOwner,rpc(McpWire::toolResult({{QStringLiteral("ok"),false},{QStringLiteral("accepted"),false},{QStringLiteral("job"),failedJob}},true)),QStringLiteral("speech_job_status"),false);
 require(QJsonDocument(failedBound).toJson(QJsonDocument::Compact).size()<=McpWire::MaxResponseBytes,"failed job wire");
 const auto failedResult=failedBound.value(QStringLiteral("result")).toObject();const auto failedSummary=data(failedResult);const auto failedCompact=failedSummary.value(QStringLiteral("job")).toObject();const auto failedError=failedCompact.value(QStringLiteral("error")).toObject();
 require(failedResult.value(QStringLiteral("isError")).toBool()&&!failedSummary.value(QStringLiteral("ok")).toBool(true)&&!failedSummary.value(QStringLiteral("accepted")).toBool(true),"failed job outcome");
 require(failedCompact.value(QStringLiteral("jobId")).toString()==QStringLiteral("failed-speech-job")&&failedCompact.value(QStringLiteral("finished")).toBool()&&failedError.value(QStringLiteral("code")).toString()==QStringLiteral("NATIVE_SPEECH_FAILED")&&failedError.value(QStringLiteral("message")).toString()==errorMessage.left(2048)&&failedError.value(QStringLiteral("messageTruncated")).toBool(),"failed job compact error");
 std::cout<<"PASS fittingBytes="<<fittingBytes<<" receiptBytes="<<boundedBytes<<" losslessPages="<<pages<<" largeJobCases=3 largestJobReply="<<largestJobReply<<"\n";return 0;
 }catch(const std::exception &error){std::cerr<<"FAIL "<<error.what()<<"\n";return 1;}}
