from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpquick.cpp')
s=p.read_text(encoding='utf-8')
old='''        QJsonArray parents;
        for (const auto &menu : control.menuOwners)
            if (menu) parents.append(identify(menu));
        data.insert(k("menus"), parents);'''
new='''        QStringList parentIds;
        for (const auto &menu : control.menuOwners)
            if (menu) parentIds.append(identify(menu));
        std::sort(parentIds.begin(), parentIds.end());
        QJsonArray parents;
        for (const auto &parentId : parentIds) parents.append(parentId);
        data.insert(k("menus"), parents);'''
assert old in s
s=s.replace(old,new)
old='''    QSet<QMenu *> menuVisited;
    std::function<void(QMenu *, QWidget *, int, const QVector<QPointer<QMenu>> &)> addMenu = [&](QMenu *menu, QWidget *host, int depth,
                                                                                                 const QVector<QPointer<QMenu>> &ancestors) {
        if (!menu || menuVisited.contains(menu) || depth > 32) return;
        menuVisited.insert(menu);'''
new='''    int menuSteps = 0;
    std::function<void(QMenu *, QWidget *, int, const QVector<QPointer<QMenu>> &)> addMenu = [&](QMenu *menu, QWidget *host, int depth,
                                                                                                 const QVector<QPointer<QMenu>> &ancestors) {
        // Shared submenus must accumulate every root-to-leaf path. A global
        // visited set loses ancestors when a submenu is enumerated first.
        if (!menu || ancestors.contains(menu)) return;
        if (depth > 32 || ++menuSteps > MaxObjects) {
            truncated = true;
            return;
        }'''
assert old in s
s=s.replace(old,new)
old='''        for (auto *action : menu->actions()) {
            const auto aid = identify(action, host);'''
new='''        for (auto *action : menu->actions()) {
            if (++menuSteps > MaxObjects) {
                truncated = true;
                break;
            }
            const auto aid = identify(action, host);'''
assert old in s
s=s.replace(old,new,1)
old='''    // Discover menu-bar roots before visible submenus. Otherwise a submenu seen
    // first in allWidgets() would lose its active ancestor close chain.'''
new='''    // Revisit visible contexts too: native popup enumeration has no ordering
    // guarantee, and each visit merges its complete ancestor path.'''
assert old in s
s=s.replace(old,new)
p.write_text(s,encoding='utf-8')
print('Fixed order-independent shared menu ancestor accumulation')
