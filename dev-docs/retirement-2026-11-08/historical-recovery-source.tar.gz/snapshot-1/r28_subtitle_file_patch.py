from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpeffects.cpp')
s=p.read_text(encoding='utf-8')
helper=r'''// Validate complete files before entering the permissive native parser. Its time
// constructor asserts on malformed timestamps and its import loop skips bad cues.
bool subtitleTimestamp(const QString &value, const QString &format, double fps, double multiplier, GenTime &result)
{
    const QString fraction = format == QLatin1String("ass") ? QStringLiteral("[0-9]{2}") : QStringLiteral("[0-9]{3}");
    const QString separator = format == QLatin1String("srt") ? QStringLiteral(",") : QStringLiteral("\\.");
    const QRegularExpression grammar(QStringLiteral("^(?:([0-9]{1,3}):)?([0-5][0-9]):([0-5][0-9])") + separator +
                                     QStringLiteral("(") + fraction + QStringLiteral(")$"));
    const auto match = grammar.match(value);
    if (!match.hasMatch() || (format != QLatin1String("vtt") && match.captured(1).isEmpty())) return false;
    const qint64 hours = match.captured(1).toLongLong();
    // Native stringtoTime multiplies the hour component in a signed int.
    if (hours > 596) return false;
    const qint64 milliseconds = ((hours * 60 + match.captured(2).toLongLong()) * 60 + match.captured(3).toLongLong()) * 1000 +
                               match.captured(4).toLongLong() * (format == QLatin1String("ass") ? 10 : 1);
    const double frame = double(milliseconds) * fps / (1000.0 * multiplier);
    if (!std::isfinite(frame) || frame < 0 || frame > 2.0 * MaxFrame + 1) return false;
    result = SubtitleEvent::stringtoTime(value, fps, multiplier);
    return true;
}

bool subtitleFilePreflight(const QString &contents, const QString &format, const std::shared_ptr<SubtitleModel> &model, double fps,
                           double sourceFps, int offset, int &candidateCount, QString &code, QString &reason)
{
    code = QStringLiteral("INVALID_SUBTITLE_FILE");
    reason = QStringLiteral("Malformed or unsupported native subtitle file record.");
    QSet<QPair<int, int>> starts;
    // importSubtitle accepts floats and divides them before promoting to double.
    const double multiplier = float(fps) / float(sourceFps);
    const auto candidate = [&](int layer, const GenTime &start, const GenTime &end) {
        const qint64 first = qint64(start.frames(fps)) + offset, last = qint64(end.frames(fps)) + offset;
        if (layer < 0 || layer > 50 || first < 0 || last <= first || last > MaxFrame) {
            reason = QStringLiteral("Subtitle ranges must remain inside the native frame and layer limits after conversion and offset.");
            return false;
        }
        const QPair<int, int> key(layer, int(first));
        if (starts.contains(key) || (model && model->getIdForStartPos(layer, GenTime(int(first), fps)) >= 0)) {
            code = QStringLiteral("SUBTITLE_CONFLICT");
            reason = QStringLiteral("Imported subtitle starts collide with another event in the same layer.");
            return false;
        }
        starts.insert(key);
        if (++candidateCount > 10000) {
            reason = QStringLiteral("Import at most 10000 subtitle events.");
            return false;
        }
        return true;
    };
    const auto lines = contents.split(QLatin1Char('\n'));
    for (const auto &line : lines) {
        if (line.size() > 65536) {
            reason = QStringLiteral("Subtitle records must not exceed 65536 characters.");
            return false;
        }
    }
    if (format != QLatin1String("ass")) {
        QStringList block;
        bool vttHeader = format != QLatin1String("vtt");
        const auto cue = [&]() {
            if (block.isEmpty()) return true;
            if (!vttHeader) {
                vttHeader = true;
                const bool valid = block.size() == 1 && (block.first() == QLatin1String("WEBVTT") || block.first().startsWith(QStringLiteral("WEBVTT ")));
                block.clear();
                if (!valid) reason = QStringLiteral("Native WebVTT requires a WEBVTT header followed by a blank line.");
                return valid;
            }
            const int timingIndex = format == QLatin1String("srt") ? 1 : 0;
            if (block.size() < timingIndex + 2 ||
                (timingIndex == 1 && !QRegularExpression(QStringLiteral("^[0-9]{1,10}$")).match(block.first()).hasMatch())) {
                reason = QStringLiteral("Each subtitle cue needs its native index/timing line and nonempty text; cue identifiers and metadata are unsupported.");
                return false;
            }
            const auto times = block.at(timingIndex).split(format == QLatin1String("sbv") ? QStringLiteral(",") : QStringLiteral(" --> "));
            GenTime start, end;
            if (times.size() != 2 || !subtitleTimestamp(times.first(), format, fps, multiplier, start) ||
                !subtitleTimestamp(times.last(), format, fps, multiplier, end)) {
                reason = QStringLiteral("Malformed subtitle timestamps or unsupported WebVTT cue settings.");
                return false;
            }
            block.clear();
            return candidate(0, start, end);
        };
        for (const auto &line : lines) {
            const QString trimmed = line.trimmed();
            if (trimmed.isEmpty()) {
                if (!cue()) return false;
            } else {
                block.append(trimmed);
            }
        }
        if (!cue() || !vttHeader) return false;
    } else {
        QString section;
        bool turn = false;
        const QString styleFormat = QStringLiteral("name,fontname,fontsize,primarycolour,secondarycolour,outlinecolour,backcolour,bold,italic,underline,"
                                                   "strikeout,scalex,scaley,spacing,angle,borderstyle,outline,shadow,alignment,marginl,marginr,marginv,encoding");
        const QString eventFormat = QStringLiteral("layer,start,end,style,name,marginl,marginr,marginv,effect,text");
        for (const auto &lineValue : lines) {
            const QString line = lineValue.simplified();
            if (line.isEmpty()) {
                turn = false;
                continue;
            }
            if (!turn) {
                QString compact = line;
                compact.remove(QLatin1Char(' '));
                if (compact.contains(QStringLiteral("ScriptInfo"))) section = QStringLiteral("script");
                else if (compact.contains(QStringLiteral("KdenliveExtradata"))) section = QStringLiteral("extra");
                else if (line.contains(QStringLiteral("Styles"))) section = QStringLiteral("styles");
                else if (line.contains(QStringLiteral("Fonts"))) section = QStringLiteral("fonts");
                else if (line.contains(QStringLiteral("Events"))) section = QStringLiteral("events");
                else section.clear();
                if (!section.isEmpty()) {
                    turn = true;
                    continue;
                }
            }
            if (section == QLatin1String("styles")) {
                if (line.startsWith(QStringLiteral("Format:"))) {
                    QString columns = line.section(QLatin1Char(':'), 1).toLower();
                    columns.remove(QLatin1Char(' '));
                    if (columns != styleFormat) {
                        reason = QStringLiteral("Native ASS imports require the standard V4+ style column order.");
                        return false;
                    }
                } else if (!validAssStyle(line)) return false;
            } else if (section == QLatin1String("extra")) {
                const auto fields = line.split(QLatin1Char(':'));
                if (fields.size() != 2) return false;
                if (fields.first().trimmed() == QLatin1String("MaxLayer")) {
                    bool valid = false;
                    const int layer = fields.last().trimmed().toInt(&valid);
                    if (!valid || layer < 0 || layer > 50) return false;
                } else if (fields.first().trimmed() == QLatin1String("DefaultStyles") && fields.last().split(QLatin1Char(',')).size() > 51) return false;
            } else if (section == QLatin1String("events")) {
                if (line.startsWith(QStringLiteral("Format:"))) {
                    QString columns = line.section(QLatin1Char(':'), 1).toLower();
                    columns.remove(QLatin1Char(' '));
                    if (columns != eventFormat && columns != QString(eventFormat).replace(QStringLiteral(",name,"), QStringLiteral(",actor,"))) {
                        reason = QStringLiteral("Native ASS imports require the standard event column order.");
                        return false;
                    }
                    continue;
                }
                if ((!line.startsWith(QStringLiteral("Dialogue:")) && !line.startsWith(QStringLiteral("Comment:"))) ||
                    line.contains(QStringLiteral("Format:"))) return false;
                const auto fields = line.section(QLatin1Char(':'), 1).split(QLatin1Char(','));
                if (fields.size() < 10) return false;
                bool valid = false;
                const int layer = fields.first().trimmed().toInt(&valid);
                GenTime start, end;
                if (!valid || !subtitleTimestamp(fields.at(1), format, fps, multiplier, start) ||
                    !subtitleTimestamp(fields.at(2), format, fps, multiplier, end)) return false;
                for (int index = 5; index <= 7; ++index) {
                    fields.at(index).toInt(&valid);
                    if (!valid) return false;
                }
                if (!candidate(layer, start, end)) return false;
            }
        }
    }
    if (candidateCount == 0) {
        reason = QStringLiteral("Import 1-10000 complete native subtitle events.");
        return false;
    }
    return true;
}

'''
assert 'bool subtitleFilePreflight(' not in s
s=s.replace('QJsonObject subtitleReadback(',helper+'QJsonObject subtitleReadback(',1)
s=s.replace('parsing and undo."),','parsing and undo. Imports ASS, SRT, plain WebVTT cues and SBV; unsupported metadata is rejected."),',1)
s=s.replace('s("Import encoding, default UTF-8")','s("Import codec recognized by this Qt build, default UTF-8; Unicode BOM takes precedence")',1)
start=s.index('        int offset = 0;\n',s.index('    if (name == QLatin1String("subtitle_file"))'))
end=s.index('        if (!model) model = timeline->createSubtitleModel();',start)
new=r'''        int offset = 0;
        double sourceFps = pCore->getCurrentFps();
        if ((arguments.contains(QStringLiteral("offsetFrames")) && !integer(arguments, QStringLiteral("offsetFrames"), -MaxFrame, MaxFrame, offset)) ||
            (arguments.contains(QStringLiteral("sourceFps")) && !real(arguments, QStringLiteral("sourceFps"), 1, 240, sourceFps)) || !file.isFile() ||
            file.isSymLink() || file.size() <= 0 || file.size() > 16 * 1024 * 1024 ||
            (extension != QLatin1String("ass") && extension != QLatin1String("srt") && extension != QLatin1String("vtt") && extension != QLatin1String("sbv")))
            return failure(QStringLiteral("INVALID_PATH"),
                           QStringLiteral("Import a bounded local ASS/SRT/VTT/SBV subtitle file and valid frame-rate offset."), state);
        QString encoding = QStringLiteral("UTF-8");
        if (arguments.contains(QStringLiteral("encoding")) && !text(arguments, QStringLiteral("encoding"), encoding, 128))
            return failure(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Use a bounded subtitle codec name."), state);
        auto encodingId = QStringConverter::encodingForName(encoding.toLatin1().constData());
        if (!encodingId) return failure(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Use a subtitle encoding recognized by this Qt build."), state);
        QFile input(path);
        if (!input.open(QIODevice::ReadOnly)) return failure(QStringLiteral("INVALID_PATH"), input.errorString(), state);
        const QByteArray bytes = input.read(16 * 1024 * 1024 + 1);
        if (input.error() != QFileDevice::NoError || !input.atEnd() || bytes.size() > 16 * 1024 * 1024)
            return failure(QStringLiteral("INVALID_PATH"), QStringLiteral("Subtitle input could not be read within the file limit."), state);
        input.close();
        // QTextStream enables Unicode BOM detection even when a codec is selected.
        // Decode once with the same BOM precedence, reject incomplete sequences,
        // and hand the native parser immutable UTF-8 in a lowercase-suffix file.
        if (bytes.startsWith(QByteArray::fromHex("efbbbf")) || bytes.startsWith(QByteArray::fromHex("fffe")) ||
            bytes.startsWith(QByteArray::fromHex("feff")) || bytes.startsWith(QByteArray::fromHex("0000feff")))
            encodingId = QStringConverter::encodingForData(bytes);
        if (!encodingId) return failure(QStringLiteral("INVALID_SUBTITLE_FILE"), QStringLiteral("Unrecognized subtitle Unicode BOM."), state);
        QStringDecoder decoder(*encodingId, QStringConverter::Flag::Stateless);
        const QString contents = decoder.decode(bytes);
        if (decoder.hasError() || contents.contains(QChar::Null))
            return failure(QStringLiteral("INVALID_SUBTITLE_FILE"), QStringLiteral("Subtitle decoding failed for this encoding."), state);
        int candidateCount = 0;
        QString preflightCode, reason;
        if (!subtitleFilePreflight(contents, extension, model, pCore->getCurrentFps(), sourceFps, offset, candidateCount, preflightCode, reason))
            return failure(preflightCode, reason, state);
        QTemporaryDir staged;
        if (!staged.isValid()) return failure(QStringLiteral("SAVE_FAILED"), QStringLiteral("Cannot stage the validated subtitle file."), state);
        const QString validatedPath = staged.filePath(QStringLiteral("subtitles.") + extension);
        QFile validated(validatedPath);
        const QByteArray utf8 = contents.toUtf8();
        if (!validated.open(QIODevice::WriteOnly | QIODevice::NewOnly) || validated.write(utf8) != utf8.size() || !validated.flush())
            return failure(QStringLiteral("SAVE_FAILED"), QStringLiteral("Cannot stage the validated subtitle file."), state);
        validated.close();
'''
s=s[:start]+new+s[end:]
s=s.replace('model->importSubtitle(path, offset, true, float(sourceFps), float(pCore->getCurrentFps()), encoding.toLatin1());','model->importSubtitle(validatedPath, offset, true, float(sourceFps), float(pCore->getCurrentFps()), QByteArrayLiteral("UTF-8"));',1)
s=s.replace('        data.insert(QStringLiteral("importedCount"), model->count() - before);','        data.insert(QStringLiteral("importedCount"), model->count() - before);\n        data.insert(QStringLiteral("format"), extension);\n        data.insert(QStringLiteral("encoding"), QString::fromLatin1(QStringConverter::nameForEncoding(*encodingId)));',1)
p.write_text(s,encoding='utf-8')
print('Patched subtitle-only schema, branch and private preflight helper.')
