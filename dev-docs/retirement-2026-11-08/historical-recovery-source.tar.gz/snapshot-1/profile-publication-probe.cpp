#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QTemporaryDir>
#include <QTemporaryFile>
int main(int argc, char **argv) {
    QCoreApplication app(argc, argv);
    QTemporaryDir dir;
    if (!dir.isValid()) return 1;
    const QByteArray payload("native profile probe\n");
    const QString path = dir.filePath("profile");
    {
        QTemporaryFile temporary(dir.filePath(".kdenlive-profile-XXXXXX"));
        if (!temporary.open() || temporary.write(payload) != payload.size() || !temporary.flush()) return 2;
        temporary.close();
        if (!temporary.rename(path)) { qInfo() << "publish failed" << temporary.errorString(); return 3; }
        temporary.setAutoRemove(false);
    }
    QFile result(path);
    if (!result.open(QIODevice::ReadOnly) || result.readAll() != payload) return 4;
    result.close();
    {
        QTemporaryFile temporary(dir.filePath(".kdenlive-profile-XXXXXX"));
        if (!temporary.open() || temporary.write("changed") != 7 || !temporary.flush()) return 5;
        temporary.close();
        if (temporary.rename(path)) return 6;
    }
    if (!result.open(QIODevice::ReadOnly) || result.readAll() != payload) return 7;
    if (!QDir(dir.path()).entryList({".kdenlive-profile-*"}, QDir::Files | QDir::Hidden).isEmpty()) return 8;
    qInfo() << "PASS: owned Windows new-file publication, existing-target refusal, payload preservation and staging cleanup";
    return 0;
}
