param([ValidateSet('focused','native','gui','install')][string]$Stage='native',[string]$LogName='completion-native-28.log',[string]$Phase='all',[string]$Regex='^(mcptest|subtitlestest|groupstest|sequencetest|markertest|bintest|treetest|mcp_proxy)$')
$ErrorActionPreference='Stop'
$taskRoot='C:\Users\USER\.codex\work\kdenlive-mcp-completion'
$craftPrefix='C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot'
$buildRoot=Join-Path $craftPrefix 'build\kde\kdemultimedia\kdenlive\work\build'
$taskPython='C:\Users\USER\AppData\Local\Python\pythoncore-3.14-64\python.exe'
$env:CRAFT_PYTHON=$taskPython
function Clear-Host {}
. (Join-Path $craftPrefix 'craft\craftenv.ps1')
Set-Location -LiteralPath $taskRoot
$env:PATH="$(Join-Path $buildRoot 'bin');$(Join-Path $craftPrefix 'bin');$env:PATH"
$env:KDEROOT=$buildRoot
$env:MLT_DATA=Join-Path $craftPrefix 'share\mlt'
$env:MLT_PROFILES_PATH=Join-Path $craftPrefix 'share\mlt\profiles'
$env:QT_QPA_PLATFORM='windows'
$env:QT_FORCE_STDERR_LOGGING='1'
$env:SDL_AUDIODRIVER='dummy'
$ownedTemp=Join-Path $taskRoot 'native-final-temp'
New-Item -ItemType Directory -Path $ownedTemp -Force | Out-Null
$env:TEMP=$ownedTemp
$env:TMP=$ownedTemp
if ($Stage -eq 'focused') {
 & $taskPython -B (Join-Path $taskRoot 'run_owned_native_cases.py') --build $buildRoot --log (Join-Path $taskRoot $LogName) --tags '[MCPLargeState],[MCPWire],[MCPCategories],[ass-transaction],[formats]'
} elseif ($Stage -eq 'native') {
 & $taskPython -B (Join-Path $taskRoot 'run_owned_native_tests.py') --build $buildRoot --log (Join-Path $taskRoot $LogName) --regex $Regex
} elseif ($Stage -eq 'gui') {
 & $taskPython -B (Join-Path $taskRoot 'completion_gui_smoke.py') --app (Join-Path $buildRoot 'bin\kdenlive.exe') --proxy 'C:\Users\USER\Documents\kdenlive\src\mcp\kdenlive-mcp.py' --renderer (Join-Path $craftPrefix 'bin\kdenlive_render.exe') --ffmpeg (Join-Path $craftPrefix 'bin\ffmpeg.exe') --ffprobe (Join-Path $craftPrefix 'bin\ffprobe.exe') --python $taskPython --work-dir $taskRoot --phase $Phase --audio-backend sdl2_audio
} elseif ($Stage -eq 'install') {
 & cmake --install $buildRoot *> (Join-Path $taskRoot $LogName)
}
$verifyExit=$LASTEXITCODE
if ($Stage -ne 'gui') { Get-Content -LiteralPath (Join-Path $taskRoot $LogName) -Tail 25 -ErrorAction SilentlyContinue }
exit $verifyExit
