from __future__ import annotations
import argparse, datetime, hashlib, json, os, re
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--native-log',type=Path,required=True)
p.add_argument('--gui',type=Path,nargs='+',required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
build=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot\build\kde\kdemultimedia\kdenlive\work\build')
source=Path(r'C:\Users\USER\Documents\kdenlive')
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read_json(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def require(value,message):
 if not value: raise RuntimeError(message)
manifest=read_json(work/'build30-source-manifest.json')
changes=[name for name,value in manifest['files'].items() if digest(source/name)!=value]
require(not changes,f'Source changed after build snapshot: {changes}')
text=a.native_log.read_text(encoding='utf-8-sig',errors='replace')
require('100% tests passed' in text and '0 tests failed out of 8' in text,'All eight native/connector CTest suites must pass')
imports=(work/'final-app-imports.txt').read_text(encoding='utf-8-sig',errors='replace')
require('mlt_playlist_get_entries_info' in imports,'Final app must import the verified bulk playlist API')
runtime=read_json(work/'private-runtime-manifest.json')
expected={Path(v['destination']).name.lower():v for v in runtime if Path(v['destination']).suffix.lower()=='.dll'}
require(len(expected)==6,'Expect two MLT DLLs and four rebuilt native modules')
live=[]
phases=set()
for path in a.gui:
 report=read_json(path)
 require(report.get('status')=='passed',f'GUI check failed: {path}')
 modules=report.get('loadedModules',{}).get('modules',[])
 found={}
 for module in modules:
  name=module['name'].lower()
  require(name not in found,f'Duplicate loaded module: {name}')
  found[name]=module
 for name,item in expected.items():
  require(name in found,f'Module missing from actual GUI process: {name}')
  require(found[name]['sha256'].lower()==item['sha256'].lower(),f'Loaded module hash mismatch: {name}')
  require(os.path.normcase(os.path.realpath(found[name]['path']))==os.path.normcase(os.path.realpath(item['destination'])),f'Wrong loaded module path: {name}')
 phases.update(report.get('completedPhases',[]))
 live.append({'report':str(path),'sha256':digest(path),'phases':report['completedPhases'],'moduleProvenanceVerified':True})
required={'catalogs','profile','timeline','effects','lifecycle','sequences','dialogs','state','subtitle_ass','subtitle_languages','monitors'}
require(required<=phases,f'Missing GUI phases: {sorted(required-phases)}')
last=(build/'Testing/Temporary/LastTest.log').read_text(encoding='utf-8',errors='replace')
case_counts=[{'assertions':int(n.replace(',','')),'cases':int(c)} for n,c in re.findall(r'All tests passed \(([\d,]+) assertions? in (\d+) test cases?\)',last)]
for c,n in re.findall(r'Passed all (\d+) test cases with (\d+) assertions',last): case_counts.append({'assertions':int(n),'cases':int(c)})
deps=read_json(work/'r39-mlt-api/app-completion-report.json')
patches={str(v.relative_to(source)).replace('\\','/'):digest(v) for v in sorted((source/'packaging/patches').glob('*.patch'))}
result={'schemaVersion':1,'verifiedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'version':'0.4.0','status':'passed','completionScope':'Recovered native MCP 0.4 integration and its supported contracts','completeEditorCoverageVerified':False,'source':manifest,'build':{'directory':str(build),'successfulLog':str(work/'completion-build-31.log'),'bulkPlaylistApiImported':True,'applicationSha256':digest(build/'bin/kdenlive.exe'),'connectorSha256':digest(source/'src/mcp/kdenlive-mcp.py')},'native':{'ctestSuitesPassed':8,'log':str(a.native_log),'logSha256':digest(a.native_log),'suiteCaseCounts':case_counts,'portableConnectorTests':23,'portableConnectorPlatformSkips':1},'dependencies':{'proof':str(work/'r39-mlt-api/app-completion-report.json'),'report':deps,'sourcePatches':patches,'privateRuntime':runtime},'liveEditor':live,'originalInstalledRuntimePreserved':True,'validationMedia':'Generated task-owned assets; no original user projects or source media changed','limitations':['Complete coverage of every editor function has not been established.','Optional speech/model/plugin/device workflows require their own local prerequisites.','The render dependency queue is session-local.','SDL lifecycle was exercised with dummy audio; physical sound devices were not validated.']}
a.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'status':'passed','verification':str(a.output),'sourceFiles':len(manifest['files']),'guiReports':len(live),'suiteCaseCounts':case_counts}))
