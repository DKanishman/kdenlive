#include <QApplication>
#include <QDebug>
#include <QMimeDatabase>
#include <QJsonArray>
#include <QJsonDocument>
#include <QStandardPaths>
#include <QTreeWidget>
int main(int argc, char **argv) {
 QApplication app(argc,argv);
 const QString path=QString::fromLocal8Bit(argv[1]);
 const auto content=QMimeDatabase().mimeTypeForFile(path,QMimeDatabase::MatchContent);
 qInfo() << "mime-content" << content.name() << content.parentMimeTypes();
 qInfo() << "mime-default" << QMimeDatabase().mimeTypeForFile(path).name();
 QJsonArray paths{QJsonArray{1}};
 qInfo() << "paths" << QJsonDocument(paths).toJson(QJsonDocument::Compact);
 QTreeWidget tree;
 tree.addTopLevelItem(new QTreeWidgetItem(QStringList{QStringLiteral("First")}));
 tree.addTopLevelItem(new QTreeWidgetItem(QStringList{QStringLiteral("Second")}));
 qInfo() << "flags" << tree.model()->index(1,0).flags();
 qInfo() << "melt-path" << QStandardPaths::findExecutable(QStringLiteral("melt"));
 qInfo() << "data" << QStandardPaths::standardLocations(QStandardPaths::AppDataLocation);
}
