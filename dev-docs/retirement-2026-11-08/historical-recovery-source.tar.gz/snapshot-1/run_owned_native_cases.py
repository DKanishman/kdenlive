from __future__ import annotations
import argparse, importlib.util, json, os, sys
from pathlib import Path
helper=Path(r"C:\Users\USER\.codex\work\kdenlive-mcp-prototype\live_smoke.py")
spec=importlib.util.spec_from_file_location("owned_case_helpers",helper)
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
parser=argparse.ArgumentParser()
parser.add_argument("--build",required=True)
parser.add_argument("--log",required=True)
parser.add_argument("--tags",required=True)
args=parser.parse_args()
owned=common.OwnedJob()
try:
    command=[str(Path(args.build)/"bin"/"mcptest.exe"),args.tags,"--reporter","compact"]
    common.run_logged(command,Path(args.log),dict(os.environ),owned,180)
    print(json.dumps({"status":"passed","tags":args.tags,"log":args.log}))
except Exception as error:
    print(json.dumps({"status":"failed","error":str(error),"log":args.log}));sys.exit(1)
finally:
    owned.close()
