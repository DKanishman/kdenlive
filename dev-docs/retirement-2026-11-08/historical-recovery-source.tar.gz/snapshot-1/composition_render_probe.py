from __future__ import annotations
from pathlib import Path
import importlib.util, os, json, uuid, xml.etree.ElementTree as E
from PIL import Image, ImageDraw, ImageChops
work=Path(__file__).parent/('composition-probe-'+uuid.uuid4().hex[:10]); work.mkdir()
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot')
spec=importlib.util.spec_from_file_location('owned_helper',Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\live_smoke.py'))
h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
pattern=Image.new('RGBA',(160,120)); d=ImageDraw.Draw(pattern);d.rectangle((0,0,99,39),fill='red');d.rectangle((100,40,159,119),fill='yellow');d.rectangle((20,60,49,89),fill='green');pattern.save(work/'pattern.png')
env=dict(os.environ);env['PATH']=str(prefix/'bin')+os.pathsep+env.get('PATH','');env['QT_QPA_PLATFORM']='offscreen';env['MLT_REPOSITORY_DENY']='libmltqt:libmltglaxnimate';env['MLT_REPOSITORY']=str(prefix/'lib/mlt');env['MLT_DATA']=str(prefix/'share/mlt');env['QT_FORCE_STDERR_LOGGING']='1'
def prop(node,key,value):E.SubElement(node,'property',{'name':key}).text=str(value)
job=h.OwnedJob(); result=[]
try:
 for name,service,parameter,animation in [('slide','affine','rect','0=-100% 0% 100% 100% 100%;19=0% 0% 100% 100% 100%'),('rotate','affine','rotate_z','0g=0;19=45'),('wipe','composite','geometry','0=0% 0% 100% 100% 0%;19=0% 0% 100% 100% 100%')]:
  root=E.Element('mlt',{'producer':'main','LC_NUMERIC':'C'});E.SubElement(root,'profile',{'description':'probe','width':'720','height':'576','frame_rate_num':'25','frame_rate_den':'1','progressive':'1','sample_aspect_num':'16','sample_aspect_den':'15','display_aspect_num':'4','display_aspect_den':'3','colorspace':'601'})
  blue=E.SubElement(root,'producer',{'id':'blue','in':'0','out':'19'});prop(blue,'mlt_service','color');prop(blue,'resource','#0000ffff');prop(blue,'length',20)
  front=E.SubElement(root,'producer',{'id':'front','in':'0','out':'19'});prop(front,'mlt_service','avformat');prop(front,'resource',(work/'pattern.png').as_posix());prop(front,'length',20);prop(front,'eof','loop');prop(front,'loop',1)
  tractor=E.SubElement(root,'tractor',{'id':'main','in':'0','out':'19'});E.SubElement(tractor,'track',{'producer':'blue'});E.SubElement(tractor,'track',{'producer':'front'})
  transition=E.SubElement(tractor,'transition',{'in':'0','out':'19'});prop(transition,'mlt_service',service);prop(transition,'a_track',0);prop(transition,'b_track',1);prop(transition,'keyed',1);prop(transition,'distort',1);prop(transition,parameter,animation)
  xml=work/(name+'.mlt');E.ElementTree(root).write(xml,encoding='utf-8',xml_declaration=True)
  folder=work/name;folder.mkdir()
  h.run_logged([str(prefix/'bin/melt.exe'),str(xml),'-silent','-consumer','avformat:'+str(folder/'frame-%03d.png'),'f=image2','vcodec=png','an=1','real_time=-1'],work/(name+'.log'),env,job,30)
  files=sorted(folder.glob('frame-*.png')); a,b=Image.open(files[0]).convert('RGB'),Image.open(files[-1]).convert('RGB')
  result.append({'service':name,'count':len(files),'size':a.size,'first':a.getpixel((4,4)),'last':b.getpixel((4,4)),'diff':ImageChops.difference(a,b).getbbox()})
 print(json.dumps({'work':str(work),'result':result}))
finally:job.close()
