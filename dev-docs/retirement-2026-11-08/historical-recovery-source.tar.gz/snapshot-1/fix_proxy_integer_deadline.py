from pathlib import Path
root=Path(r'C:\Users\USER\Documents\kdenlive')
proxy=root/'src/mcp/kdenlive-mcp.py'; text=proxy.read_text(encoding='utf-8')
old='''    deadline = time.monotonic() + timeout
    while True:
        if time.monotonic() >= deadline:
            raise TimeoutError("Named pipe connection deadline expired.")'''
new='''    # Integer ticks avoid float cancellation at large system uptimes. A short
    # timeout must not acquire an extra millisecond when converted for Win32.
    deadline_ns = time.monotonic_ns() + math.ceil(timeout * 1_000_000_000)
    while True:
        if time.monotonic_ns() >= deadline_ns:
            raise TimeoutError("Named pipe connection deadline expired.")'''
assert text.count(old)==1;text=text.replace(old,new,1)
old='''        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("Named pipe connection deadline expired.")
        # WaitNamedPipe is bounded and may race another client; retry CreateFile
        # only while establishing this one connection, never after a request.
        api.wait(path, max(1, math.ceil(remaining * 1000)))'''
new='''        remaining_ns = deadline_ns - time.monotonic_ns()
        if remaining_ns <= 0:
            raise TimeoutError("Named pipe connection deadline expired.")
        # WaitNamedPipe is bounded and may race another client; retry CreateFile
        # only while establishing this one connection, never after a request.
        api.wait(path, max(1, (remaining_ns + 999_999) // 1_000_000))'''
assert text.count(old)==1;text=text.replace(old,new,1)
proxy.write_text(text,encoding='utf-8',newline='\n')
tests=root/'tests/test_kdenlive_mcp_proxy.py'; text=tests.read_text(encoding='utf-8')
anchor='    def test_nonbusy_error_is_not_retried(self):'
regression='''    def test_busy_wait_budget_uses_exact_ticks_at_large_uptime(self):
        api = FakePipeApi([self.busy(), self.busy(), 77])
        initial = 1_000_000_000_000_000_000
        ticks = [initial, initial, initial, initial + 100_000_000,
                 initial + 100_000_000, initial + 199_000_000]
        with mock.patch.object(proxy.time, "monotonic_ns", side_effect=ticks):
            transport = proxy.connect_windows("kdenlive-local-test", 0.2, api=api)
        self.assertEqual([milliseconds for _, milliseconds in api.waits], [200, 100])
        transport.close()
        self.assertEqual(api.closed, [77])

    def test_busy_deadline_is_rechecked_after_wait(self):
        api = FakePipeApi([self.busy()])
        ticks = [0, 0, 199_999_999, 200_000_000]
        with mock.patch.object(proxy.time, "monotonic_ns", side_effect=ticks):
            with self.assertRaises(TimeoutError):
                proxy.connect_windows("kdenlive-local-test", 0.2, api=api)
        self.assertEqual(len(api.paths), 1)
        self.assertEqual([milliseconds for _, milliseconds in api.waits], [1])

'''
assert text.count(anchor)==1;text=text.replace(anchor,regression+anchor,1)
tests.write_text(text,encoding='utf-8',newline='\n')
print('Proxy deadline fix and exact-clock regressions written.')
