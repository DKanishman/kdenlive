from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpspeech.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('job->output.clear(); job->errors.clear(); if (job->temporary) job->temporary.reset();', 'job->output.clear(); job->errors.clear();\n        if (job->temporary && (!job->process || job->process->state() == QProcess::NotRunning)) job->temporary.reset();', 1)
s=s.replace('sourceIdentity(source) == job->identity;', 'sourceIdentity(source) == job->identity && std::abs(pCore->getCurrentFps() - job->fps) < 1e-9;', 1)
s=s.replace('for (const auto &job : jobs) if (!job->terminal) ++active;', 'for (const auto &job : jobs) if (!job->terminal || (job->process && job->process->state() != QProcess::NotRunning)) ++active;', 1)
s=s.replace('QStringList args{k("-v"), k("error"), k("-nostdin"), k("-i")', 'QStringList args{k("-v"), k("error"), k("-nostdin"), k("-protocol_whitelist"), k("file,pipe"), k("-i")', 1)
start=s.index('QJsonObject wordPage(')
end=s.index('\nstruct SpeechJob',start)
s=s[:start]+'''QList<Word> withNativeSilences(const QList<Word> &words, double begin, double end, double fps)
{
    QList<Word> result;
    double previousEnd = begin; int previousBlock = -1, block = 0;
    for (const auto &word : words) {
        if (word.block != previousBlock) {
            if (GenTime(word.start).frames(fps) > GenTime(previousEnd).frames(fps) + 1)
                result.append({previousEnd, word.start, i18n("No speech"), block++, true});
            else ++block;
        }
        auto copy = word; copy.block = block; result.append(copy);
        previousEnd = std::max(previousEnd, word.end); previousBlock = word.block;
    }
    if (GenTime(end).frames(fps) > GenTime(previousEnd).frames(fps) + 1)
        result.append({previousEnd, end, i18n("No speech"), block + 1, true});
    return result;
}
QJsonObject wordPage(const QList<Word> &words, int offset, int limit, double fps, int endBoundary)
{
    QJsonArray page, speechRanges, editRanges;
    int begin = -1, end = -1, paragraph = -1; bool silence = false;
    auto flush = [&] {
        if (begin < 0 || end < begin) return;
        const QJsonObject range{{k("sourceInFrame"), begin}, {k("sourceOutFrame"), end}, {k("durationFrames"), end - begin + 1}};
        editRanges.append(range); if (!silence) speechRanges.append(range);
    };
    for (int i = offset; i < std::min(int(words.size()), offset + limit); ++i) {
        const auto &word = words.at(i);
        const int first = std::clamp(GenTime(word.start).frames(fps), 0, endBoundary);
        const int boundary = std::clamp(GenTime(word.end).frames(fps), first, endBoundary), last = boundary - 1;
        page.append(QJsonObject{{k("index"), i}, {k("text"), word.text}, {k("startSeconds"), word.start}, {k("endSeconds"), word.end},
                                {k("sourceInFrame"), first}, {k("sourceOutFrame"), last}, {k("endBoundaryFrame"), boundary},
                                {k("durationFrames"), boundary - first}, {k("insertable"), boundary > first},
                                {k("silence"), word.silence}, {k("paragraph"), word.block}});
        if (boundary <= first) continue;
        if (begin >= 0 && (paragraph != word.block || silence != word.silence)) { flush(); begin = -1; }
        if (begin < 0) { begin = first; end = last; paragraph = word.block; silence = word.silence; }
        else end = std::max(end, last);
    }
    flush();
    return {{k("wordCount"), words.size()}, {k("offset"), offset}, {k("words"), page}, {k("speechRanges"), speechRanges}, {k("editRanges"), editRanges},
            {k("hasMore"), offset + limit < words.size()}, {k("fps"), fps},
            {k("frameConvention"), k("Native GenTime boundary rounding; sourceOutFrame=endBoundaryFrame-1, inclusive and clipped to source/range.")}};
}
''' + s[end:]
s=s.replace('''            const auto items = group.toObject().value(job->engine == k("whisper") ? k("words") : k("result")).toArray();''', '''            const QString wordsKey = job->engine == k("whisper") ? k("words") : k("result");
            const auto value = group.toObject().value(wordsKey);
            const bool emptyVosk = job->engine == k("vosk") && value.isUndefined() && group.toObject().value(k("text")).isString() && group.toObject().value(k("text")).toString().isEmpty();
            if (!group.isObject() || (!value.isArray() && !emptyVosk)) {
                fail(job, k("INVALID_RESULT"), k("Native transcript contains a malformed word group.")); return;
            }
            const auto items = value.toArray();''',1)
s=s.replace('''            const QString task = arguments.value(k("task")).toString(k("transcribe"));''','''            if (arguments.contains(k("task")) && !arguments.value(k("task")).isString()) return reject("INVALID_ARGUMENT", "Task must be a string.");
            const QString task = arguments.value(k("task")).toString(k("transcribe"));''',1)
s=s.replace('''            job->task = task == k("translate_english") ? k("translate") : task;''','''            if (task == k("translate_english") && (job->model.contains(k("turbo")) || job->model.endsWith(k(".en"))))
                return reject("UNSUPPORTED_MODEL_TASK", "Turbo and English-only Whisper checkpoints do not support multilingual translation-to-English.");
            job->task = task == k("translate_english") ? k("translate") : task;''',1)
s=s.replace('''    QString binId = arguments.value(k("binId")).toString(); std::shared_ptr<ProjectClip> source; QList<Word> words; double fps = pCore->getCurrentFps();''','''    QString binId = arguments.value(k("binId")).toString(); std::shared_ptr<ProjectClip> source; QList<Word> words; double fps = pCore->getCurrentFps(); int endBoundary = 10000001;''',1)
s=s.replace('words = job->words; fps = job->fps; binId = job->binId;', 'words = job->words; fps = job->fps; binId = job->binId; endBoundary = job->outFrame + 1;',1)
s=s.replace('''        if (!readNativeWords(binId, source->getProducerProperty(k("kdenlive:speech")), words))''','''        endBoundary = int(std::min(size_t(10000001), source->frameDuration()));
        if (!readNativeWords(binId, source->getProducerProperty(k("kdenlive:speech")), words))''',1)
s=s.replace('wordPage(words, offset, limit, fps)', 'wordPage(words, offset, limit, fps, endBoundary)',1)
s=s.replace('''        words = job->words;
    } else if''','''        words = withNativeSilences(job->words, job->inFrame / job->fps, (job->outFrame + 1) / job->fps, job->fps);
    } else if''',1)
s=s.replace('''            if (action == k("remove_words")) words.erase(words.begin() + first, words.begin() + first + count); else words = words.mid(first, count);''','''            if (action == k("remove_words")) {
                // Native fullExport spans each paragraph. Split at a deletion so
                // reopening the editor cannot reintroduce the removed audio.
                if (first > 0 && first + count < words.size() && words.at(first - 1).block == words.at(first + count).block) {
                    int maximumBlock = 0; for (const auto &word : words) maximumBlock = std::max(maximumBlock, word.block);
                    const int oldBlock = words.at(first + count).block;
                    for (int i = first + count; i < words.size() && words.at(i).block == oldBlock; ++i) words[i].block = maximumBlock + 1;
                }
                words.erase(words.begin() + first, words.begin() + first + count);
            } else words = words.mid(first, count);''',1)
s=s.replace('Inclusive speechRanges can be used', 'Current editRanges preserve retained silence; speechRanges omit silence. Inclusive ranges can be used',1)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpspeech_cases.inc')
s=p.read_text(encoding='utf-8').replace('#include <KLocalizedString>','#include <KLocalizedString>\n#include <QApplication>',1)
s=s.replace('CHECK_FALSE(range.value(QStringLiteral("sourceInFrame")).toInt() <= 12 && range.value(QStringLiteral("sourceOutFrame")).toInt() >= 12);','CHECK_FALSE((range.value(QStringLiteral("sourceInFrame")).toInt() <= 12 && range.value(QStringLiteral("sourceOutFrame")).toInt() >= 12));')
p.write_text(s,encoding='utf-8')
print('Applied process lifetime, native exclusive-boundary, exact edit-range, silence and result-validation corrections.')
