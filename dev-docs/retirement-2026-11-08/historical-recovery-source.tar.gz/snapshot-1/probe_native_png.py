from pathlib import Path
import importlib.util, os, subprocess, uuid, json
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot')
work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')/('png-probe-'+uuid.uuid4().hex)
work.mkdir()
spec=importlib.util.spec_from_file_location('owned_helpers', prefix.parent/'live_smoke.py')
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
env=dict(os.environ)
env['PATH']=str(prefix/'bin')+os.pathsep+env.get('PATH','')
env['MLT_REPOSITORY']=str(prefix/'lib'/'mlt')
env['MLT_DATA']=str(prefix/'share'/'mlt-7')
env['QT_PLUGIN_PATH']=str(prefix/'plugins')
results=[]
for mode,extra in [('default',[]),('one-thread',['threads=1'])]:
    output=work/mode;output.mkdir()
    args=[str(prefix/'bin'/'melt.exe'),'-loglevel','error','-progress2','-profile','dv_pal','color:red','in=0','out=7','-consumer','avformat:'+str(output/'frame_%05d.png').replace('\\','/'),'progressive=1','f=image2','vcodec=png','an=1','audio_off=1','g=1','bg=0','pix_fmt=rgba']+extra
    owned=common.OwnedJob()
    process=None
    try:
        process=subprocess.Popen(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,**common.hidden_options())
        owned.attach(process)
        data,_=process.communicate(timeout=15)
        (work/(mode+'.log')).write_bytes(data)
        files=list(output.glob('*.png'))
        results.append({'mode':mode,'exitCode':process.returncode,'files':len(files),'sizes':[p.stat().st_size for p in files],'logTail':data[-4000:].decode('utf-8','replace')})
    finally:
        common.stop_owned(process);owned.close()
(work/'result.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps({'work':str(work),'results':results},indent=2))
