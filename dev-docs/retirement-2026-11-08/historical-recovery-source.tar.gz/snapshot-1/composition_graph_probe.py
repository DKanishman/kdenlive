from pathlib import Path
import xml.etree.ElementTree as E, importlib.util, os, json, uuid
from PIL import Image, ImageChops
prefix=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot');source=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\composition-probe-e48c8eda33');work=source.parent/('composition-graph-'+uuid.uuid4().hex[:10]);work.mkdir()
spec=importlib.util.spec_from_file_location('owned_helper',Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\live_smoke.py'));h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
env=dict(os.environ);env['PATH']=str(prefix/'bin')+os.pathsep+env.get('PATH','');env['QT_QPA_PLATFORM']='offscreen';env['MLT_REPOSITORY_DENY']='libmltqt:libmltglaxnimate';env['MLT_DATA']=str(prefix/'share/mlt');env['QT_FORCE_STDERR_LOGGING']='1'
def prop(node,key,value):E.SubElement(node,'property',{'name':key}).text=str(value)
job=h.OwnedJob();results=[]
try:
 for asset in ('slide','rotate','wipe'):
  root=E.parse(source/(asset+'.mlt')).getroot();tractor=root.find('tractor');root.remove(tractor)
  black=E.SubElement(root,'producer',{'id':'black'});prop(black,'mlt_service','color');prop(black,'resource','black');prop(black,'length',20)
  E.SubElement(root,'playlist',{'id':'empty'})
  root.append(tractor)
  for t in list(tractor.findall('track')):tractor.remove(t)
  transition=tractor.find('transition')
  for p in transition.findall('property'):
   if p.attrib['name']=='a_track':p.text='2'
   if p.attrib['name']=='b_track':p.text='3'
  for index,name in enumerate(('black','empty','blue','front')):tractor.insert(index,E.Element('track',{'producer':name}))
  for index in (2,3):
   t=E.SubElement(tractor,'transition',{'in':'0','out':'19'});prop(t,'mlt_service','qtblend');prop(t,'a_track',0);prop(t,'b_track',index);prop(t,'internal_added',237);prop(t,'always_active',1)
  xml=work/(asset+'.mlt');E.ElementTree(root).write(xml,encoding='utf-8',xml_declaration=True)
  out=work/asset;out.mkdir()
  h.run_logged([str(prefix/'bin/melt.exe'),str(xml),'-silent','-consumer','avformat:'+str(out/'frame-%03d.png'),'f=image2','vcodec=png','an=1','real_time=-1'],work/(asset+'.log'),env,job,30)
  files=sorted(out.glob('frame-*.png'));a,b=Image.open(files[0]).convert('RGB'),Image.open(files[-1]).convert('RGB');results.append({'asset':asset,'count':len(files),'diff':ImageChops.difference(a,b).getbbox(),'first':a.getpixel((4,4)),'last':b.getpixel((4,4))})
 print(json.dumps({'work':str(work),'results':results}))
finally:job.close()
