from pathlib import Path
work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
source=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcpquick.cpp')
assert source.read_text(encoding='utf-8') == (work/'mcpquick.before-context-fix.cpp').read_text(encoding='utf-8'), 'Quick source changed; merge required'
s=(work/'mcpquick.context-fix.cpp').read_text(encoding='utf-8')
s=s.replace('''            control.menuOwners = lineage;''','''            for (const auto &owner : lineage)
                if (!control.menuOwners.contains(owner)) control.menuOwners.append(owner);''')
source.write_text(s,encoding='utf-8')
tests=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcpquick_cases.inc')
t=tests.read_text(encoding='utf-8')
assert 'MCP Quick text selections invalidate' not in t
t+='\n'+(work/'quick_context_regressions.inc').read_text(encoding='utf-8-sig')
tests.write_text(t,encoding='utf-8')
life=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcplifecycle.cpp')
s=life.read_text(encoding='utf-8')
s=s.replace('bool makeRoom(QHash<QString, QJsonObject> &jobs)', 'bool makeRoom(QHash<QString, QJsonObject> &jobs, const QString &preserve = {})')
s=s.replace('''        if (terminal(it.value().value(key("status")).toString())) {''','''        if (it.key() != preserve && terminal(it.value().value(key("status")).toString())) {''',1)
old='''if (!makeRoom(m_lifecycleJobs)) return failure(key("JOB_LIMIT"), key("Too many active jobs."), state);'''
assert old in s
s=s.replace(old,'''if (!makeRoom(m_lifecycleJobs, predecessor)) return failure(key("JOB_LIMIT"), key("Too many active jobs."), state);''',1)
life.write_text(s,encoding='utf-8')
print('Integrated Quick context and queue predecessor protection')
