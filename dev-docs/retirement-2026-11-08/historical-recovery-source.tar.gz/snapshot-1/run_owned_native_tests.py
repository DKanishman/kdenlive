from __future__ import annotations
import argparse, importlib.util, json, os, subprocess, sys
from pathlib import Path
helper=Path(r"C:\Users\USER\.codex\work\kdenlive-mcp-prototype\live_smoke.py")
spec=importlib.util.spec_from_file_location("owned_native_helpers",helper)
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
parser=argparse.ArgumentParser()
parser.add_argument("--build",required=True)
parser.add_argument("--log",required=True)
parser.add_argument("--regex",default="^mcptest$")
args=parser.parse_args()
job=common.OwnedJob()
try:
    command=["ctest","--test-dir",args.build,"-R",args.regex,"--output-on-failure","--no-tests=error","--timeout","360"]
    common.run_logged(command,Path(args.log),dict(os.environ),job,480)
    print(json.dumps({"status":"passed","log":args.log}))
except Exception as error:
    print(json.dumps({"status":"failed","error":str(error),"log":args.log}))
    sys.exit(1)
finally:
    job.close()
