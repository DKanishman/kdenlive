from pathlib import Path
import shutil
root=Path(r'C:\Users\USER\Documents\kdenlive')
work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
def edit(name,old,new):
 p=root/name;t=p.read_text(encoding='utf-8');assert old in t,name
 b=work/(name.replace('/','_')+'.category-before')
 if not b.exists():shutil.copy2(p,b)
 p.write_text(t.replace(old,new,1),encoding='utf-8',newline='\n')
edit('src/bin/bin.h','    void removeMarkerCategories(QList<int> toRemove, const QMap<int, int> remapCategories);','''    bool removeMarkerCategories(QList<int> toRemove, const QMap<int, int> remapCategories);
    /** Collect live recursive source/sequence marker models without opening timelines.
     *  Reject missing producers or pending serialized-marker imports before category edits.
     */
    static bool markerModelsForCategoryChange(const std::shared_ptr<ProjectItemModel> &itemModel,
                                             QList<std::shared_ptr<MarkerListModel>> &models);''')
edit('src/bin/bin.cpp','#include "projectfolder.h"','#include "projectfolder.h"\n#include <QJsonArray>\n#include <QJsonDocument>\n#include <QSet>')
p=root/'src/bin/bin.cpp';t=p.read_text(encoding='utf-8');a=t.index('void Bin::removeMarkerCategories(');b=t.index('QStringList Bin::sequenceReferencedClips',a)
edit('src/bin/bin.cpp',t[a:b],'''bool Bin::markerModelsForCategoryChange(const std::shared_ptr<ProjectItemModel> &itemModel,
                                       QList<std::shared_ptr<MarkerListModel>> &models)
{
    if (!itemModel || !itemModel->getRootFolder()) return false;
    auto collected = models;
    QSet<MarkerListModel *> seen;
    for (const auto &model : std::as_const(collected)) {
        if (!model) return false;
        seen.insert(model.get());
    }
    const auto clips = itemModel->getRootFolder()->childClips();
    for (const auto &clip : clips) {
        if (!clip || !clip->statusReady()) return false;
        const auto model = clip->getMarkerModel();
        if (!model) return false;
        // ProjectClip queues its producer's marker import during construction. Do not
        // discard markers that have not reached the live model yet, even if the producer is ready.
        const QString stored = clip->getProducerProperty(QStringLiteral("kdenlive:markers"));
        if (!stored.isEmpty()) {
            const auto data = QJsonDocument::fromJson(stored.toUtf8());
            if (!data.isArray() || (model->rowCount() == 0 && !data.array().isEmpty())) return false;
        }
        if (!seen.contains(model.get())) {
            collected.append(model);
            seen.insert(model.get());
        }
    }
    models = std::move(collected);
    return true;
}

bool Bin::removeMarkerCategories(QList<int> toRemove, const QMap<int, int> remapCategories)
{
    QList<std::shared_ptr<MarkerListModel>> models;
    if (!markerModelsForCategoryChange(m_itemModel, models)) return false;
    if (models.isEmpty()) return true;
    bool changed = false;
    for (const auto &model : std::as_const(models)) {
        for (int category : std::as_const(toRemove)) changed |= !model->getAllMarkers(category).isEmpty();
    }
    Fun undo = [] { return true; }, redo = [] { return true; };
    if (!MarkerListModel::removeCategories(models, toRemove, remapCategories, undo, redo)) return false;
    if (changed) pCore->pushUndo(undo, redo, i18n("Remove clip markers"));
    return true;
}

''')
edit('src/mltcontroller/clipcontroller.h','    bool removeMarkerCategories(const QList<int> toRemove, const QMap<int, int> remapCategories, Fun &undo, Fun &redo);','''    /** Remove/remap categories with stable marker IDs and ranges; true also means unchanged success. */
    bool removeMarkerCategories(const QList<int> toRemove, const QMap<int, int> remapCategories, Fun &undo, Fun &redo);''')
edit('src/doc/kdenlivedoc.h','    /** @brief Set the guides categories for the project in format {name:index:#color} */\n    void updateGuideCategories(const QStringList &categories, const QMap<int, int> remapCategories = {});','''    /** @brief Change project-wide categories and all source/sequence markers in one undo.
     *  Removed categories without a mapping delete their markers. Application defaults are
     *  unchanged: the current default category must be retained. Unready models or pending
     *  legacy guides reject the operation without changing the project or undo/redo history.
     */
    bool updateGuideCategories(const QStringList &categories, const QMap<int, int> remapCategories = {});''')
edit('src/doc/kdenlivedoc.cpp','#include "bin/projectclip.h"','#include "bin/projectclip.h"\n#include "bin/projectfolder.h"')
p=root/'src/doc/kdenlivedoc.cpp';t=p.read_text(encoding='utf-8');a=t.index('void KdenliveDoc::updateGuideCategories(');b=t.index('void KdenliveDoc::saveGuideCategories()',a)
edit('src/doc/kdenlivedoc.cpp',t[a:b],'''bool KdenliveDoc::updateGuideCategories(const QStringList &categories, const QMap<int, int> remapCategories)
{
    auto fail = [](const QString &message) {
        pCore->displayMessage(message, ErrorMessage);
        return false;
    };
    const auto active = m_timelines.value(activeUuid);
    if (!active || !active->getGuideModel() || !m_commandStack)
        return fail(i18n("Cannot change marker categories: the active guide model is unavailable."));
    const auto guideModel = active->getGuideModel();
    const QStringList currentCategories = guideModel->categoriesToStringList();
    if (categories == currentCategories && remapCategories.isEmpty()) return true;
    QSet<int> updatedIndexes;
    for (const auto &category : categories) updatedIndexes.insert(category.section(QLatin1Char(':'), -2, -2).toInt());
    if (pCore->markerTypes.contains(KdenliveSettings::default_marker_type()) && !updatedIndexes.contains(KdenliveSettings::default_marker_type()))
        return fail(i18n("Keep the current default marker category. Choose another application default explicitly before deleting it."));
    QList<std::shared_ptr<MarkerListModel>> models;
    const auto itemModel = pCore->projectItemModel();
    if (!Bin::markerModelsForCategoryChange(itemModel, models))
        return fail(i18n("Cannot change marker categories while a source or sequence marker model is unavailable or still loading."));
    // Use the live bin tree, not the cached sequence UUID map, which can contain
    // deleted entries. Modern unopened sequences already own their marker model.
    QSet<QUuid> sequences;
    const auto clips = itemModel->getRootFolder()->childClips();
    for (const auto &clip : clips) {
        if (clip->clipType() == ClipType::Timeline) sequences.insert(clip->getSequenceUuid());
    }
    for (auto i = m_timelines.cbegin(); i != m_timelines.cend(); ++i) {
        if (!i.value() || !i.value()->getGuideModel())
            return fail(i18n("Cannot change marker categories: a sequence guide model is unavailable."));
        sequences.insert(i.key());
        models.append(i.value()->getGuideModel());
    }
    for (const auto &uuid : std::as_const(sequences)) {
        if (!getSequenceProperty(uuid, QStringLiteral("guides")).isEmpty())
            return fail(i18n("Open the sequence containing pending legacy guides before changing marker categories."));
    }
    const QString property = QStringLiteral("guidesCategories");
    const bool hadProperty = m_documentProperties.contains(property);
    const QString oldProperty = m_documentProperties.value(property);
    Fun markerUndo = [] { return true; }, markerRedo = [] { return true; };
    if (!guideModel->loadCategoriesWithUndo(categories, currentCategories, remapCategories, markerUndo, markerRedo, models))
        return fail(i18n("Cannot change marker categories: invalid categories, remapping, or a busy marker model. The project was unchanged."));
    if (currentCategories == guideModel->categoriesToStringList()) return true;
    const QString newProperty = guideModel->categoriesToJSon();
    m_documentProperties.insert(property, newProperty);
    Fun undo = [this, markerUndo, hadProperty, property, oldProperty] {
        if (!markerUndo()) return false;
        if (hadProperty) m_documentProperties.insert(property, oldProperty);
        else m_documentProperties.remove(property);
        return true;
    };
    Fun redo = [this, markerRedo, property, newProperty] {
        if (!markerRedo()) return false;
        m_documentProperties.insert(property, newProperty);
        return true;
    };
    m_commandStack->push(new FunctionalUndoCommand(undo, redo, i18n("Update project marker categories")));
    return true;
}

''')
