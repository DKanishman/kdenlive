from pathlib import Path
p=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion\mcplifecycle.advanced.cpp')
s=p.read_text(encoding='utf-8')
s=s.replace('#include <mlt++/MltProducer.h>', '#include <mlt++/MltProducer.h>\n#include <mlt++/MltProfile.h>\n#ifdef Q_OS_WIN\n#include <qt_windows.h>\n#elif defined(Q_OS_LINUX)\n#include <fcntl.h>\n#include <sys/syscall.h>\n#include <unistd.h>\n#elif defined(Q_OS_MACOS)\n#include <stdio.h>\n#endif')
anchor='bool safeOutputLeaf(const QString &name)'
helper='''bool publishDirectory(const QString &source, const QString &destination)
{
    // Qt's preliminary exists check cannot make a directory rename exclusive
    // against an independent creator. Use the native no-replace operation.
#ifdef Q_OS_WIN
    const QString from = QDir::toNativeSeparators(source), to = QDir::toNativeSeparators(destination);
    return MoveFileW(reinterpret_cast<LPCWSTR>(from.utf16()), reinterpret_cast<LPCWSTR>(to.utf16())) != 0;
#elif defined(Q_OS_LINUX) && defined(SYS_renameat2)
    const QByteArray from = QFile::encodeName(source), to = QFile::encodeName(destination);
    constexpr unsigned int NoReplace = 1;
    return syscall(SYS_renameat2, AT_FDCWD, from.constData(), AT_FDCWD, to.constData(), NoReplace) == 0;
#elif defined(Q_OS_MACOS) && defined(RENAME_EXCL)
    const QByteArray from = QFile::encodeName(source), to = QFile::encodeName(destination);
    return renamex_np(from.constData(), to.constData(), RENAME_EXCL) == 0;
#else
    Q_UNUSED(source)
    Q_UNUSED(destination)
    return false; // Retain verified staging when exclusive publication is unavailable.
#endif
}
'''
assert anchor in s
s=s.replace(anchor,helper+anchor)
s=s.replace('directoryOutput ? QDir().rename(publish, target) : QFile::rename(publish, target)', 'directoryOutput ? publishDirectory(publish, target) : QFile::rename(publish, target)')
p.write_text(s,encoding='utf-8')
