from pathlib import Path
import os,subprocess,json
root=Path(r'C:\Users\USER\Documents\kdenlive');work=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-completion')
env=os.environ.copy();env['PATH']=r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\craftroot\bin'+os.pathsep+env.get('PATH','')
def run(args,**kw):return subprocess.run(['git','-c','core.longpaths=true',*args],cwd=root,env=env,check=True,**kw)
paths=subprocess.check_output(['git','diff','--cached','--name-only','-z','--diff-filter=ACMR','--','*.cpp','*.h','*.hpp','*.c'],cwd=root).decode().split('\0')
paths=[v for v in paths if v]
before={v:(root/v).read_bytes() for v in paths}
formatted=run(['clang-format','--staged','--extensions','cpp,h,hpp,c'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
for name,original in before.items():
 path=root/name
 if path.read_bytes()!=original: raise RuntimeError(f'Concurrent edit during format: {name}')
 data=subprocess.check_output(['git','show',':'+name],cwd=root)
 if data!=original:path.write_bytes(data)
notes=root/'dev-docs/mcp-progress.md'
text=notes.read_text(encoding='utf-8')
text=text.replace('The corrected native suite and final live ASS workflow have not been rerun.','The corrected native suite and final live ASS workflow have not been rerun. Repository-required C++ formatting was applied while saving this checkpoint; no additional feature checks were run after the pause request.')
notes.write_text(text,encoding='utf-8')
run(['add','--','dev-docs/mcp-progress.md'])
run(['diff','--cached','--check','--','.',':(exclude)packaging/patches/*.patch'])
run(['commit','--file',str(work/'github-main-commit-message.txt')])
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();(work/'github-main-sha.txt').write_text(sha+'\n',encoding='ascii')
print(json.dumps({'commit':sha,'formattedCppFilesConsidered':len(paths)}))
