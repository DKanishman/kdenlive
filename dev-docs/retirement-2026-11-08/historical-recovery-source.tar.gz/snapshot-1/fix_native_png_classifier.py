from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\src\mcp\mcplifecycle.cpp')
s=p.read_text(encoding='utf-8')
old='''    const bool sequence = consumer.attribute(key("f")) == key("image2");'''
new='''    // Installed MLT presets may leave f=image2 inside properties=stills/PNG.
    // Use the same native classifier as RenderRequest rather than requiring the
    // resolved format to appear explicitly in the generated consumer element.
    RenderPresetParams generatedParams;
    const auto attributes = consumer.attributes();
    for (int index = 0; index < attributes.size(); ++index) {
        const auto attribute = attributes.item(index).toAttr();
        generatedParams.insert(attribute.name(), attribute.value());
    }
    const bool sequence = generatedParams.isImageSequence();'''
assert old in s
s=s.replace(old,new)
p.write_text(s,encoding='utf-8')
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcplifecycle_cases.inc')
s=p.read_text(encoding='utf-8')
s=s.replace('#include <QDir>', '#include <QDir>\n#include <iostream>',1)
old='''            INFO(QJsonDocument(job).toJson(QJsonDocument::Compact).constData());
            return job;'''
new='''            if (status == QStringLiteral("failed"))
                std::cerr << "MCP export terminal job: " << QJsonDocument(job).toJson(QJsonDocument::Compact).constData() << '\\n';
            return job;'''
assert old in s
s=s.replace(old,new,1)
old='''    const auto completed = exportTerminal(project, exportStart(project, target, preset, {{QStringLiteral("outputName"), QStringLiteral("frame.png")}}));'''
new='''    const QString renderId = exportStart(project, target, preset, {{QStringLiteral("outputName"), QStringLiteral("frame.png")}});
    const auto prepared = project.success(QStringLiteral("render_status"), {{QStringLiteral("jobId"), renderId}}).value(QStringLiteral("job")).toObject();
    REQUIRE(prepared.value(QStringLiteral("outputs")).toArray().first().toObject().value(QStringLiteral("kind")).toString() == QStringLiteral("imageSequence"));
    const auto completed = exportTerminal(project, renderId);'''
assert old in s
s=s.replace(old,new,1)
old='''    CHECK(project.undoStack->index() == undoIndex);
    project.rejectWithoutChange(QStringLiteral("start_render"), exportArgs(project, target, preset));'''
new='''    CHECK(project.undoStack->index() == undoIndex);
    // Exercise both installed forms: properties=stills/PNG and an explicit
    // f=image2 profile. They must share the exact same native output contract.
    bool referencedPreset = false, explicitPreset = false;
    int variant = 0;
    for (const auto &name : RenderPresetRepository::get()->getAllPresets()) {
        const auto &candidate = RenderPresetRepository::get()->getPreset(name);
        if (!candidate || !candidate->isValid() || candidate->extension() != QStringLiteral("png") || !candidate->params().isImageSequence()) continue;
        const auto params = candidate->params();
        referencedPreset = referencedPreset || params.value(QStringLiteral("properties")).startsWith(QStringLiteral("stills/"));
        explicitPreset = explicitPreset || params.value(QStringLiteral("f")) == QStringLiteral("image2");
        if (name == preset) continue;
        const QString variantPath = directory.filePath(QStringLiteral("png-variant-%1").arg(variant++));
        const auto rendered = exportTerminal(project, exportStart(project, variantPath, name));
        REQUIRE(rendered.value(QStringLiteral("status")).toString() == QStringLiteral("completed"));
        const auto variantFiles = QDir(variantPath).entryList({QStringLiteral("*.png")}, QDir::Files, QDir::Name);
        REQUIRE(variantFiles.size() == 8);
        const QImage first(QDir(variantPath).filePath(variantFiles.first())), last(QDir(variantPath).filePath(variantFiles.last()));
        REQUIRE_FALSE(first.isNull());
        REQUIRE_FALSE(last.isNull());
        CHECK(QColor(first.pixel(first.width() / 2, first.height() / 2)).red() > 240);
        CHECK(QColor(last.pixel(last.width() / 2, last.height() / 2)).blue() > 240);
    }
    CHECK(referencedPreset);
    CHECK(explicitPreset);
    project.rejectWithoutChange(QStringLiteral("start_render"), exportArgs(project, target, preset));'''
assert old in s
s=s.replace(old,new,1)
p.write_text(s,encoding='utf-8')
print('Fixed referenced native image preset classification and persistent failure diagnostics')
