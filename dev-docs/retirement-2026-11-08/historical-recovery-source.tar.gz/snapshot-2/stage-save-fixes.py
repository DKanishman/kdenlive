from pathlib import Path
stage = Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\staging')
path = stage/'integration/src/doc/kdenlivedoc.cpp'
s = path.read_text(encoding='utf-8')
s = s.replace('#include <QSaveFile>', '#include <QSaveFile>\n#include <QTemporaryFile>', 1)
s = s.replace('if (errorMessage && (saveOverExistingFile || QFileInfo::exists(path)))', 'if (errorMessage && saveOverExistingFile)', 1)
needle = '    sceneList.clear();\n\n    // Backup current version'
assert s.count(needle) == 1
s = s.replace(needle, '''    sceneList.clear();

    if (errorMessage) {
        // Publish a new copy atomically without replacing a concurrently created file.
        QTemporaryFile file(QFileInfo(path).dir().absoluteFilePath(QStringLiteral(".kdenlive-new-XXXXXX")));
        if (!file.open()) {
            return reportError(i18n("Cannot write to file %1", path), file.errorString());
        }
        if (file.write(sceneData) != sceneData.size() || !file.flush()) {
            return reportError(i18n("Cannot write to file %1", path), file.errorString());
        }
        file.close();
        if (!file.rename(path)) {
            return reportError(i18n("Cannot write to file %1", path), file.errorString());
        }
        file.setAutoRemove(false);
        return true;
    }

    // Backup current version''', 1)
assert '#include <QTemporaryFile>' in s
path.write_text(s, encoding='utf-8', newline='\n')
path = stage/'mcpserver.cpp'
s = path.read_text(encoding='utf-8')
needle = '    const auto method = request.value(QStringLiteral("method"));\n'
assert s.count(needle) == 1
s = s.replace(needle, needle + '''    if (request.contains(QStringLiteral("id"))
        && ((!id.isString() && !id.isDouble() && !id.isNull()) || (id.isString() && id.toString().size() > 128))) {
        return rpcError(QJsonValue::Null, -32600, QStringLiteral("Request ID must be a scalar with at most 128 characters."));
    }
''', 1)
path.write_text(s, encoding='utf-8', newline='\n')
print('Staged atomic new-copy saving and bounded request IDs.')
