from pathlib import Path
p=Path(r'C:\Users\USER\Documents\kdenlive\tests\mcptest.cpp')
s=p.read_text(encoding='utf-8')
a=s.index('    void initialize()')
b=s.index('    QJsonObject call(', a)
s=s[:a]+'''    void initialize()
    {
        const QJsonObject params{
            {QStringLiteral("protocolVersion"), QStringLiteral("2025-06-18")},
            {QStringLiteral("capabilities"), QJsonObject{}},
            {QStringLiteral("clientInfo"), QJsonObject{{QStringLiteral("name"), QStringLiteral("native-test")},
                                                     {QStringLiteral("version"), QStringLiteral("1")}}}};
        const QJsonObject request{{QStringLiteral("jsonrpc"), QStringLiteral("2.0")},
                                  {QStringLiteral("id"), ++requestId},
                                  {QStringLiteral("method"), QStringLiteral("initialize")},
                                  {QStringLiteral("params"), params}};
        const QJsonObject reply = server.handleRequest(request);
        INFO(QJsonDocument(reply).toJson(QJsonDocument::Compact).constData());
        REQUIRE_FALSE(reply.contains(QStringLiteral("error")));
        REQUIRE(reply.value(QStringLiteral("result")).isObject());
        const QJsonObject notification{{QStringLiteral("jsonrpc"), QStringLiteral("2.0")},
                                        {QStringLiteral("method"), QStringLiteral("notifications/initialized")}};
        CHECK(server.handleRequest(notification).isEmpty());
    }

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\staging\mcptest.cpp').write_text(s,encoding='utf-8',newline='\n')
