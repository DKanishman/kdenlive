from pathlib import Path
stage=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\staging')
p=stage/'kdenlive-mcp.py'
s=p.read_text(encoding='utf-8')
old='def id_fits(value: object) -> bool:\n    return len(json.dumps(value, ensure_ascii=True, allow_nan=False).encode("ascii")) <= MAX_ID_BYTES'
new='''def id_fits(value: object) -> bool:
    if isinstance(value, str) and len(value.encode("utf-16-le", "surrogatepass")) > 256:
        return False  # Match the native endpoint's 128 UTF-16-character ID limit.
    return len(json.dumps(value, ensure_ascii=True, allow_nan=False).encode("ascii")) <= MAX_ID_BYTES'''
assert s.count(old)==1
p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')
p=stage/'mcptest.cpp'
s=p.read_text(encoding='utf-8')
assert 'MCP rejects unbounded request IDs' not in s
s+='''\nTEST_CASE("MCP rejects unbounded request IDs before dispatch", "[MCP]")
{
    McpProject project;
    project.open();
    const auto before = project.state();
    QJsonObject request{{QStringLiteral("jsonrpc"), QStringLiteral("2.0")},
                        {QStringLiteral("id"), QString(129, QLatin1Char('x'))},
                        {QStringLiteral("method"), QStringLiteral("tools/list")}};
    const auto response = project.server.handleRequest(request);
    CHECK(response.value(QStringLiteral("id")).isNull());
    REQUIRE(response.value(QStringLiteral("error")).isObject());
    CHECK(project.state() == before);
}
'''
p.write_text(s,encoding='utf-8',newline='\n')
print('Staged matching ID limits and native ingress regression test.')
