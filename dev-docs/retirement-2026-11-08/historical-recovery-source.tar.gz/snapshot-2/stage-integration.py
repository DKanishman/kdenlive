from pathlib import Path

source = Path(r'C:\Users\USER\Documents\kdenlive')
stage = Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\staging')

def transform(relative, edits):
    text = (source / relative).read_text(encoding='utf-8')
    for old, new in edits:
        if text.count(old) != 1:
            raise RuntimeError(f'{relative}: expected exactly one match: {old[:100]!r}')
        text = text.replace(old, new, 1)
    target = stage / 'integration' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding='utf-8', newline='\n')

transform('src/doc/kdenlivedoc.h', [(
    'bool saveSceneList(const QString &path, const QString &scene, bool saveOverExistingFile = true);',
    '// Supplying errorMessage selects noninteractive saving to a new path only.\n    bool saveSceneList(const QString &path, const QString &scene, bool saveOverExistingFile = true, QString *errorMessage = nullptr);'
)])
transform('src/doc/kdenlivedoc.cpp', [(
    'bool KdenliveDoc::saveSceneList(const QString &path, const QString &scene, bool saveOverExistingFile)\n{',
    '''bool KdenliveDoc::saveSceneList(const QString &path, const QString &scene, bool saveOverExistingFile, QString *errorMessage)
{
    if (errorMessage) errorMessage->clear();
    const auto reportError = [errorMessage](const QString &message, const QString &detail = QString()) {
        if (errorMessage) {
            *errorMessage = detail.isEmpty() ? message : message + QStringLiteral(": ") + detail;
        } else {
            KMessageBox::error(QApplication::activeWindow(), message);
        }
        return false;
    };
    // Automated copies must not enter interactive backup/overwrite paths.
    if (errorMessage && (saveOverExistingFile || QFileInfo::exists(path))) {
        return reportError(i18n("Automated saving requires a new project file."));
    }'''
), (
    'KMessageBox::error(QApplication::activeWindow(), i18n("Cannot write to file %1, scene list is corrupted.", path));\n        return false;',
    'return reportError(i18n("Cannot write to file %1, scene list is corrupted.", path));'
), (
    '''        KMessageBox::error(QApplication::activeWindow(), i18n("Cannot write to file %1", path));
        return false;
    }

    file.write(sceneData);
    if (!file.commit()) {
        KMessageBox::error(QApplication::activeWindow(), i18n("Cannot write to file %1", path));
        return false;
    }''',
    '''        return reportError(i18n("Cannot write to file %1", path), file.errorString());
    }

    if (file.write(sceneData) != sceneData.size()) {
        const QString detail = file.errorString();
        file.cancelWriting();
        return reportError(i18n("Cannot write to file %1", path), detail);
    }
    if (!file.commit()) {
        return reportError(i18n("Cannot write to file %1", path), file.errorString());
    }'''
)])
transform('src/project/projectmanager.h', [(
    'bool saveFileAs(const QString &outputFileName, bool saveOverExistingFile = true, bool saveACopy = false);',
    '// errorMessage requests noninteractive saving of a new copy; normal GUI calls leave it null.\n    bool saveFileAs(const QString &outputFileName, bool saveOverExistingFile = true, bool saveACopy = false, QString *errorMessage = nullptr);'
)])
transform('src/project/projectmanager.cpp', [(
    'bool ProjectManager::saveFileAs(const QString &outputFileName, bool saveOverExistingFile, bool saveACopy)\n{',
    '''bool ProjectManager::saveFileAs(const QString &outputFileName, bool saveOverExistingFile, bool saveACopy, QString *errorMessage)
{
    if (errorMessage) {
        errorMessage->clear();
        if (!saveACopy || saveOverExistingFile || QFileInfo::exists(outputFileName)) {
            *errorMessage = i18n("Automated saving requires a new project copy.");
            return false;
        }
    }'''
), (
    'm_project->saveSceneList(outputFileName, scene, saveOverExistingFile)',
    'm_project->saveSceneList(outputFileName, scene, saveOverExistingFile, errorMessage)'
)])
transform('src/main.cpp', [(
    '#include "core.h"', '#include "core.h"\n#include "mcp/mcpserver.h"'
), (
    '    // render options',
    '''    QCommandLineOption mcpSocketOption(QStringLiteral("mcp-socket"),
        i18n("Enable the experimental same-user MCP endpoint with an explicit socket name."), QStringLiteral("name"));
    parser.addOption(mcpSocketOption);

    // render options'''
), (
    '    aboutData.processCommandLine(&parser);',
    '''    aboutData.processCommandLine(&parser);
    if (parser.isSet(mcpSocketOption) && (parser.isSet(renderOption) || parser.isSet(verifyOption) || parser.isSet(saveDebugOption))) {
        qCritical() << "--mcp-socket requires the interactive editor.";
        return EXIT_FAILURE;
    }'''
), (
    '''        pCore->initGUI(parser.value(mltPathOption), app.url, clipsToLoad);
        result = app.exec();''',
    '''        pCore->initGUI(parser.value(mltPathOption), app.url, clipsToLoad);
        std::unique_ptr<KdenliveMcpServer> mcpServer;
        if (parser.isSet(mcpSocketOption)) {
            mcpServer = std::make_unique<KdenliveMcpServer>();
            QString error;
            if (!mcpServer->start(parser.value(mcpSocketOption), &error)) {
                qCritical() << "Cannot start MCP endpoint:" << error;
                mcpServer.reset();
                Core::clean();
                return EXIT_FAILURE;
            }
        }
        result = app.exec();'''
)])
transform('src/CMakeLists.txt', [(
    '    core.cpp\n', '    core.cpp\n    mcp/mcpserver.cpp\n    mcp/mcpserver.h\n'
), (
    '    Qt${QT_MAJOR_VERSION}::Core\n', '    Qt${QT_MAJOR_VERSION}::Core\n    Qt${QT_MAJOR_VERSION}::Network\n'
)])
transform('CMakeLists.txt', [('    Core Widgets', '    Core Widgets Network')])
transform('tests/CMakeLists.txt', [('    modeltest.cpp\n', '    modeltest.cpp\n    mcptest.cpp\n')])
print('Staged integration changes; source checkout untouched.')

