#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Kdenlive MCP prototype contributors
# SPDX-License-Identifier: GPL-3.0-or-later
"""Run an owned Windows GUI/stdin-MCP smoke test against a built Kdenlive.

No installation or client configuration is performed. Harness log/config files
live under a new run directory in --work-dir. The main settings and project cache
are task-specific; Qt can still write auxiliary data to real Windows known folders. The output directory must not contain
simple-project.kdenlive or, when rendering, simple-project.mp4. Run this with the
same development environment/PATH used to run the built editor.
"""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import uuid

MAX_FRAME = 1024 * 1024


class SmokeFailure(RuntimeError):
    pass


def require(condition: object, message: str) -> None:
    if not condition:
        raise SmokeFailure(message)


def hidden_options() -> dict:
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = subprocess.SW_HIDE
    return {"startupinfo": startup, "creationflags": subprocess.CREATE_NO_WINDOW}


class OwnedJob:
    """A kill-on-close Windows job containing only this harness's child trees."""
    def __init__(self) -> None:
        class Basic(ctypes.Structure):
            _fields_ = [("processTime", ctypes.c_longlong), ("jobTime", ctypes.c_longlong),
                        ("flags", wintypes.DWORD), ("minimum", ctypes.c_size_t),
                        ("maximum", ctypes.c_size_t), ("active", wintypes.DWORD),
                        ("affinity", ctypes.c_size_t), ("priority", wintypes.DWORD),
                        ("scheduling", wintypes.DWORD)]
        class Counters(ctypes.Structure):
            _fields_ = [(name, ctypes.c_ulonglong) for name in
                        ("reads", "writes", "other", "readBytes", "writeBytes", "otherBytes")]
        class Extended(ctypes.Structure):
            _fields_ = [("basic", Basic), ("io", Counters),
                        ("processMemory", ctypes.c_size_t), ("jobMemory", ctypes.c_size_t),
                        ("peakProcess", ctypes.c_size_t), ("peakJob", ctypes.c_size_t)]
        self.api = ctypes.WinDLL("kernel32", use_last_error=True)
        self.api.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        self.api.CreateJobObjectW.restype = wintypes.HANDLE
        self.api.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        self.api.SetInformationJobObject.restype = wintypes.BOOL
        self.api.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.api.OpenProcess.restype = wintypes.HANDLE
        self.api.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        self.api.AssignProcessToJobObject.restype = wintypes.BOOL
        self.api.CloseHandle.argtypes = [wintypes.HANDLE]
        self.api.CloseHandle.restype = wintypes.BOOL
        self.handle = self.api.CreateJobObjectW(None, None)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        info = Extended()
        info.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not self.api.SetInformationJobObject(self.handle, 9, ctypes.byref(info), ctypes.sizeof(info)):
            error = ctypes.WinError(ctypes.get_last_error())
            self.close()
            raise error

    def attach(self, process: subprocess.Popen) -> None:
        handle = self.api.OpenProcess(0x0101, False, process.pid)  # SET_QUOTA | TERMINATE
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            if not self.api.AssignProcessToJobObject(self.handle, handle):
                raise ctypes.WinError(ctypes.get_last_error())
        finally:
            self.api.CloseHandle(handle)

    def close(self) -> None:
        if self.handle:
            self.api.CloseHandle(self.handle)
            self.handle = None


def stop_owned(process: subprocess.Popen | None) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def wait_for_pipe(name: str, application: subprocess.Popen, timeout: float) -> None:
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    api.WaitNamedPipeW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD]
    api.WaitNamedPipeW.restype = wintypes.BOOL
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if application.poll() is not None:
            raise SmokeFailure(f"Kdenlive exited before MCP became ready: {application.returncode}")
        if api.WaitNamedPipeW("\\\\.\\pipe\\" + name, 100):
            return
        error = ctypes.get_last_error()
        if error not in (2, 121, 231):  # absent, timeout, busy
            raise ctypes.WinError(error)
        time.sleep(0.1)
    raise SmokeFailure("MCP socket did not become available; inspect the owned GUI log for a dialog/build error.")


class McpClient:
    def __init__(self, process: subprocess.Popen, timeout: float, receipts: list) -> None:
        self.process, self.timeout, self.receipts = process, timeout, receipts
        self.messages: queue.Queue = queue.Queue(maxsize=4)
        self.next_id = 0
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()

    def _read(self) -> None:
        try:
            while True:
                line = self.process.stdout.readline(MAX_FRAME + 2)
                self.messages.put(line)
                if not line:
                    return
        except Exception as error:
            self.messages.put(error)

    def notify(self, method: str) -> None:
        self._write({"jsonrpc": "2.0", "method": method})

    def _write(self, request: dict) -> None:
        self.receipts.append({"direction": "request", "message": request})
        line = json.dumps(request, separators=(",", ":"), allow_nan=False).encode("utf-8") + b"\n"
        require(len(line) <= MAX_FRAME + 1, "Smoke request exceeded its framing budget.")
        self.process.stdin.write(line)
        self.process.stdin.flush()

    def request(self, method: str, params: dict | None = None) -> dict:
        self.next_id += 1
        request = {"jsonrpc": "2.0", "id": self.next_id, "method": method}
        if params is not None:
            request["params"] = params
        self._write(request)  # Never replay after this point.
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                line = self.messages.get(timeout=max(0.001, deadline - time.monotonic()))
            except queue.Empty as error:
                raise SmokeFailure("MCP response timed out; the edit outcome is uncertain and was not retried.") from error
            if isinstance(line, Exception):
                raise SmokeFailure(f"MCP stdout read failed: {line}")
            require(line and line.endswith(b"\n") and len(line) <= MAX_FRAME + 1,
                    "MCP proxy disconnected or returned an oversized/incomplete frame; no request was retried.")
            reply = json.loads(line)
            self.receipts.append({"direction": "response", "message": reply})
            if "method" in reply and "id" not in reply:
                continue
            require(reply.get("jsonrpc") == "2.0" and reply.get("id") == self.next_id,
                    "Unexpected MCP response identity.")
            require("error" not in reply, f"MCP protocol/transport error: {reply.get('error')}")
            require(isinstance(reply.get("result"), dict), "MCP result was not an object.")
            return reply["result"]

    def tool(self, name: str, arguments: dict | None = None, *, error_code: str | None = None) -> dict:
        result = self.request("tools/call", {"name": name, "arguments": arguments or {}})
        content = result.get("structuredContent")
        require(isinstance(content, dict), f"{name} did not return structured content.")
        if error_code is not None:
            require(result.get("isError") is True and content.get("ok") is False,
                    f"{name} should have been rejected.")
            require(content.get("error", {}).get("code") == error_code,
                    f"{name} returned an unexpected rejection: {content}")
        else:
            require(not result.get("isError") and content.get("ok") is True,
                    f"{name} failed: {content}")
        return content


def clips(state: dict) -> dict[int, tuple[int, dict]]:
    return {clip["id"]: (track["id"], clip)
            for track in state["tracks"] for clip in track["clips"]}


def require_layout(state: dict, expected: list[tuple[int, int, int, int, int, int]]) -> None:
    actual = sorted((cid, tid, clip["startFrame"], clip["durationFrames"], clip["inFrame"], clip["outFrame"])
                    for cid, (tid, clip) in clips(state).items())
    require(actual == sorted(expected), f"Timeline mismatch: expected {expected}, observed {actual}")


def with_token(state: dict, **arguments) -> dict:
    require(isinstance(state.get("expectedState"), str) and state["expectedState"], "Missing expected-state token.")
    return {"expectedState": state["expectedState"], **arguments}


def seed_config(path: Path, renderer: Path, ffmpeg: Path | None) -> None:
    # These names/groups come from kdenlivesettings.kcfg/MainWindow::initializeOptions.
    # StoreInCustomFolder is 3 in definitions.h; ProjectManager::newFile uses this
    # explicit folder for the new document and its project cache.
    project_cache = path.parent / "project-cache"
    project_cache.mkdir()
    content = ("[version]\nversion=26.11.70\n\n[misc]\nopenlastproject=false\ncrashrecovery=false\n\n"
               "[project]\nvideotracks=2\naudiotracks=2\n\n[sdl]\nsdlAudioBackend=sdl2_audio\n\n"
               f"[env]\nkdenliverendererpath={renderer.as_posix()}\ndefaultprojectstoragetype=3\ndefaultprojectfolder={project_cache.as_posix()}\n")
    if ffmpeg is not None:
        content += f"ffmpegpath={ffmpeg.as_posix()}\n"
    content += "\n[unmanaged]\ndefault_profile=dv_pal\n"
    path.write_text(content, encoding="utf-8")


def run_logged(command: list[str], path: Path, env: dict, job: OwnedJob,
               timeout: float, *, capture: bool = False) -> bytes:
    with path.open("xb") as log:
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE if capture else log, stderr=log,
                                   env=env, **hidden_options())
        try:
            job.attach(process)
            output, _ = process.communicate(timeout=timeout)
            require(process.returncode == 0, f"Command failed ({process.returncode}); inspect {path}")
            return output or b""
        finally:
            stop_owned(process)


def inspect_render(args, video: Path, work: Path, env: dict, job: OwnedJob, fps: float) -> dict:
    raw = run_logged([str(args.ffprobe), "-v", "error", "-select_streams", "v:0", "-count_frames",
                      "-show_entries", "stream=width,height,avg_frame_rate,nb_frames,nb_read_frames,duration",
                      "-of", "json", str(video)], work / "ffprobe.log", env, job, 60, capture=True)
    probe = json.loads(raw)
    require(len(probe.get("streams", [])) == 1, "Rendered file has no unique video stream.")
    stream = probe["streams"][0]
    require(int(stream["nb_read_frames"]) == 175, f"Expected 175 rendered frames, observed {stream}")
    require(math.isclose(float(Fraction(stream["avg_frame_rate"])), fps, abs_tol=1e-6), "Rendered FPS differs from timeline.")
    samples = {}
    for frame, color in ((10, "red"), (50, "red"), (85, "black"), (120, "blue"), (170, "blue")):
        pixel = run_logged([str(args.ffmpeg), "-v", "error", "-i", str(video), "-map", "0:v:0",
                            "-vf", f"select=eq(n\\,{frame}),scale=1:1:flags=area", "-frames:v", "1",
                            "-an", "-sn", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"],
                           work / f"frame-{frame}.log", env, job, 60, capture=True)
        require(len(pixel) == 3, f"Frame {frame} was not decoded as one RGB pixel.")
        r, g, b = pixel
        okay = ((r > 180 and g < 60 and b < 60) if color == "red" else
                (b > 180 and r < 60 and g < 60) if color == "blue" else max(pixel) < 25)
        require(okay, f"Frame {frame} should be {color}; observed RGB {list(pixel)}")
        samples[str(frame)] = {"expected": color, "rgb": list(pixel)}
    return {"stream": stream, "samples": samples}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app", type=Path, required=True)
    parser.add_argument("--proxy", type=Path, required=True)
    parser.add_argument("--renderer", type=Path)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=45)
    parser.add_argument("--startup-timeout", type=float, default=90)
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--render-timeout", type=float, default=180)
    parser.add_argument("--ffmpeg", type=Path)
    parser.add_argument("--ffprobe", type=Path)
    args = parser.parse_args()
    if os.name != "nt":
        parser.error("This first GUI smoke harness currently supports Windows only.")
    for name in ("timeout", "startup_timeout", "render_timeout"):
        if not math.isfinite(getattr(args, name)) or getattr(args, name) <= 0:
            parser.error(f"--{name.replace('_', '-')} must be positive and finite")
    if args.timeout > 120:
        parser.error("--timeout cannot exceed the proxy's 120 second limit")
    args.app = args.app.resolve(strict=True)
    args.proxy = args.proxy.resolve(strict=True)
    args.renderer = (args.renderer or args.app.with_name("kdenlive_render.exe")).resolve(strict=True)
    if args.ffmpeg is not None:
        args.ffmpeg = args.ffmpeg.resolve(strict=True)
    elif args.app.with_name("ffmpeg.exe").is_file():
        args.ffmpeg = args.app.with_name("ffmpeg.exe")
    if args.ffprobe is not None:
        args.ffprobe = args.ffprobe.resolve(strict=True)
    if args.render and (args.ffmpeg is None or args.ffprobe is None):
        parser.error("--render requires --ffmpeg and --ffprobe")
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    project = output / "simple-project.kdenlive"
    video = output / "simple-project.mp4"
    require(not project.exists() and not project.is_symlink(), "The test project path already exists; choose a new output folder.")
    require(not args.render or (not video.exists() and not video.is_symlink()), "The render path already exists.")
    work = args.work_dir.resolve() / ("smoke-" + uuid.uuid4().hex[:12])
    work.mkdir(parents=True)
    config = work / "kdenlive-smoke.rc"
    seed_config(config, args.renderer, args.ffmpeg)
    env = os.environ.copy()
    env["PATH"] = str(args.app.parent) + os.pathsep + env.get("PATH", "")
    env["SDL_AUDIODRIVER"] = "dummy"
    env["QT_FORCE_STDERR_LOGGING"] = "1"  # Capture Qt diagnostics from the Windows GUI executable.
    # These overrides can help non-Qt child tools. On Windows, Qt uses
    # SHGetKnownFolderPath rather than these variables. Main settings are routed
    # by --config, and the project cache by the explicit custom-folder setting;
    # auxiliary Qt application data may still use the real known folders.
    for key, suffix in (("APPDATA", "appdata"), ("LOCALAPPDATA", "localappdata"),
                        ("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_DATA_HOME", "data")):
        location = work / suffix
        location.mkdir()
        env[key] = str(location)
    endpoint = "kdenlive-mcp-smoke-" + uuid.uuid4().hex
    receipts: list = []
    summary = {"status": "failed", "workDirectory": str(work), "settingsFile": str(config),
               "projectCacheDirectory": str(work / "project-cache"), "project": str(project),
               "socket": endpoint, "renderRequested": args.render}
    app = proxy = None
    job = OwnedJob()
    gui_log = proxy_log = None
    try:
        gui_log = (work / "gui.log").open("xb")
        app = subprocess.Popen([str(args.app), "--no-welcome", "--config", str(config), "--mcp-socket", endpoint],
                               stdin=subprocess.DEVNULL, stdout=gui_log, stderr=gui_log, env=env, **hidden_options())
        job.attach(app)
        wait_for_pipe(endpoint, app, args.startup_timeout)
        proxy_log = (work / "proxy.log").open("xb")
        proxy = subprocess.Popen([sys.executable, "-B", str(args.proxy), "--socket", endpoint,
                                  "--timeout", str(args.timeout)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=proxy_log, env=env, **hidden_options())
        job.attach(proxy)
        client = McpClient(proxy, args.timeout + 2, receipts)
        initialized = client.request("initialize", {"protocolVersion": "2025-11-25", "capabilities": {},
                                     "clientInfo": {"name": "kdenlive-native-smoke", "version": "0.1"}})
        require(initialized.get("protocolVersion") == "2025-11-25", "Unexpected negotiated protocol.")
        client.notify("notifications/initialized")
        names = {item["name"] for item in client.request("tools/list")["tools"]}
        require({"get_info", "get_state", "add_color_clip", "move_clip", "cut_clip", "undo", "redo", "save_project"} <= names,
                "Required native tools are missing.")
        info = client.tool("get_info")
        require(info.get("processId") == str(app.pid), "MCP attached to a different process.")
        deadline = time.monotonic() + args.startup_timeout
        while True:
            state = client.tool("get_state")["state"]
            if state.get("ready"):
                break
            require(time.monotonic() < deadline, f"GUI project did not become ready: {state}")
            time.sleep(0.1)  # Only a read is polled; edits are never retried.
        require(state.get("freshProjectEligible") and not clips(state), "Owned instance is not a fresh empty project.")
        track = next((item["id"] for item in state["tracks"] if not item["audio"] and not item["locked"]), None)
        require(track is not None, "No unlocked video track is available.")
        initial = state
        red = client.tool("add_color_clip", with_token(state, trackId=track, startFrame=0,
                            durationFrames=75, color="#ff0000ff", name="MCP red"))
        red_id, state = red["clipId"], red["state"]
        require_layout(state, [(red_id, track, 0, 75, 0, 74)])
        token_before_rejection = state["expectedState"]
        client.tool("move_clip", with_token(initial, clipId=red_id, trackId=track, startFrame=1), error_code="STALE_STATE")
        state = client.tool("get_state")["state"]
        require(state["expectedState"] == token_before_rejection, "Rejected stale request changed native state.")
        blue = client.tool("add_color_clip", with_token(state, trackId=track, startFrame=75,
                             durationFrames=75, color="#0000ffff", name="MCP blue"))
        blue_id, state = blue["clipId"], blue["state"]
        require_layout(state, [(red_id, track, 0, 75, 0, 74), (blue_id, track, 75, 75, 0, 74)])
        state = client.tool("move_clip", with_token(state, clipId=blue_id, trackId=track, startFrame=100))["state"]
        before_cut = [(red_id, track, 0, 75, 0, 74), (blue_id, track, 100, 75, 0, 74)]
        require_layout(state, before_cut)
        cut = client.tool("cut_clip", with_token(state, clipId=red_id, frame=30))
        state = cut["state"]
        after_cut = [(cut["leftClipId"], track, 0, 30, 0, 29),
                     (cut["rightClipId"], track, 30, 45, 30, 74), (blue_id, track, 100, 75, 0, 74)]
        require_layout(state, after_cut)
        state = client.tool("undo", with_token(state))["state"]
        require_layout(state, before_cut)
        state = client.tool("redo", with_token(state))["state"]
        require_layout(state, after_cut)
        require(state["durationFrames"] == 175, "Expected a 175-frame timeline.")
        saved = client.tool("save_project", with_token(state, path=str(project)))
        require(saved.get("persisted") and saved.get("saveAsCopy") and project.is_file() and project.stat().st_size > 0,
                "Native save did not produce a nonempty project copy.")
        require(Path(saved["path"]).resolve() == project.resolve(), "Native save returned a different output path.")
        require(saved["state"]["projectPath"] == initial["projectPath"], "Save copy changed the live project path.")
        before_hash = hashlib.sha256(project.read_bytes()).hexdigest()
        # Existing-output refusal is preflight validation, not a failed write retry.
        result = client.request("tools/call", {"name": "save_project", "arguments": with_token(saved["state"], path=str(project))})
        require(result.get("isError") is True, "Saving over an existing file was not rejected.")
        require(hashlib.sha256(project.read_bytes()).hexdigest() == before_hash, "Existing saved project changed after refusal.")
        summary.update({"nativeTools": sorted(names), "state": saved["state"], "projectSha256": before_hash,
                        "applicationProcessId": app.pid})
        proxy.stdin.close()
        proxy.wait(timeout=5)
        require(proxy.returncode == 0, "Proxy did not finish cleanly after stdio EOF.")
        stop_owned(app)
        verify_log = work / "verify.log"
        run_logged([str(args.app), "--config", str(config), "--verify-file", str(project)], verify_log, env, job, 90)
        require("SUCCESS: Project file is valid:" in verify_log.read_text(encoding="utf-8", errors="replace"),
                "Verification exited without its successful-consistency-check marker.")
        summary["nativeFileVerification"] = "passed"
        if args.render:
            run_logged([str(args.app), "--config", str(config), "--render", str(project), str(video)],
                       work / "render.log", env, job, args.render_timeout)
            require(video.is_file() and video.stat().st_size > 0, "Renderer did not create a video.")
            summary["render"] = inspect_render(args, video, work, env, job, float(state["fps"]))
            summary["video"] = str(video)
        summary["status"] = "passed"
        print(json.dumps({"status": "passed", "project": str(project), "report": str(work / "smoke-report.json"),
                          "video": str(video) if args.render else None}, ensure_ascii=True))
        return 0
    except Exception as error:
        summary["error"] = str(error)
        print(f"Smoke test failed: {error}\nDiagnostics: {work}", file=sys.stderr)
        return 1
    finally:
        stop_owned(proxy)
        stop_owned(app)
        job.close()  # Also terminates renderer descendants on a timeout/failure.
        if gui_log is not None:
            gui_log.close()
        if proxy_log is not None:
            proxy_log.close()
        (work / "mcp-receipts.json").write_text(json.dumps(receipts, indent=2, allow_nan=False), encoding="utf-8")
        (work / "smoke-report.json").write_text(json.dumps(summary, indent=2, allow_nan=False), encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
