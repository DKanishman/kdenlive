/*
    SPDX-FileCopyrightText: 2026 Kdenlive contributors
    SPDX-License-Identifier: GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
*/
#include "mcpserver.h"

#include "bin/model/subtitlemodel.hpp"
#include "bin/projectclip.h"
#include "bin/projectfolder.h"
#include "bin/projectitemmodel.h"
#include "config-kdenlive.h"
#include "core.h"
#include "doc/docundostack.hpp"
#include "doc/kdenlivedoc.h"
#include "effects/effectstack/model/effectstackmodel.hpp"
#include "project/projectmanager.h"
#include "timeline2/model/timelinefunctions.hpp"
#include "timeline2/model/timelineitemmodel.hpp"

#include <QApplication>
#include <QCryptographicHash>
#include <QDir>
#include <QDomDocument>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QLocalSocket>
#include <QRegularExpression>
#include <QScopedValueRollback>
#include <QThread>
#include <QUuid>
#include <algorithm>
#include <cmath>
#include <mlt++/MltProducer.h>

namespace {
constexpr qsizetype MaxRequestBytes = 1024 * 1024;
constexpr qsizetype MaxResponseBytes = 1024 * 1024;
constexpr int MaxFrame = 10000000;
constexpr int MaxDuration = 1000000;
constexpr int MaxItems = 512;

QJsonObject rpcError(const QJsonValue &id, int code, const QString &message)
{
    return {{QStringLiteral("jsonrpc"), QStringLiteral("2.0")},
            {QStringLiteral("id"), id},
            {QStringLiteral("error"), QJsonObject{{QStringLiteral("code"), code}, {QStringLiteral("message"), message}}}};
}
QJsonObject toolResult(const QJsonObject &data, bool error = false)
{
    return {
        {QStringLiteral("content"), QJsonArray{QJsonObject{{QStringLiteral("type"), QStringLiteral("text")},
                                                           {QStringLiteral("text"), QString::fromUtf8(QJsonDocument(data).toJson(QJsonDocument::Compact))}}}},
        {QStringLiteral("structuredContent"), data},
        {QStringLiteral("isError"), error}};
}
QJsonObject failure(const QString &code, const QString &message, const QJsonObject &state = {})
{
    QJsonObject data{{QStringLiteral("ok"), false},
                     {QStringLiteral("error"), QJsonObject{{QStringLiteral("code"), code}, {QStringLiteral("message"), message}}}};
    if (!state.isEmpty()) data.insert(QStringLiteral("state"), state);
    return toolResult(data, true);
}
QString digest(const QByteArray &bytes)
{
    return QString::fromLatin1(QCryptographicHash::hash(bytes, QCryptographicHash::Sha256).toHex());
}
QString effectsDigest(const std::shared_ptr<EffectStackModel> &stack)
{
    if (!stack) return QString();
    QDomDocument document;
    document.appendChild(stack->toXml(document));
    return digest(document.toByteArray(0));
}
bool integer(const QJsonObject &object, const QString &key, int minimum, int maximum, int &result)
{
    const auto value = object.value(key);
    if (!value.isDouble()) return false;
    const double number = value.toDouble();
    if (!std::isfinite(number) || std::floor(number) != number || number < minimum || number > maximum) return false;
    result = static_cast<int>(number);
    return true;
}
QJsonObject property(const QString &type, const QString &description)
{
    return {{QStringLiteral("type"), type}, {QStringLiteral("description"), description}};
}
QJsonArray toolCatalog()
{
    const auto text = [](const char *description) { return property(QStringLiteral("string"), QString::fromUtf8(description)); };
    const auto number = [](const char *description) {
        auto value = property(QStringLiteral("integer"), QString::fromUtf8(description));
        value.insert(QStringLiteral("minimum"), 0);
        value.insert(QStringLiteral("maximum"), MaxFrame);
        return value;
    };
    const auto expected = text("Exact state.expectedState from the latest result; bound to document, sequence and undo history.");
    QJsonArray tools;
    const auto add = [&tools](const char *name, const char *description, QJsonObject properties, QJsonArray required, bool readOnly) {
        tools.append(
            QJsonObject{{QStringLiteral("name"), QString::fromUtf8(name)},
                        {QStringLiteral("description"), QString::fromUtf8(description)},
                        {QStringLiteral("inputSchema"), QJsonObject{{QStringLiteral("type"), QStringLiteral("object")},
                                                                    {QStringLiteral("properties"), properties},
                                                                    {QStringLiteral("required"), required},
                                                                    {QStringLiteral("additionalProperties"), false}}},
                        {QStringLiteral("annotations"), QJsonObject{{QStringLiteral("readOnlyHint"), readOnly}, {QStringLiteral("openWorldHint"), false}}}});
    };
    add("get_info", "Describe the native prototype and its limits.", {}, {}, true);
    add("get_state", "Read the active sequence, all tracks, clip IDs and fresh expectedState.", {}, {}, true);
    add("add_color_clip", "Add a finite native color clip to an explicit unlocked video track; one undo step. Requires an initially empty unsaved project.",
        {{QStringLiteral("expectedState"), expected},
         {QStringLiteral("trackId"), number("Native video track ID.")},
         {QStringLiteral("startFrame"), number("Exact timeline start frame.")},
         {QStringLiteral("durationFrames"), number("Positive frame count; at most 1000000.")},
         {QStringLiteral("color"), text("RGBA in #RRGGBBAA format.")},
         {QStringLiteral("name"), text("Optional name, at most 160 characters.")}},
        {QStringLiteral("expectedState"), QStringLiteral("trackId"), QStringLiteral("startFrame"), QStringLiteral("durationFrames"), QStringLiteral("color")},
        false);
    add("move_clip", "Move one ungrouped, unmixed native color clip by ID. Does not overwrite other clips or use selection.",
        {{QStringLiteral("expectedState"), expected},
         {QStringLiteral("clipId"), number("Native timeline clip ID.")},
         {QStringLiteral("trackId"), number("Native destination video track ID.")},
         {QStringLiteral("startFrame"), number("Exact timeline start frame.")}},
        {QStringLiteral("expectedState"), QStringLiteral("clipId"), QStringLiteral("trackId"), QStringLiteral("startFrame")}, false);
    add("cut_clip", "Split one ungrouped native color clip strictly inside its duration; timeline selection must be empty.",
        {{QStringLiteral("expectedState"), expected},
         {QStringLiteral("clipId"), number("Native timeline clip ID.")},
         {QStringLiteral("frame"), number("Absolute timeline cut frame.")}},
        {QStringLiteral("expectedState"), QStringLiteral("clipId"), QStringLiteral("frame")}, false);
    add("undo", "Undo the current document's last command, including user commands. Returns fresh state.", {{QStringLiteral("expectedState"), expected}},
        {QStringLiteral("expectedState")}, false);
    add("redo", "Redo the current document's next command, including user commands. Returns fresh state.", {{QStringLiteral("expectedState"), expected}},
        {QStringLiteral("expectedState")}, false);
    add("save_project", "Save a native project copy to an absolute new local .kdenlive path. Does not replace the active document or overwrite a file.",
        {{QStringLiteral("expectedState"), expected}, {QStringLiteral("path"), text("Absolute destination file path; parent folder must exist.")}},
        {QStringLiteral("expectedState"), QStringLiteral("path")}, false);
    return tools;
}
} // namespace

KdenliveMcpServer::KdenliveMcpServer(QObject *parent)
    : QObject(parent)
    , m_server(this)
    , m_sessionId(QUuid::createUuid().toString(QUuid::WithoutBraces))
{
    m_server.setSocketOptions(QLocalServer::UserAccessOption);
    m_server.setMaxPendingConnections(1);
    connect(&m_server, &QLocalServer::newConnection, this, &KdenliveMcpServer::acceptClient);
}
KdenliveMcpServer::~KdenliveMcpServer()
{
    disconnect(m_undoConnection);
    if (m_client) m_client->abort();
    m_server.close();
}
bool KdenliveMcpServer::start(const QString &socketName, QString *error)
{
    QString reason;
#if !defined(Q_OS_WIN) && !defined(Q_OS_LINUX)
    reason = QStringLiteral("This prototype requires Windows or Linux socket user-access enforcement.");
#endif
    if (!qApp || QThread::currentThread() != qApp->thread()) reason = QStringLiteral("Start must run on the GUI thread.");
    if (!QRegularExpression(QStringLiteral("^[A-Za-z0-9][A-Za-z0-9_.-]{7,99}$")).match(socketName).hasMatch())
        reason = QStringLiteral("Use an explicit unique socket name, 8-100 letters, digits, dots, underscores or hyphens.");
    if (reason.isEmpty() && !m_server.listen(socketName)) reason = m_server.errorString();
    if (error) *error = reason;
    return reason.isEmpty();
}
void KdenliveMcpServer::acceptClient()
{
    while (auto *socket = m_server.nextPendingConnection()) {
        if (m_client) {
            socket->abort();
            socket->deleteLater();
            continue;
        }
        m_client = socket;
        m_initialized = false;
        m_input.clear();
        socket->setReadBufferSize(MaxRequestBytes + 1);
        connect(socket, &QLocalSocket::readyRead, this, &KdenliveMcpServer::readClient);
        connect(socket, &QLocalSocket::disconnected, this, [this, socket] {
            if (m_client == socket) {
                m_client.clear();
                m_input.clear();
                m_initialized = false;
            }
            socket->deleteLater();
        });
        if (socket->bytesAvailable()) readClient();
    }
}
void KdenliveMcpServer::readClient()
{
    if (!m_client || m_reading) return;
    QScopedValueRollback<bool> reading(m_reading, true);
    m_input += m_client->readAll();
    if (m_input.size() > MaxRequestBytes + 1) {
        m_client->abort();
        return;
    }
    int processed = 0;
    while (m_client && processed++ < 16) {
        const auto end = m_input.indexOf('\n');
        if (end < 0) {
            if (m_input.size() > MaxRequestBytes) {
                send(rpcError(QJsonValue::Null, -32600, QStringLiteral("Request exceeds 1 MiB.")));
                if (m_client) m_client->disconnectFromServer();
            }
            if (m_client && m_client->bytesAvailable()) QMetaObject::invokeMethod(this, &KdenliveMcpServer::readClient, Qt::QueuedConnection);
            return;
        }
        if (end > MaxRequestBytes) {
            m_client->abort();
            return;
        }
        QByteArray line = m_input.left(end).trimmed();
        m_input.remove(0, end + 1);
        QJsonParseError error;
        const auto document = QJsonDocument::fromJson(line, &error);
        if (error.error != QJsonParseError::NoError || !document.isObject()) {
            send(rpcError(QJsonValue::Null, -32700, QStringLiteral("Expected one JSON object per line.")));
        } else {
            const auto response = handleRequest(document.object());
            if (!response.isEmpty()) send(response);
        }
    }
    if (m_client && (m_input.contains('\n') || m_client->bytesAvailable()))
        QMetaObject::invokeMethod(this, &KdenliveMcpServer::readClient, Qt::QueuedConnection);
}
void KdenliveMcpServer::send(const QJsonObject &response)
{
    if (!m_client) return;
    auto bytes = QJsonDocument(response).toJson(QJsonDocument::Compact);
    if (bytes.size() > MaxResponseBytes)
        bytes = QJsonDocument(rpcError(response.value(QStringLiteral("id")), -32001, QStringLiteral("Response exceeds prototype limit.")))
                    .toJson(QJsonDocument::Compact);
    if (m_client->bytesToWrite() + bytes.size() > 2 * MaxResponseBytes) {
        m_client->abort();
        return;
    }
    bytes.append('\n');
    m_client->write(bytes);
}
QJsonObject KdenliveMcpServer::handleRequest(const QJsonObject &request)
{
    const auto id = request.value(QStringLiteral("id"));
    const auto method = request.value(QStringLiteral("method"));
    if (request.contains(QStringLiteral("id")) && ((!id.isString() && !id.isDouble() && !id.isNull()) || (id.isString() && id.toString().size() > 128))) {
        return rpcError(QJsonValue::Null, -32600, QStringLiteral("Request ID must be a scalar with at most 128 characters."));
    }
    if (request.value(QStringLiteral("jsonrpc")) != QJsonValue(QStringLiteral("2.0")) || !method.isString() ||
        (request.contains(QStringLiteral("id")) && !id.isString() && !id.isDouble() && !id.isNull()) ||
        (request.contains(QStringLiteral("params")) && !request.value(QStringLiteral("params")).isObject()))
        return rpcError(id.isUndefined() ? QJsonValue(QJsonValue::Null) : id, -32600, QStringLiteral("Invalid JSON-RPC request."));
    if (id.isUndefined()) return {}; // Notifications never execute editing commands.
    if (!qApp || QThread::currentThread() != qApp->thread()) return rpcError(id, -32000, QStringLiteral("GUI thread required."));
    if (m_dispatching) return rpcError(id, -32000, QStringLiteral("Another command is still running."));
    QScopedValueRollback<bool> dispatching(m_dispatching, true);
    const QString name = method.toString();
    const auto params = request.value(QStringLiteral("params")).toObject();
    QJsonObject result;
    if (name == QLatin1String("initialize")) {
        if (m_initialized) return rpcError(id, -32600, QStringLiteral("Already initialized."));
        const QString version = params.value(QStringLiteral("protocolVersion")).toString();
        const QString selected = version == QLatin1String("2025-11-25") ? version : QStringLiteral("2025-06-18");
        m_initialized = true;
        result = {
            {QStringLiteral("protocolVersion"), selected},
            {QStringLiteral("capabilities"), QJsonObject{{QStringLiteral("tools"), QJsonObject{{QStringLiteral("listChanged"), false}}}}},
            {QStringLiteral("serverInfo"),
             QJsonObject{{QStringLiteral("name"), QStringLiteral("kdenlive-native-mcp")}, {QStringLiteral("version"), QStringLiteral("0.1.0")}}},
            {QStringLiteral("instructions"),
             QStringLiteral("Native prototype: attach to a fresh unsaved project. Read get_state before each edit. "
                            "Use returned IDs and expectedState. Color clips only; saves create a copy. No project replacement, scripting or preview tools.")}};
    } else if (name == QLatin1String("ping")) {
        result = {};
    } else {
        if (!m_initialized) return rpcError(id, -32002, QStringLiteral("Initialize the MCP session first."));
        if (name == QLatin1String("tools/list")) {
            result = {{QStringLiteral("tools"), toolCatalog()}};
        } else if (name == QLatin1String("tools/call")) {
            if (!params.value(QStringLiteral("name")).isString() ||
                (params.contains(QStringLiteral("arguments")) && !params.value(QStringLiteral("arguments")).isObject()))
                return rpcError(id, -32602, QStringLiteral("Tool name and object arguments are required."));
            result = callTool(params.value(QStringLiteral("name")).toString(), params.value(QStringLiteral("arguments")).toObject());
        } else
            return rpcError(id, -32601, QStringLiteral("Unknown method."));
    }
    return {{QStringLiteral("jsonrpc"), QStringLiteral("2.0")}, {QStringLiteral("id"), id}, {QStringLiteral("result"), result}};
}
QJsonObject KdenliveMcpServer::snapshot()
{
    QJsonObject state{{QStringLiteral("ready"), false}, {QStringLiteral("sessionId"), m_sessionId}};
    if (!pCore || pCore->closing || !pCore->projectManager() || !pCore->currentDoc()) {
        state.insert(QStringLiteral("reason"), QStringLiteral("No active document."));
        return state;
    }
    auto *document = pCore->currentDoc();
    const auto timeline = pCore->projectManager()->getTimeline();
    const auto bin = pCore->projectItemModel();
    const auto stack = pCore->undoStack();
    if (!timeline || !bin || !stack || document->loading || document->closing || timeline->isClosed) {
        state.insert(QStringLiteral("reason"), QStringLiteral("Document is loading, closing or unavailable."));
        return state;
    }
    if (m_document != document || m_timeline.lock() != timeline) {
        disconnect(m_undoConnection);
        m_document = document;
        m_timeline = timeline;
        ++m_epoch;
        ++m_revision;
        m_undoConnection = connect(stack.get(), &QUndoStack::indexChanged, this, [this](int) { ++m_revision; });
        m_freshProject = document->url().isEmpty() && timeline->getClipsCount() == 0 && timeline->getCompositionsCount() == 0 && !timeline->hasSubtitles() &&
                         bin->getAllSequenceClips().size() <= 1;
        const auto sequences = bin->getAllSequenceClips().values();
        for (const auto &id : bin->getAllClipIds())
            if (!sequences.contains(id)) m_freshProject = false;
    }
    if (timeline->getClipsCount() + timeline->getCompositionsCount() > MaxItems || timeline->getTracksCount() > 64 || bin->getAllClipIds().size() > MaxItems) {
        state.insert(QStringLiteral("reason"), QStringLiteral("Project exceeds prototype state limits."));
        return state;
    }
    state.insert(QStringLiteral("ready"), true);
    state.insert(QStringLiteral("documentId"), document->uuid().toString(QUuid::WithoutBraces));
    state.insert(QStringLiteral("sequenceId"), timeline->uuid().toString(QUuid::WithoutBraces));
    state.insert(QStringLiteral("epoch"), QString::number(m_epoch));
    state.insert(QStringLiteral("revision"), QString::number(m_revision));
    state.insert(QStringLiteral("freshProjectEligible"), m_freshProject);
    state.insert(QStringLiteral("projectPath"), document->url().toLocalFile());
    state.insert(QStringLiteral("fps"), pCore->getCurrentFps());
    state.insert(QStringLiteral("width"), pCore->getCurrentFrameSize().width());
    state.insert(QStringLiteral("height"), pCore->getCurrentFrameSize().height());
    state.insert(QStringLiteral("durationFrames"), timeline->duration());
    state.insert(QStringLiteral("editMode"), static_cast<int>(timeline->editMode()));
    state.insert(QStringLiteral("singleSelectionMode"), timeline->singleSelectionMode());
    state.insert(QStringLiteral("undoIndex"), stack->index());
    state.insert(QStringLiteral("undoCount"), stack->count());
    state.insert(QStringLiteral("canUndo"), stack->canUndo());
    state.insert(QStringLiteral("canRedo"), stack->canRedo());
    state.insert(QStringLiteral("undoText"), stack->undoText());
    state.insert(QStringLiteral("redoText"), stack->redoText());
    QJsonArray selection;
    const auto selected = timeline->getCurrentSelection();
    std::vector<int> selectedIds(selected.begin(), selected.end());
    std::sort(selectedIds.begin(), selectedIds.end());
    for (int id : selectedIds)
        selection.append(id);
    state.insert(QStringLiteral("selection"), selection);
    state.insert(QStringLiteral("groups"), timeline->groupsData());
    state.insert(QStringLiteral("masterEffectsHash"), effectsDigest(timeline->getMasterEffectStackModel()));
    QJsonArray tracks;
    const auto allTracks = timeline->getAllTracksIds();
    std::vector<int> trackIds(allTracks.begin(), allTracks.end());
    std::sort(trackIds.begin(), trackIds.end(), [timeline](int a, int b) { return timeline->getTrackPosition(a) < timeline->getTrackPosition(b); });
    for (int id : trackIds) {
        QJsonObject track{{QStringLiteral("id"), id},
                          {QStringLiteral("position"), timeline->getTrackPosition(id)},
                          {QStringLiteral("name"), timeline->getTrackFullName(id)},
                          {QStringLiteral("audio"), timeline->isAudioTrack(id)},
                          {QStringLiteral("locked"), timeline->trackIsLocked(id)},
                          {QStringLiteral("effectsHash"), effectsDigest(timeline->getTrackEffectStackModel(id))}};
        QJsonArray clips, compositions;
        const auto allItems = timeline->getItemsInRange(id, 0, -1, true);
        std::vector<int> ids(allItems.begin(), allItems.end());
        std::sort(ids.begin(), ids.end());
        for (int cid : ids) {
            QJsonObject item{{QStringLiteral("id"), cid},
                             {QStringLiteral("startFrame"), timeline->getItemPosition(cid)},
                             {QStringLiteral("durationFrames"), timeline->getItemPlaytime(cid)}};
            if (timeline->isClip(cid)) {
                const auto inOut = timeline->getClipInOut(cid);
                item.insert(QStringLiteral("binId"), timeline->getClipBinId(cid));
                item.insert(QStringLiteral("name"), timeline->getClipName(cid));
                item.insert(QStringLiteral("inFrame"), inOut.first);
                item.insert(QStringLiteral("outFrame"), inOut.second);
                item.insert(QStringLiteral("grouped"), timeline->isInGroup(cid));
                item.insert(QStringLiteral("mixDuration"), timeline->getMixDuration(cid));
                item.insert(QStringLiteral("endMix"), timeline->hasClipEndMix(cid));
                item.insert(QStringLiteral("effectsHash"), effectsDigest(timeline->getClipEffectStackModel(cid)));
                clips.append(item);
            } else if (timeline->isComposition(cid))
                compositions.append(item);
        }
        track.insert(QStringLiteral("clips"), clips);
        track.insert(QStringLiteral("compositions"), compositions);
        tracks.append(track);
    }
    state.insert(QStringLiteral("tracks"), tracks);
    QJsonArray sources;
    auto binIds = bin->getAllClipIds();
    std::sort(binIds.begin(), binIds.end());
    for (const auto &id : binIds) {
        auto clip = bin->getClipByBinID(id);
        if (clip)
            sources.append(QJsonObject{{QStringLiteral("id"), id},
                                       {QStringLiteral("name"), clip->getData(AbstractProjectItem::DataName).toString()},
                                       {QStringLiteral("ready"), clip->statusReady()},
                                       {QStringLiteral("resource"), clip->getProducerProperty(QStringLiteral("resource"))},
                                       {QStringLiteral("durationFrames"), clip->getFramePlaytime()},
                                       {QStringLiteral("effectsHash"), effectsDigest(clip->getEffectStack())}});
    }
    state.insert(QStringLiteral("bin"), sources);
    if (timeline->hasSubtitleModel()) state.insert(QStringLiteral("subtitles"), timeline->getSubtitleModel()->toJson());
    state.insert(QStringLiteral("expectedState"), digest(QJsonDocument(state).toJson(QJsonDocument::Compact)));
    return state;
}
QJsonObject KdenliveMcpServer::callTool(const QString &name, const QJsonObject &arguments)
{
    QJsonObject schema;
    for (const auto &entry : toolCatalog()) {
        const auto tool = entry.toObject();
        if (tool.value(QStringLiteral("name")).toString() == name) {
            schema = tool.value(QStringLiteral("inputSchema")).toObject();
            break;
        }
    }
    if (schema.isEmpty()) return failure(QStringLiteral("UNKNOWN_TOOL"), QStringLiteral("Unknown tool."));
    const auto properties = schema.value(QStringLiteral("properties")).toObject();
    for (auto it = arguments.begin(); it != arguments.end(); ++it)
        if (!properties.contains(it.key())) return failure(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Unexpected argument: ") + it.key());
    for (const auto &entry : schema.value(QStringLiteral("required")).toArray())
        if (!arguments.contains(entry.toString())) return failure(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Missing argument: ") + entry.toString());
    if (name == QLatin1String("get_info"))
        return toolResult(
            {{QStringLiteral("ok"), true},
             {QStringLiteral("application"), QStringLiteral("Kdenlive")},
             {QStringLiteral("version"), QStringLiteral(KDENLIVE_VERSION)},
             {QStringLiteral("prototypeVersion"), QStringLiteral("0.1.0")},
             {QStringLiteral("sessionId"), m_sessionId},
             {QStringLiteral("processId"), QString::number(QCoreApplication::applicationPid())},
             {QStringLiteral("scope"),
              QStringLiteral("Fresh unsaved project; finite color clips; explicit IDs; shared undo; native save copies; no preview/project lifecycle.")}});
    auto state = snapshot();
    if (name == QLatin1String("get_state")) return toolResult({{QStringLiteral("ok"), true}, {QStringLiteral("state"), state}});
    if (!state.value(QStringLiteral("ready")).toBool()) return failure(QStringLiteral("NOT_READY"), state.value(QStringLiteral("reason")).toString(), state);
    const auto expected = arguments.value(QStringLiteral("expectedState"));
    if (!expected.isString() || expected.toString() != state.value(QStringLiteral("expectedState")).toString())
        return failure(QStringLiteral("STALE_STATE"), QStringLiteral("Read get_state again before editing."), state);
    if (!m_freshProject) return failure(QStringLiteral("PROJECT_SCOPE"), QStringLiteral("Start with an empty unsaved single-sequence project."), state);
    const auto timeline = m_timeline.lock();
    const auto bin = pCore->projectItemModel();
    auto stack = pCore->undoStack();
    if (QApplication::activeModalWidget() || QApplication::activePopupWidget() || QApplication::mouseButtons() != Qt::NoButton || !timeline->normalEdit() ||
        !timeline->getCurrentSelection().empty() || timeline->singleSelectionMode())
        return failure(QStringLiteral("UI_BUSY"), QStringLiteral("Close dialogs, finish dragging, use normal edit mode and clear timeline selection."), state);
    if (timeline->hasSubtitles() || timeline->getCompositionsCount() != 0)
        return failure(QStringLiteral("UNSUPPORTED_PROJECT"), QStringLiteral("Subtitles and compositions are outside this prototype."), state);
    QJsonObject data{{QStringLiteral("ok"), true}};
    if (name == QLatin1String("save_project")) {
        const auto requested = arguments.value(QStringLiteral("path"));
        if (!requested.isString() || requested.toString().size() > 2048)
            return failure(QStringLiteral("INVALID_PATH"), QStringLiteral("An absolute local .kdenlive path is required."), state);
        const QString path = QDir::fromNativeSeparators(requested.toString());
        const QFileInfo target(path);
        const QString leaf = target.fileName();
        const QString parent = target.absoluteDir().canonicalPath();
        if (!QDir::isAbsolutePath(path) || path.startsWith(QLatin1String("//")) || parent.isEmpty() ||
            target.suffix().compare(QLatin1String("kdenlive"), Qt::CaseInsensitive) != 0 || leaf.isEmpty() || leaf.size() > 200 ||
            leaf.contains(QLatin1Char(':')) || leaf.contains(QLatin1Char('"')) ||
            QRegularExpression(QStringLiteral("[<>|?*\\x00-\\x1f]")).match(leaf).hasMatch() || !QFileInfo(parent).isWritable() || target.exists() ||
            target.isSymLink())
            return failure(QStringLiteral("INVALID_PATH"), QStringLiteral("Use a new local .kdenlive file in an existing writable folder."), state);
        const QString actual = QDir(parent).absoluteFilePath(leaf);
        if (QFileInfo::exists(actual) || QFileInfo(actual).isSymLink())
            return failure(QStringLiteral("FILE_EXISTS"), QStringLiteral("The output file already exists."), state);
        if (!pCore->window()) return failure(QStringLiteral("GUI_REQUIRED"), QStringLiteral("Saving requires the running GUI."), state);
        QString error;
        const bool saved = pCore->projectManager()->saveFileAs(actual, false, true, &error);
        const QFileInfo persisted(actual);
        if (!saved || !persisted.isFile() || persisted.size() <= 0)
            return failure(QStringLiteral("SAVE_FAILED"), error.isEmpty() ? QStringLiteral("The project copy was not saved.") : error, snapshot());
        data.insert(QStringLiteral("path"), persisted.absoluteFilePath());
        data.insert(QStringLiteral("saveAsCopy"), true);
        data.insert(QStringLiteral("persisted"), true);
    } else if (name == QLatin1String("undo") || name == QLatin1String("redo")) {
        const bool undoing = name == QLatin1String("undo");
        if (undoing ? !stack->canUndo() : !stack->canRedo())
            return failure(QStringLiteral("NO_HISTORY"), QStringLiteral("No matching history command."), state);
        data.insert(QStringLiteral("command"), undoing ? stack->undoText() : stack->redoText());
        if (undoing)
            stack->undo();
        else
            stack->redo();
    } else {
        int tid = -1, cid = -1, frame = -1;
        if (name != QLatin1String("cut_clip")) {
            if (!integer(arguments, QStringLiteral("trackId"), 0, MaxFrame, tid) || !timeline->isTrack(tid))
                return failure(QStringLiteral("INVALID_TRACK"), QStringLiteral("Unknown trackId."), state);
            if (timeline->isAudioTrack(tid) || timeline->trackIsLocked(tid))
                return failure(QStringLiteral("INVALID_TRACK"), QStringLiteral("An unlocked video track is required."), state);
        }
        if (name != QLatin1String("add_color_clip")) {
            if (!integer(arguments, QStringLiteral("clipId"), 0, MaxFrame, cid) || !timeline->isClip(cid))
                return failure(QStringLiteral("INVALID_CLIP"), QStringLiteral("Unknown clipId."), state);
            const int sourceTrack = timeline->getClipTrackId(cid);
            if (sourceTrack < 0 || timeline->trackIsLocked(sourceTrack) || timeline->isInGroup(cid) || timeline->getMixDuration(cid) != 0 ||
                timeline->hasClipEndMix(cid) || timeline->getClipState(cid).second != ClipType::Color)
                return failure(QStringLiteral("UNSUPPORTED_CLIP"), QStringLiteral("Use an unlocked, ungrouped color clip without mixes."), state);
        }
        const QString frameKey = name == QLatin1String("cut_clip") ? QStringLiteral("frame") : QStringLiteral("startFrame");
        if (!integer(arguments, frameKey, 0, MaxFrame, frame))
            return failure(QStringLiteral("INVALID_FRAME"), QStringLiteral("A bounded non-negative integral frame is required."), state);
        int duration = name == QLatin1String("add_color_clip") ? 0 : timeline->getClipPlaytime(cid);
        QString color, clipName;
        if (name == QLatin1String("add_color_clip")) {
            color = arguments.value(QStringLiteral("color")).toString();
            clipName = arguments.contains(QStringLiteral("name")) ? arguments.value(QStringLiteral("name")).toString() : QStringLiteral("MCP color");
            if (!integer(arguments, QStringLiteral("durationFrames"), 1, MaxDuration, duration) ||
                !QRegularExpression(QStringLiteral("^#[0-9A-Fa-f]{8}$")).match(color).hasMatch() ||
                (arguments.contains(QStringLiteral("name")) && !arguments.value(QStringLiteral("name")).isString()) || clipName.isEmpty() ||
                clipName.size() > 160 || clipName.contains(QChar::Null))
                return failure(QStringLiteral("INVALID_ARGUMENT"), QStringLiteral("Use positive duration, #RRGGBBAA color and a 1-160 character name."), state);
            if (timeline->getClipsCount() >= MaxItems - 1 || bin->getAllClipIds().size() >= MaxItems - 1)
                return failure(QStringLiteral("LIMIT"), QStringLiteral("Prototype clip limit reached."), state);
        }
        if (name == QLatin1String("cut_clip")) {
            const int start = timeline->getClipPosition(cid);
            if (frame <= start || qint64(frame) >= qint64(start) + duration)
                return failure(QStringLiteral("CUT_BOUNDARY"), QStringLiteral("Cut strictly inside the clip."), state);
            if (timeline->getClipsCount() >= MaxItems - 1) return failure(QStringLiteral("LIMIT"), QStringLiteral("Prototype clip limit reached."), state);
        } else {
            if (qint64(frame) + duration > MaxFrame)
                return failure(QStringLiteral("INVALID_FRAME"), QStringLiteral("Clip end exceeds prototype frame limit."), state);
            for (int other : timeline->getItemsInRange(tid, 0, -1, true)) {
                if (other == cid) continue;
                const qint64 start = timeline->getItemPosition(other), end = start + timeline->getItemPlaytime(other);
                if (qint64(frame) < end && qint64(frame) + duration > start)
                    return failure(QStringLiteral("COLLISION"), QStringLiteral("Destination overlaps another item."), state);
            }
        }
        Fun undo = [] { return true; }, redo = [] { return true; };
        bool success = false;
        QString undoText;
        if (name == QLatin1String("add_color_clip")) {
            const QByteArray resource = (QStringLiteral("0x") + color.mid(1)).toLatin1();
            auto producer = std::make_shared<Mlt::Producer>(pCore->getProjectProfile(), "color", resource.constData());
            if (!producer->is_valid()) return failure(QStringLiteral("PRODUCER"), QStringLiteral("MLT could not create the color producer."), state);
            producer->set("length", duration);
            producer->set_in_and_out(0, duration - 1);
            producer->set("kdenlive:duration", duration);
            producer->set("kdenlive:clipname", clipName.toUtf8().constData());
            QString binId;
            if (bin->requestAddBinClip(binId, producer, bin->getRootFolder()->clipId(), undo, redo)) {
                bin->getClipByBinID(binId)->forceLimitedDuration();
                success = timeline->requestClipInsertion(QStringLiteral("V") + binId, tid, frame, cid, true, true, false, undo, redo, QVector<int>{tid}, 1);
                data.insert(QStringLiteral("binId"), binId);
            }
            undoText = QStringLiteral("MCP add color clip");
        } else if (name == QLatin1String("move_clip")) {
            success = timeline->requestClipMove(cid, tid, frame, false, true, true, true, undo, redo) == TimelineModel::MoveSuccess;
            undoText = QStringLiteral("MCP move clip");
        } else {
            success = TimelineFunctions::requestClipCut(timeline, cid, frame, undo, redo);
            // The high-level cut already rolls back its accumulated changes on failure.
            if (!success) return failure(QStringLiteral("EDIT_FAILED"), QStringLiteral("Kdenlive rejected the cut."), snapshot());
            const int rightId = timeline->getClipByPosition(timeline->getClipTrackId(cid), frame);
            success = rightId >= 0 && rightId != cid && timeline->getClipPosition(rightId) == frame &&
                      timeline->getClipPosition(cid) + timeline->getClipPlaytime(cid) == frame && timeline->getCurrentSelection().empty();
            data.insert(QStringLiteral("leftClipId"), cid);
            data.insert(QStringLiteral("rightClipId"), rightId);
            undoText = QStringLiteral("MCP cut clip");
        }
        if (success && name != QLatin1String("cut_clip"))
            success = timeline->isClip(cid) && timeline->getClipTrackId(cid) == tid && timeline->getClipPosition(cid) == frame &&
                      timeline->getClipPlaytime(cid) == duration;
        if (!success) {
            const bool restored = undo();
            return failure(restored ? QStringLiteral("EDIT_FAILED") : QStringLiteral("ROLLBACK_FAILED"),
                           restored ? QStringLiteral("Kdenlive rejected the edit; changes were rolled back.")
                                    : QStringLiteral("Rollback failed; inspect the project."),
                           snapshot());
        }
        pCore->pushUndo(undo, redo, undoText);
        data.insert(QStringLiteral("clipId"), cid);
    }
    ++m_revision;
    data.insert(QStringLiteral("state"), snapshot());
    return toolResult(data);
}
