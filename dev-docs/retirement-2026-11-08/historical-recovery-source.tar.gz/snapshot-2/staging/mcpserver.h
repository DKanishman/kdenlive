/*
    SPDX-FileCopyrightText: 2026 Kdenlive contributors
    SPDX-License-Identifier: GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
*/
#pragma once

#include <QJsonObject>
#include <QLocalServer>
#include <QPointer>
#include <memory>

class KdenliveDoc;
class QLocalSocket;
class TimelineItemModel;

/** Opt-in, same-user local MCP endpoint. All dispatch runs on the GUI thread.
 *  Construct after Core::initGUI and destroy before Core::clean.
 *  Version 1 edits an initially empty, unsaved single-sequence project.
 */
class KdenliveMcpServer : public QObject
{
    Q_OBJECT
public:
    explicit KdenliveMcpServer(QObject *parent = nullptr);
    ~KdenliveMcpServer() override;
    bool start(const QString &socketName, QString *error = nullptr);
    /** Exact transport dispatcher; an empty result means no notification reply. */
    QJsonObject handleRequest(const QJsonObject &request);

private:
    void acceptClient();
    void readClient();
    void send(const QJsonObject &response);
    QJsonObject snapshot();
    QJsonObject callTool(const QString &name, const QJsonObject &arguments);
    QLocalServer m_server;
    QPointer<QLocalSocket> m_client;
    QByteArray m_input;
    QPointer<KdenliveDoc> m_document;
    std::weak_ptr<TimelineItemModel> m_timeline;
    QMetaObject::Connection m_undoConnection;
    const QString m_sessionId;
    quint64 m_epoch{0};
    quint64 m_revision{0};
    bool m_freshProject{false};
    bool m_initialized{false};
    bool m_reading{false};
    bool m_dispatching{false};
};
