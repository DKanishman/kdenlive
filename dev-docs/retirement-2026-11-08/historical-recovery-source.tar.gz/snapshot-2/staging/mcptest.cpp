/*
    SPDX-FileCopyrightText: 2026 Kdenlive contributors
    SPDX-License-Identifier: GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
*/

#include "test_utils.hpp"

#include "mcp/mcpserver.h"

#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QStandardPaths>
#include <QTemporaryDir>

#include <limits>

namespace {

// This executable uses the shared runner; enable Qt's dedicated test paths before its main().
const bool isolatedQtPaths = [] {
    QStandardPaths::setTestModeEnabled(true);
    return true;
}();

class McpProject
{
public:
    McpProject()
        : undoStack(std::make_shared<DocUndoStack>(nullptr))
    {
    }

    void open()
    {
        pCore->projectItemModel()->clean();
        pCore->setCurrentProfile(QStringLiteral("dv_pal"));
        document = std::make_unique<KdenliveDoc>(undoStack);
        pCore->projectManager()->testSetDocument(document.get());
        REQUIRE(KdenliveTests::updateTimeline(false, QString(), QString(), QDateTime::currentDateTime(), false));
        timeline = document->getTimeline(document->uuid());
        REQUIRE(timeline);
        pCore->projectManager()->testSetActiveTimeline(timeline);
        document->loading = false;
        for (int position = 0; position < timeline->getTracksCount(); ++position) {
            const int id = timeline->getTrackIndexFromPosition(position);
            if (timeline->isAudioTrack(id)) {
                audioTrack = id;
            } else {
                videoTracks.push_back(id);
            }
        }
        REQUIRE(videoTracks.size() >= 2);
        REQUIRE(audioTrack >= 0);
        undoStack->clear();
        initialize();
    }

    ~McpProject()
    {
        // Headless ProjectManager does not own the dummy test document.
        if (document && pCore->projectManager()->current() == document.get()) {
            pCore->projectManager()->closeCurrentDocument(false, false);
        }
    }

    void initialize()
    {
        const QJsonObject params{{QStringLiteral("protocolVersion"), QStringLiteral("2025-06-18")},
                                 {QStringLiteral("capabilities"), QJsonObject{}},
                                 {QStringLiteral("clientInfo"),
                                  QJsonObject{{QStringLiteral("name"), QStringLiteral("native-test")}, {QStringLiteral("version"), QStringLiteral("1")}}}};
        const QJsonObject request{{QStringLiteral("jsonrpc"), QStringLiteral("2.0")},
                                  {QStringLiteral("id"), ++requestId},
                                  {QStringLiteral("method"), QStringLiteral("initialize")},
                                  {QStringLiteral("params"), params}};
        const QJsonObject reply = server.handleRequest(request);
        INFO(QJsonDocument(reply).toJson(QJsonDocument::Compact).constData());
        REQUIRE_FALSE(reply.contains(QStringLiteral("error")));
        REQUIRE(reply.value(QStringLiteral("result")).isObject());
        const QJsonObject notification{{QStringLiteral("jsonrpc"), QStringLiteral("2.0")},
                                       {QStringLiteral("method"), QStringLiteral("notifications/initialized")}};
        CHECK(server.handleRequest(notification).isEmpty());
    }

    QJsonObject call(const QString &name, const QJsonObject &arguments = {})
    {
        const QJsonObject reply = server.handleRequest(
            QJsonObject{{QStringLiteral("jsonrpc"), QStringLiteral("2.0")},
                        {QStringLiteral("id"), ++requestId},
                        {QStringLiteral("method"), QStringLiteral("tools/call")},
                        {QStringLiteral("params"), QJsonObject{{QStringLiteral("name"), name}, {QStringLiteral("arguments"), arguments}}}});
        INFO(QJsonDocument(reply).toJson(QJsonDocument::Compact).constData());
        REQUIRE_FALSE(reply.contains(QStringLiteral("error")));
        REQUIRE(reply.value(QStringLiteral("result")).isObject());
        return reply.value(QStringLiteral("result")).toObject();
    }

    QJsonObject success(const QString &name, const QJsonObject &arguments = {})
    {
        const QJsonObject result = call(name, arguments);
        INFO(QJsonDocument(result).toJson(QJsonDocument::Compact).constData());
        REQUIRE_FALSE(result.value(QStringLiteral("isError")).toBool());
        const QJsonObject content = result.value(QStringLiteral("structuredContent")).toObject();
        REQUIRE(content.value(QStringLiteral("ok")).toBool());
        return content;
    }

    QJsonObject state()
    {
        const QJsonObject result = success(QStringLiteral("get_state"));
        const QJsonObject current = result.value(QStringLiteral("state")).toObject();
        REQUIRE(current.value(QStringLiteral("ready")).toBool());
        REQUIRE_FALSE(current.value(QStringLiteral("expectedState")).toString().isEmpty());
        return current;
    }

    QString token() { return state().value(QStringLiteral("expectedState")).toString(); }

    QJsonObject expected() { return QJsonObject{{QStringLiteral("expectedState"), token()}}; }

    QJsonObject colorArgs(int trackId, int start, int duration)
    {
        QJsonObject args = expected();
        args.insert(QStringLiteral("trackId"), trackId);
        args.insert(QStringLiteral("startFrame"), start);
        args.insert(QStringLiteral("durationFrames"), duration);
        args.insert(QStringLiteral("color"), QStringLiteral("#ff0000ff"));
        args.insert(QStringLiteral("name"), QStringLiteral("MCP native test"));
        return args;
    }

    void rejectWithoutChange(const QString &name, const QJsonObject &arguments)
    {
        const QString beforeToken = token();
        const int beforeUndoIndex = undoStack->index();
        const int beforeUndoCount = undoStack->count();
        const int beforeClips = timeline->getClipsCount();
        const auto beforeBin = pCore->projectItemModel()->getAllClipIds();
        const QJsonObject result = call(name, arguments);
        INFO(QJsonDocument(result).toJson(QJsonDocument::Compact).constData());
        REQUIRE(result.value(QStringLiteral("isError")).toBool());
        const QJsonObject content = result.value(QStringLiteral("structuredContent")).toObject();
        REQUIRE_FALSE(content.value(QStringLiteral("ok")).toBool(true));
        REQUIRE(content.value(QStringLiteral("error")).isObject());
        CHECK(token() == beforeToken);
        CHECK(undoStack->index() == beforeUndoIndex);
        CHECK(undoStack->count() == beforeUndoCount);
        CHECK(timeline->getClipsCount() == beforeClips);
        CHECK(pCore->projectItemModel()->getAllClipIds() == beforeBin);
        REQUIRE(timeline->checkConsistency());
    }

    std::shared_ptr<DocUndoStack> undoStack;
    std::unique_ptr<KdenliveDoc> document;
    std::shared_ptr<TimelineItemModel> timeline;
    std::vector<int> videoTracks;
    int audioTrack{-1};
    KdenliveMcpServer server;

private:
    int requestId{0};
};

} // namespace

TEST_CASE("MCP edits use native clip operations and one undo step per edit", "[MCP]")
{
    McpProject project;
    project.open();
    const int video1 = project.videoTracks.at(0);
    const int video2 = project.videoTracks.at(1);
    const auto initialBinCount = pCore->projectItemModel()->getAllClipIds().size();

    const QJsonObject added = project.success(QStringLiteral("add_color_clip"), project.colorArgs(video1, 10, 40));
    REQUIRE(added.value(QStringLiteral("clipId")).isDouble());
    const int clipId = added.value(QStringLiteral("clipId")).toInt(-1);
    const QString binId = added.value(QStringLiteral("binId")).toString();
    REQUIRE(clipId >= 0);
    REQUIRE_FALSE(binId.isEmpty());
    REQUIRE(project.timeline->isClip(clipId));
    CHECK(project.timeline->getClipPosition(clipId) == 10);
    CHECK(project.timeline->getClipPlaytime(clipId) == 40);
    CHECK(project.timeline->getClipTrackId(clipId) == video1);
    CHECK(project.timeline->getClipInOut(clipId) == std::make_pair(0, 39));
    CHECK(project.undoStack->index() == 1);
    REQUIRE(project.timeline->checkConsistency());

    QJsonObject move = project.expected();
    move.insert(QStringLiteral("clipId"), clipId);
    move.insert(QStringLiteral("trackId"), video2);
    move.insert(QStringLiteral("startFrame"), 50);
    project.success(QStringLiteral("move_clip"), move);
    CHECK(project.timeline->getClipPosition(clipId) == 50);
    CHECK(project.timeline->getClipTrackId(clipId) == video2);
    CHECK(project.undoStack->index() == 2);

    QJsonObject cut = project.expected();
    cut.insert(QStringLiteral("clipId"), clipId);
    cut.insert(QStringLiteral("frame"), 65);
    const QJsonObject cutResult = project.success(QStringLiteral("cut_clip"), cut);
    const int left = cutResult.value(QStringLiteral("leftClipId")).toInt(-1);
    const int right = cutResult.value(QStringLiteral("rightClipId")).toInt(-1);
    REQUIRE(project.timeline->isClip(left));
    REQUIRE(project.timeline->isClip(right));
    CHECK(left != right);
    CHECK(project.timeline->getClipPosition(left) == 50);
    CHECK(project.timeline->getClipPlaytime(left) == 15);
    CHECK(project.timeline->getClipPosition(right) == 65);
    CHECK(project.timeline->getClipPlaytime(right) == 25);
    CHECK(project.undoStack->index() == 3);
    REQUIRE(project.timeline->checkConsistency());

    project.success(QStringLiteral("undo"), project.expected());
    CHECK(project.timeline->getClipsCount() == 1);
    CHECK(project.timeline->getClipPlaytime(clipId) == 40);
    project.success(QStringLiteral("undo"), project.expected());
    CHECK(project.timeline->getClipPosition(clipId) == 10);
    CHECK(project.timeline->getClipTrackId(clipId) == video1);
    project.success(QStringLiteral("undo"), project.expected());
    CHECK(project.timeline->getClipsCount() == 0);
    CHECK(pCore->projectItemModel()->getAllClipIds().size() == initialBinCount);
    CHECK(project.undoStack->index() == 0);
    REQUIRE(project.timeline->checkConsistency());

    for (int i = 0; i < 3; ++i) {
        project.success(QStringLiteral("redo"), project.expected());
        REQUIRE(project.timeline->checkConsistency());
    }
    CHECK(project.timeline->getClipsCount() == 2);
    CHECK(project.timeline->getClipPosition(left) == 50);
    CHECK(project.timeline->getClipPlaytime(left) == 15);
    CHECK(project.timeline->getClipPosition(right) == 65);
    CHECK(project.timeline->getClipPlaytime(right) == 25);
}

TEST_CASE("MCP state tokens reject manual edits and undo-history branches", "[MCP]")
{
    McpProject project;
    project.open();
    const int track = project.videoTracks.at(0);
    const int clipId = project.success(QStringLiteral("add_color_clip"), project.colorArgs(track, 0, 20)).value(QStringLiteral("clipId")).toInt(-1);
    REQUIRE(project.timeline->isClip(clipId));
    const QString beforeManual = project.token();
    const int originalIndex = project.undoStack->index();

    REQUIRE(project.timeline->requestClipMove(clipId, track, 40, true, true, true));
    CHECK(project.token() != beforeManual);
    project.rejectWithoutChange(QStringLiteral("undo"), QJsonObject{{QStringLiteral("expectedState"), beforeManual}});

    project.undoStack->undo();
    REQUIRE(project.timeline->getClipPosition(clipId) == 0);
    REQUIRE(project.undoStack->index() == originalIndex);
    // The image and undo index match the earlier state, but its token must still be stale.
    CHECK(project.token() != beforeManual);
    project.rejectWithoutChange(QStringLiteral("undo"), QJsonObject{{QStringLiteral("expectedState"), beforeManual}});

    REQUIRE(project.timeline->requestClipMove(clipId, track, 80, true, true, true));
    const QString priorBranch = project.token();
    const int branchIndex = project.undoStack->index();
    project.undoStack->undo();
    REQUIRE(project.timeline->requestClipMove(clipId, track, 100, true, true, true));
    REQUIRE(project.undoStack->index() == branchIndex);
    CHECK(project.token() != priorBranch);
    project.rejectWithoutChange(QStringLiteral("undo"), QJsonObject{{QStringLiteral("expectedState"), priorBranch}});
    REQUIRE(project.timeline->getClipPosition(clipId) == 100);
}

TEST_CASE("MCP rejects invalid and conflicting edits without changing native state", "[MCP]")
{
    McpProject project;
    project.open();
    const int track = project.videoTracks.at(0);

    SECTION("Malformed numeric fields, color, and unknown IDs")
    {
        QJsonObject args = project.colorArgs(track, 0, 20);
        args.insert(QStringLiteral("startFrame"), 0.5);
        project.rejectWithoutChange(QStringLiteral("add_color_clip"), args);
        args = project.colorArgs(track, 0, 20);
        args.insert(QStringLiteral("durationFrames"), 0);
        project.rejectWithoutChange(QStringLiteral("add_color_clip"), args);
        args = project.colorArgs(track, 0, 20);
        args.insert(QStringLiteral("startFrame"), static_cast<double>(std::numeric_limits<int>::max()) + 1.0);
        project.rejectWithoutChange(QStringLiteral("add_color_clip"), args);
        args = project.colorArgs(track, 0, 20);
        args.insert(QStringLiteral("color"), QStringLiteral("#gg0000ff"));
        project.rejectWithoutChange(QStringLiteral("add_color_clip"), args);
        args = project.colorArgs(std::numeric_limits<int>::max(), 0, 20);
        project.rejectWithoutChange(QStringLiteral("add_color_clip"), args);
    }

    SECTION("Color clips cannot be placed on audio or locked tracks")
    {
        project.rejectWithoutChange(QStringLiteral("add_color_clip"), project.colorArgs(project.audioTrack, 0, 20));
        project.timeline->setTrackProperty(track, QStringLiteral("kdenlive:locked_track"), QStringLiteral("1"));
        project.rejectWithoutChange(QStringLiteral("add_color_clip"), project.colorArgs(track, 0, 20));
    }

    SECTION("Overlap, missing clips, and cuts at clip boundaries fail")
    {
        const int clipId = project.success(QStringLiteral("add_color_clip"), project.colorArgs(track, 10, 30)).value(QStringLiteral("clipId")).toInt(-1);
        REQUIRE(project.timeline->isClip(clipId));
        project.rejectWithoutChange(QStringLiteral("add_color_clip"), project.colorArgs(track, 20, 10));
        const int second = project.success(QStringLiteral("add_color_clip"), project.colorArgs(track, 60, 20)).value(QStringLiteral("clipId")).toInt(-1);
        REQUIRE(project.timeline->isClip(second));
        QJsonObject move = project.expected();
        move.insert(QStringLiteral("clipId"), second);
        move.insert(QStringLiteral("trackId"), track);
        move.insert(QStringLiteral("startFrame"), 20);
        project.rejectWithoutChange(QStringLiteral("move_clip"), move);
        CHECK(project.timeline->getClipPosition(second) == 60);
        move = project.expected();
        move.insert(QStringLiteral("clipId"), std::numeric_limits<int>::max());
        move.insert(QStringLiteral("trackId"), track);
        move.insert(QStringLiteral("startFrame"), 100);
        project.rejectWithoutChange(QStringLiteral("move_clip"), move);

        for (int frame : {10, 40}) {
            QJsonObject cut = project.expected();
            cut.insert(QStringLiteral("clipId"), clipId);
            cut.insert(QStringLiteral("frame"), frame);
            project.rejectWithoutChange(QStringLiteral("cut_clip"), cut);
        }
        QJsonObject cut = project.expected();
        cut.insert(QStringLiteral("clipId"), clipId);
        cut.insert(QStringLiteral("frame"), 15.25);
        project.rejectWithoutChange(QStringLiteral("cut_clip"), cut);
        CHECK(project.timeline->getClipPosition(clipId) == 10);
        CHECK(project.timeline->getClipPlaytime(clipId) == 30);
    }
}

TEST_CASE("MCP automated save failures return errors without opening dialogs", "[MCP]")
{
    McpProject project;
    project.open();
    QTemporaryDir directory;
    REQUIRE(directory.isValid());
    QString message;
    CHECK_FALSE(project.document->saveSceneList(directory.filePath(QStringLiteral("corrupt.kdenlive")), QStringLiteral("invalid xml"), false, &message));
    CHECK_FALSE(message.isEmpty());
    const QString scene = QStringLiteral("<mlt><playlist id=\"main_bin\"/><tractor><track producer=\"main_bin\"/></tractor></mlt>");
    CHECK_FALSE(project.document->saveSceneList(directory.filePath(QStringLiteral("missing/output.kdenlive")), scene, false, &message));
    CHECK_FALSE(message.isEmpty());
    QFile existing(directory.filePath(QStringLiteral("existing.kdenlive")));
    REQUIRE(existing.open(QIODevice::WriteOnly));
    REQUIRE(existing.write("preserve", 8) == 8);
    existing.close();
    CHECK_FALSE(project.document->saveSceneList(existing.fileName(), scene, false, &message));
    CHECK_FALSE(message.isEmpty());
    REQUIRE(existing.open(QIODevice::ReadOnly));
    CHECK(existing.readAll() == QByteArray("preserve"));
}

TEST_CASE("MCP rejects unbounded request IDs before dispatch", "[MCP]")
{
    McpProject project;
    project.open();
    const auto before = project.state();
    QJsonObject request{{QStringLiteral("jsonrpc"), QStringLiteral("2.0")},
                        {QStringLiteral("id"), QString(129, QLatin1Char('x'))},
                        {QStringLiteral("method"), QStringLiteral("tools/list")}};
    const auto response = project.server.handleRequest(request);
    CHECK(response.value(QStringLiteral("id")).isNull());
    REQUIRE(response.value(QStringLiteral("error")).isObject());
    CHECK(project.state() == before);
}
