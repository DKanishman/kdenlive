# Experimental native MCP control

This prototype adds an opt-in local MCP endpoint to the actual Kdenlive GUI. It
uses Kdenlive's timeline/bin models and native undo history. It does not automate
mouse or keyboard events and does not maintain a second editing model.

The first version supports a fresh, empty, unsaved single-sequence project and
finite generated color clips. State can be inspected on other projects, subject
to prototype size limits, but mutations require a project that was empty when the
service first inspected it. Media import, effect editing, rendered preview,
project opening/replacement, application closing and arbitrary scripting are not
exposed.

## Start a local session

Build and install Kdenlive and its ordinary runtime data/dependencies first. Use
the same development environment/PATH that runs that build normally. The service
is disabled unless `--mcp-socket` is supplied:

```powershell
& 'C:/path/to/build/bin/kdenlive.exe' --no-welcome --mcp-socket kdenlive-mcp-local
```

Use a new empty project, normal editing mode and no selected timeline items.
The socket name must contain 8-100 ASCII letters, digits, dots, underscores or
hyphens and start with a letter or digit. Choose a unique name for each instance;
the service does not remove another instance's endpoint.

Point an MCP client's stdio-server configuration at an explicit Python 3.10+
interpreter and the connector script. The connector needs only the standard
library:

```powershell
& 'C:/path/to/python.exe' -B 'C:/path/to/source/src/mcp/kdenlive-mcp.py' --socket kdenlive-mcp-local --timeout 30
```

The Windows connector uses a local named pipe. The Linux connector accepts the
actual absolute AF_UNIX path of the Qt local endpoint. The endpoint enforces
same-user access on Windows/Linux and accepts one client at a time. It does not
listen on a TCP port. Other platforms are rejected by this initial native
service. A socket name is an address, not a secret or a replacement for same-user
access enforcement.

## Protocol and tools

The native service implements MCP `initialize`, `ping`, `tools/list` and
`tools/call`, with protocol revisions `2025-06-18` and `2025-11-25`. Messages are
one UTF-8 JSON-RPC object per line, bounded to 1 MiB in each direction. JSON-RPC
batches are unsupported. String request IDs are limited to 128 UTF-16 code units. Editing commands are never executed as notifications.

| Tool | Arguments and result |
| --- | --- |
| `get_info` | No arguments. Reports build/prototype versions, process/session identity and scope. |
| `get_state` | No arguments. Reports active sequence, all tracks including locked tracks, clip IDs/source ranges, history and `expectedState`. |
| `add_color_clip` | `expectedState`, `trackId`, `startFrame`, `durationFrames`, `color`, optional `name`. Color is `#RRGGBBAA`. Returns `clipId`, `binId` and resulting state. |
| `move_clip` | `expectedState`, `clipId`, `trackId`, `startFrame`. Returns the exact applied state. |
| `cut_clip` | `expectedState`, `clipId`, `frame`. Cuts strictly inside a clip and returns `leftClipId`, `rightClipId` and state. |
| `undo` | `expectedState`. Undoes the actual document's previous command and reports the command and state. |
| `redo` | `expectedState`. Redoes the actual document's next command and reports the command and state. |
| `save_project` | `expectedState`, `path`. Saves a new native `.kdenlive` copy and returns its actual path, persistence status and state. |

Tool results contain MCP text content and `structuredContent`. Successful
results have `ok: true`; state-bearing results use `state.expectedState`. Tool
failures have `isError: true`, `ok: false` and `error: {code, message}`. Protocol
errors use JSON-RPC errors instead. Reported success is not a substitute for
checking the applied state and resulting saved/rendered artifacts.

All times are integral project frames. A clip occupies `[startFrame,
startFrame + durationFrames)` on the timeline; the returned source `inFrame` and
`outFrame` are inclusive. For example, a 75-frame color clip starting at frame 0
occupies frames 0-74, and a cut at frame 30 creates 30- and 45-frame fragments.

## Editing and recovery contract

Read `get_state`, use its object IDs and pass its exact `expectedState` to each
mutation. Successful edits return the next state/token. Tokens bind the service
session, document/sequence, undo revision and a digest of relevant native state.
A manual edit, undo or incompatible target invalidates stale assumptions. After
`STALE_STATE`, inspect the current state and decide a new edit; do not blindly
replay an old one.

The prototype rejects non-normal editing mode, selected timeline items, active
modal/popup dialogs, mouse dragging, audio/locked destination tracks, overlapping
destinations, grouped clips, mixed clips and unsupported clip types. There are
also bounds on project size, frame values and names. These restrictions make
initial native behavior explicit rather than depending on UI selection or track
targets.

Color creation and timeline insertion share one native undo step. Moves and cuts
also use native undo composition. Undo/redo act on the shared document history,
including commands made manually by the user. Stop issuing commands while the
user is interacting with the timeline. This version has no asynchronous editing
jobs, progress/cancellation tools or unrestricted simultaneous human/AI editing.

`save_project` requires a new absolute local `.kdenlive` path with an existing
writable parent. It refuses existing outputs and saves a copy; it does not rename
the live document. Automated new-copy write failures are returned as errors
instead of opening a save error dialog. Normal interactive save calls retain
their existing error-dialog behavior.

The connector processes requests sequentially. A deadline or disconnection after
sending may mean an edit was applied even if no response arrived. It reports an
uncertain outcome and exits without reconnecting or replaying. Reconnect
explicitly, read state, and reconcile the project before any further edit. Idle
native notifications and cancellation overtaking an active synchronous call are
outside this connector's initial scope.

## Verification

The native regression target uses the same request dispatcher as the socket:

```text
cmake --build <build-directory> --target kdenlive mcptest
ctest --test-dir <build-directory> -R ^mcptest$ --output-on-failure --no-tests=error
python -B tests/test_kdenlive_mcp_proxy.py -q
```

Native tests cover generated clips, exact move/cut ranges, native undo/redo,
stale-state rejection, locked/audio/conflicting destinations and automated-save
failure reporting. Connector tests exercise framing, deadlines, disconnections,
malformed messages and the Windows named-pipe transport. Test execution still
requires the corresponding runtime/development dependencies; consult actual test
logs rather than treating the presence of these tests as a passing result.

The task's optional `live_smoke.py` helper launches only its own hidden GUI
instance with a task-specific main settings file and custom project-cache folder,
drives the real stdio connector, edits a 175-frame red/gap/blue sequence, saves a
project copy, and invokes Kdenlive's
`--verify-file` consistency check. With `--render`, `--ffmpeg` and `--ffprobe`, it
also renders the copy, checks frame count/rate and samples red, black and blue
frames. It records protocol receipts and a result report in a fresh work
subdirectory. It does not install tools or register a client. The helper is a
task-work asset, not part of the installed application's public API. On Windows,
Qt obtains standard locations through `SHGetKnownFolderPath`; changing
`APPDATA`, `LOCALAPPDATA` or `XDG_*` in the child environment does not redirect
those Qt locations. The explicit config and project-cache settings scope the
test's main settings/cache, while auxiliary Qt application data may still be
written to real user locations.
