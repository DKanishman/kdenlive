$ErrorActionPreference = 'Stop'
$sourceRoot = 'C:\Users\USER\Documents\kdenlive'
$taskWork = 'C:\Users\USER\.codex\work\kdenlive-mcp-prototype'
$stageRoot = Join-Path $taskWork 'staging'
$head = (& git -C $sourceRoot rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $head -ne '3d7c862085c81c083aa3e8b5ed6ee0c9d62505a4') { throw 'Source revision changed; review before applying.' }
$changes = & git -C $sourceRoot status --porcelain
if ($LASTEXITCODE -ne 0 -or $changes) { throw 'Source contains existing changes; preserve and review them before applying.' }
$copies = @()
$integrationRoot = Join-Path $stageRoot 'integration'
Get-ChildItem -LiteralPath $integrationRoot -File -Recurse | ForEach-Object {
    $relative = [IO.Path]::GetRelativePath($integrationRoot, $_.FullName)
    $copies += [pscustomobject]@{ Source = $_.FullName; Destination = (Join-Path $sourceRoot $relative) }
}
$newFiles = @{
    'mcpserver.h' = 'src\mcp\mcpserver.h'
    'mcpserver.cpp' = 'src\mcp\mcpserver.cpp'
    'kdenlive-mcp.py' = 'src\mcp\kdenlive-mcp.py'
    'mcptest.cpp' = 'tests\mcptest.cpp'
    'test_kdenlive_mcp_proxy.py' = 'tests\test_kdenlive_mcp_proxy.py'
    'mcp.md' = 'dev-docs\mcp.md'
}
foreach ($entry in $newFiles.GetEnumerator()) {
    $destination = Join-Path $sourceRoot $entry.Value
    if (Test-Path -LiteralPath $destination) { throw "New prototype path already exists: $destination" }
    $copies += [pscustomobject]@{ Source = (Join-Path $stageRoot $entry.Key); Destination = $destination }
}
foreach ($copy in $copies) {
    if (-not (Test-Path -LiteralPath $copy.Source -PathType Leaf)) { throw "Missing staged file: $($copy.Source)" }
    $absoluteDestination = [IO.Path]::GetFullPath($copy.Destination)
    if (-not $absoluteDestination.StartsWith($sourceRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Destination escaped source checkout.' }
}
$branchName = 'codex/mcp-prototype'
& git -C $sourceRoot show-ref --verify --quiet ('refs/heads/' + $branchName)
if ($LASTEXITCODE -eq 0) { throw 'Prototype branch already exists; review before reusing.' }
& git -C $sourceRoot switch -c $branchName
if ($LASTEXITCODE -ne 0) { throw 'Could not create prototype branch.' }
foreach ($copy in $copies) {
    New-Item -ItemType Directory -Path (Split-Path -Parent $copy.Destination) -Force | Out-Null
    Copy-Item -LiteralPath $copy.Source -Destination $copy.Destination
}
$copies | ForEach-Object { [pscustomobject]@{ Path = $_.Destination; SHA256 = (Get-FileHash -LiteralPath $_.Destination -Algorithm SHA256).Hash } } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskWork 'applied-files.json') -Encoding utf8
& git -C $sourceRoot diff --check
if ($LASTEXITCODE -ne 0) { throw 'Prototype diff has whitespace errors.' }
& git -C $sourceRoot status --short
