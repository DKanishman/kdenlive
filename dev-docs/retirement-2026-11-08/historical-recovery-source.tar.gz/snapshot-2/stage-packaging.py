from pathlib import Path
stage=Path(r'C:\Users\USER\.codex\work\kdenlive-mcp-prototype\staging')
p=stage/'integration/src/CMakeLists.txt'
s=p.read_text(encoding='utf-8')
needle='install(TARGETS kdenlive DESTINATION ${KDE_INSTALL_BINDIR})'
assert s.count(needle)==1
s=s.replace(needle,needle+'\ninstall(PROGRAMS mcp/kdenlive-mcp.py DESTINATION ${KDE_INSTALL_BINDIR})')
p.write_text(s,encoding='utf-8',newline='\n')
p=stage/'test_kdenlive_mcp_proxy.py'
s=p.read_text(encoding='utf-8')
old='SPEC = importlib.util.spec_from_file_location(\n    "kdenlive_mcp_proxy", Path(__file__).with_name("kdenlive-mcp.py"))'
new='''PROXY_PATH = Path(__file__).resolve().parents[1] / "src" / "mcp" / "kdenlive-mcp.py"
if not PROXY_PATH.is_file():
    PROXY_PATH = Path(__file__).with_name("kdenlive-mcp.py")  # Task staging.
SPEC = importlib.util.spec_from_file_location("kdenlive_mcp_proxy", PROXY_PATH)'''
assert s.count(old)==1
p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')
p=stage/'mcp.md'
s=p.read_text(encoding='utf-8')
s=s.replace('batches are unsupported. Editing commands', 'batches are unsupported. String request IDs are limited to 128 UTF-16 code units. Editing commands')
s=s.replace('ctest --test-dir <build-directory> -R ^mcptest$ --output-on-failure --no-tests=error', 'ctest --test-dir <build-directory> -R ^mcptest$ --output-on-failure --no-tests=error\npython -B tests/test_kdenlive_mcp_proxy.py -q')
p.write_text(s,encoding='utf-8',newline='\n')
print('Staged connector installation, portable test import and protocol documentation.')
