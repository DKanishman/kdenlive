# Linux agent access and project recovery plan

Prepared 2026-11-07. This is a plan, not an applied permission change.

The user wants to continue in this ChatGPT conversation. The primary workflow
below keeps coding, review and project decisions here. A separate Codex CLI task
is optional reference material only and is not a required migration.

## What has actually been established

| Layer | Current evidence | Action |
| --- | --- | --- |
| Build tools | GCC 16.2.1, CMake 4.3.0, Ninja and development libraries are installed. | Use the installed toolchain. |
| Qt/KDE | The real CMake configure found Qt 6.11.2 and KF 6.31.0. | No additional Qt/KDE upgrade is indicated by that check. |
| MLT | Fedora supplied 7.40.0; this fork requires at least 7.42.0 and its patches target a pinned 7.43.0 revision. | Build the matching patched dependency in the project prefix. |
| Agent command access | The active local runner reports a restricted filesystem and restricted network policy. Git cannot resolve github.com. | Verify Work-specific controls; do not substitute Codex CLI settings. |
| Local sockets | A real AF_UNIX bind/connection in the current runner returns EPERM. | Unresolved task restriction. Public internet access does not establish local IPC access. |
| SELinux | `getenforce` inside the runner reports `Disabled`; host status was not independently verified outside its namespace. | There is no audit evidence here that calls for a SELinux change. |
| Existing application | Stock Kdenlive is a Fedora Flatpak. | Use the custom installed binary for native MCP; stock Kdenlive does not acquire the fork's changes. |
| Available client | The ChatGPT RPM includes `/usr/lib/chatgpt/resources/codex`, version `0.166.0-alpha.6`. Its help confirms the flags below. | Optional Codex-only reference; not a way to change this Work chat. |

An error inside the agent is not automatically a Fedora host error. Compare the
same check in your ordinary terminal and in the agent before changing system
network, file ownership or security configuration. Browser/search/connector
success does not prove that shell commands have equivalent access.

## 1. Establish an ordinary-terminal baseline

In your normal Fedora terminal:

```bash
cd /home/USER/code/kdenlive
git ls-remote https://github.com/mltframework/mlt.git HEAD
python3 -B dev-tools/mcp-linux.py doctor
```

- `cd` selects the existing project directory.
- `git ls-remote` reads repository references over HTTPS. The URL selects MLT's
  official repository and `HEAD` requests its default revision. This neither
  clones the repository nor executes its code. Success prints a commit hash.
- `python3` runs Python; `-B` prevents bytecode cache files. The helper's `doctor`
  command checks executable availability and creates/removes a temporary Unix
  socket. Its `unixSocketBind.ok` should be `true`. Its build-readiness flag is a
  preliminary check, not proof that every dependency version or native test passes.

If those pass in your terminal but fail in the agent, investigate the agent
permission boundary first. If the ordinary-terminal network check also fails,
investigate the host connection/DNS separately. If binding fails in both places,
inspect the concrete host error and directory permissions before changing policy.

## 2. Verified Work controls and current limitations

The user's screenshot confirms that the proposed permissions selector is absent
beneath this Work conversation's composer. Do not ask the user to find it again.
The earlier instructions wrongly treated a documented conditional Codex/desktop
control as an available control in this interface.

OpenAI's Developer settings documentation explicitly states that ChatGPT Work
chats run in a managed environment and do not read local Codex configuration
files. Changes to `~/.codex/config.toml`, Codex permission profiles or CLI flags
are therefore not a verified way to reconfigure this Work conversation.

OpenAI's Work overview and sandbox documentation describe **Settings > Data
controls > Work network access > Allow public internet access** only when that
setting is available. Its availability in this installed build/account has not
been verified. This document does not instruct the user to search for it as if
it were known to exist. It controls command network destinations; no documented
user-facing Work control granting this particular session arbitrary Unix socket
binding/connection was established by the research.

The current tool set has no exposed action for changing this session's shell
sandbox policy. Plugin permission controls are separate. No supported route to
remove these exact restrictions while retaining this exact conversation has yet
been verified. Keep that distinction explicit instead of promising that a menu,
config edit or application restart will repair it.

Before requesting any further user action, verify the official documentation for
the exact ChatGPT Work/Linux surface, distinguish conditional rollout features
from available controls, and state what is still unknown. Do not ask the user to
supply another screenshot of the already absent composer control.

## 3. Keep execution and control in this conversation where supported

Once the current chat's effective networking and local IPC checks pass, continue
source editing, builds, test diagnosis and MCP development here. Changing the
approval reviewer alone does not establish those permissions. The acceptance
criterion is successful real commands in this chat.

If the app cannot grant a needed capability to this conversation, an ordinary
terminal can execute the specific blocked setup/build command while this chat
continues to own the source changes and diagnosis. That keeps the conversation
here but does not mean every command is automated here. Do not present this
manual fallback as a repaired sandbox. The separate CLI appendix is optional and
must not be treated as the user's preferred route.

## 4. Verify before treating the environment as repaired

Have the agent in this conversation run the three baseline commands itself.
They must pass in this chat's execution context, not only in your terminal. In this repository also run:

```bash
python3 -B -m unittest discover -s tests -p 'test_*mcp*.py' -q
```

`-m unittest` runs Python's test runner. `discover` finds tests under `-s tests`;
`-p` limits discovery to the matching MCP test files, and `-q` reduces output.
This full invocation includes the real Unix socket test. A Windows-only skip on
Linux is expected; an EPERM error in the Unix test is not a passing result.

Codex-only reference, not a Work configuration instruction: if public Git works
but sockets still fail in a separately configured Codex task, inspect its effective
permission profile. A filtered profile may need the exact Kdenlive endpoint allowed under
`permissions.<profile>.network.unix_sockets`. Domain allowlists and
`allow_local_binding` are different controls; neither is a substitute for Unix
socket authorization. Temporary test sockets and GUI session sockets may require
additional supported grants. Do not enable arbitrary Unix sockets merely to hide
which integration is blocked.

For a separate Codex task's later narrower network policy, define a named permission profile with
`features.network_proxy=true`, an explicit domain allowlist and exact required
Unix endpoints. Permission profiles are beta and must not be mixed with legacy
`sandbox_mode` / `sandbox_workspace_write` settings. Test such a profile separately
before replacing a working baseline.

## 5. Build the matching native dependency and application

Once access checks pass, let the agent run:

```bash
python3 -B dev-tools/mcp-linux.py build --jobs 2
```

`build` downloads the pinned MLT source, applies the four preserved patches,
compiles/tests MLT, compiles/tests Kdenlive and installs into
`build-mcp-linux/install`. `--jobs 2` limits concurrent compiler work to reduce
memory pressure. The helper does not use sudo or replace the system Flatpak.

An existing source checkout at another revision is deliberately refused. If you
already executed the earlier `git clone --no-checkout` instruction, have the agent
inspect that clean checkout and select the pinned dependency revision before
restarting the helper; do not force-reset a modified dependency tree.

## 6. Verify and register actual MCP control

In one ordinary terminal, from the project directory:

```bash
python3 -B dev-tools/mcp-linux.py launch --isolated
```

`launch` starts the newly built editor with MCP enabled. `--isolated` places
configuration/data/cache under the build folder for initial testing. It does not
prevent you from opening or editing an explicitly selected project; use generated
test assets or a project copy for verification.

In another terminal:

```bash
cd /home/USER/code/kdenlive
python3 -B dev-tools/mcp-linux.py probe
```

`probe` performs the initialize/discovery/state reads against the exact private
Unix socket. It sends no project-editing commands and exits after its checks.
Only one client is accepted, so let the probe exit before connecting a client.

To expose native MCP tools in this chat, use this ChatGPT surface's supported
local MCP/plugin registration, if available. That registration route has not yet
been verified for this custom project. A successful bridge probe does not prove
that tools have been installed into this conversation. The CLI-specific example
is retained in the optional appendix only; it does not register a Work plugin.

A successful connection is the start of native feature verification. Exercise
editing, undo/redo, save/reopen, rendered frames/audio, cancellation and the WIP
feature contracts before claiming complete MCP coverage.

## General project error routing

| Symptom | Check and response |
| --- | --- |
| Command not found | Check the executable and PATH; install the exact missing development package through the host package manager. |
| CMake rejects a dependency version | Use the required version in an isolated prefix and configure against it. Preserve the application's minimum-version checks. |
| Git works in a browser/connector but not in the agent shell | Check command-network policy separately; these surfaces have independent connections. |
| Git fails in both the agent and your ordinary terminal | Investigate the actual host DNS, connection, proxy or TLS error. Keep certificate verification enabled. |
| Writes work in your terminal but fail in the agent | Select the correct project root or grant the exact additional writable folder. File-mode changes do not widen a sandbox. |
| Writes fail in both places | Inspect ownership/permissions of the reported path before making a narrowly scoped correction. |
| Unix socket fails only in the agent | Check local IPC/network policy and the exact socket path. Firewall-port changes do not address filesystem Unix sockets. |
| GUI fails to open or a socket is invisible | Use the logged-in desktop user's session and the custom native binary. Flatpak namespaces, Wayland/X11 and D-Bus access are separate integration concerns. |
| Unknown `--mcp-socket` option | Check the executable path; the stock editor does not contain this fork's MCP integration. |
| Compiler is killed under memory pressure | Reduce build parallelism, inspect memory and the build log, and retry the failed target. |
| Feature/tool is absent | Confirm the capability is exposed to that session and the relevant app/plugin is installed. More Linux packages or broader networking cannot create an unavailable tool. |

## Optional appendix: separate local CLI task

Run this yourself from your normal Fedora terminal. It starts a separate local
Codex task; it does not change the permissions of the existing conversation.

```bash
/usr/lib/chatgpt/resources/codex \
  --no-daemon \
  --cd /home/USER/code/kdenlive \
  --sandbox workspace-write \
  --ask-for-approval on-request \
  --config 'approvals_reviewer="user"' \
  --config sandbox_workspace_write.network_access=true \
  --config features.network_proxy=false
```

| Part | Meaning |
| --- | --- |
| `/usr/lib/chatgpt/resources/codex` | Uses the CLI already bundled in the installed ChatGPT RPM. This observed internal path can change with an app update. |
| Trailing `\` | Continues one shell command on the next line. |
| `--no-daemon` | Starts without reusing the shared background app server. It does not override managed requirements or remove the sandbox. |
| `--cd …` | Selects the project working root. |
| `--sandbox workspace-write` | Allows normal project/temp writes while retaining filesystem restrictions outside the workspace. It is not read isolation from the rest of your home directory. |
| `--ask-for-approval on-request` | Lets the agent request approval for work beyond its current boundary. |
| `--config 'approvals_reviewer="user"'` | Sends applicable approval requests to you rather than automatic review. Shell quotes preserve the TOML string. |
| `--config sandbox_workspace_write.network_access=true` | Allows command networking for this invocation. |
| `--config features.network_proxy=false` | Disables the optional command-network filtering proxy for this invocation where policy permits it. Command network access is consequently broad, including local services where the runtime permits them; there is no domain allowlist in this baseline. |

This is an explicit project-scoped filesystem policy with broad command network
access. It is not a proposal to disable the whole sandbox. These invocation
overrides do not permanently rewrite your config. Organization-managed requirements
can still reject or constrain them. If that happens, use the supported policy
owner/admin path rather than attempting to evade the restriction.

If the CLI needs authentication, use its normal ChatGPT sign-in. The bundled CLI
supports this optional device-login command:

```bash
/usr/lib/chatgpt/resources/codex login --device-auth
```

`login` authenticates the client; `--device-auth` uses a browser/device sign-in
flow. Complete it yourself and keep credentials and codes out of project files
and chat. Then rerun the launch command.

Paste this task instruction into the new CLI session:

> Read dev-docs/linux-agent-access-plan.md, dev-docs/mcp-progress.md and
> dev-docs/mcp-linux-verification.json. Preserve the current branch and every
> existing working-tree change. First rerun the Git and Unix-socket checks in your
> own command environment. Once they pass, build and test the patched MLT and
> Kdenlive with dev-tools/mcp-linux.py, then continue the unfinished native MCP
> coverage. Report actual errors and runtime evidence; do not mark full coverage
> complete from tool discovery alone.

The original conversation and its exact tool set are not automatically transferred
to the CLI. The repository's checkpoint and working changes carry the code state.

For a different project, change `--cd` to its actual folder. If that task needs a
second writable directory, add `--add-dir /absolute/path/to/the/required/folder`
before starting it. That flag grants an additional write area; grant the specific
folder the task needs. Neither extra writable roots nor network access supply
administrator privileges or unavailable browser/desktop automation tools.

For the local Codex client, after the probe succeeds:

```bash
/usr/lib/chatgpt/resources/codex mcp add kdenlive -- \
  /usr/bin/python3 -B \
  /home/USER/code/kdenlive/src/mcp/kdenlive-mcp.py \
  --socket /home/USER/code/kdenlive/build-mcp-linux/run/kdenlive-mcp-local
```

`mcp add kdenlive` stores a named MCP server entry in Codex's configuration.
`--` separates the manager's options from the server command. `/usr/bin/python3`
runs the standard-library stdio bridge, and `--socket` selects the editor's exact
AF_UNIX endpoint. This registers a local integration, not an internet-facing
server. Start/reload the client session so its MCP tool catalog is refreshed.
Registration for the desktop app's separate plugin surface may use a different
supported setup; a CLI server entry is not proof a Work plugin was installed.


## References

- [OpenAI: Work and developer configuration boundaries](https://learn.chatgpt.com/docs/developer-settings)
- [OpenAI: Work overview and conditional command-network setting](https://learn.chatgpt.com/docs/enterprise/chatgpt-work-overview)
- [OpenAI: Sandbox](https://learn.chatgpt.com/docs/sandboxing)
- [OpenAI: Permission modes](https://learn.chatgpt.com/docs/permission-modes)
- [OpenAI: Config basics](https://learn.chatgpt.com/docs/config-file/config-basic)
- [OpenAI: Configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference)
- [OpenAI: Permission profiles](https://learn.chatgpt.com/docs/permissions)
- [Project Linux setup and current verification](mcp-linux.md)

The missing composer control has now been visually confirmed by the user's
screenshot. The separate Work network setting is documented conditionally but
was not verified as available in this UI. CLI flags were checked against the
installed executable, but apply to a separate Codex task. No workflow in this
document has been demonstrated to remove this Work conversation's current
socket/network restriction.
